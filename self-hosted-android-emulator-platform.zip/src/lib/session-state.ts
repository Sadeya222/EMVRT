/** TypeScript mirror of crates/common/src/state.rs (the authoritative Rust implementation). */
export const STATES = ["REQUESTED", "QUEUED", "ASSIGNED", "BOOTING", "INSTALLING", "READY", "ACTIVE", "ENDING", "WIPED", "FAILED", "CANCELLED"] as const;
export type SessionState = (typeof STATES)[number];

export const isTerminal = (s: SessionState) => s === "WIPED" || s === "FAILED" || s === "CANCELLED";

export function canTransition(from: SessionState, to: SessionState): boolean {
  if (isTerminal(from)) return false;
  if (to === "FAILED") return true;
  const allowed: Partial<Record<SessionState, SessionState[]>> = {
    REQUESTED: ["QUEUED", "ASSIGNED", "CANCELLED"],
    QUEUED: ["ASSIGNED", "CANCELLED"],
    ASSIGNED: ["BOOTING", "ENDING", "CANCELLED"],
    BOOTING: ["INSTALLING", "READY", "ENDING", "CANCELLED"],
    INSTALLING: ["READY", "ENDING", "CANCELLED"],
    READY: ["ACTIVE", "ENDING"],
    ACTIVE: ["ENDING"],
    ENDING: ["WIPED"],
  };
  return allowed[from]?.includes(to) ?? false;
}

export function nextStates(from: SessionState): SessionState[] {
  return STATES.filter((s) => canTransition(from, s));
}

export function isState(v: unknown): v is SessionState {
  return typeof v === "string" && (STATES as readonly string[]).includes(v);
}
