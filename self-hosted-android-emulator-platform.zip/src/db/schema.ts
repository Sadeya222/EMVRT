import { pgTable, uuid, text, timestamp, index } from "drizzle-orm/pg-core";

/** Preview-only tables backing the session state-machine simulator. */
export const previewSessions = pgTable("preview_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  state: text("state").notNull(),
  profile: text("profile").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const previewSessionEvents = pgTable(
  "preview_session_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    sessionId: uuid("session_id").notNull().references(() => previewSessions.id, { onDelete: "cascade" }),
    fromState: text("from_state"),
    toState: text("to_state").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("preview_session_events_session_idx").on(t.sessionId)],
);
