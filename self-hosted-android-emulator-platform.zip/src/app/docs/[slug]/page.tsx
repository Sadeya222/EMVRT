import { readFile } from "node:fs/promises";
import path from "node:path";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";
const ALLOWED = new Set(["architecture", "security", "deployment", "agent-installation", "emulator-integration", "local-development", "roadmap", "readme"]);

export default async function DocPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!ALLOWED.has(slug)) notFound();
  const file = slug === "readme" ? path.join(process.cwd(), "device-platform", "README.md") : path.join(process.cwd(), "device-platform", "docs", `${slug}.md`);
  const content = await readFile(file, "utf8").catch(() => null);
  if (content === null) notFound();
  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <Link href="/" className="text-sm text-emerald-400 hover:underline">← Back</Link>
      <article className="mt-6 whitespace-pre-wrap rounded-xl border border-slate-800 bg-slate-900/60 p-6 font-mono text-[13px] leading-6 text-slate-200">{content}</article>
    </main>
  );
}
