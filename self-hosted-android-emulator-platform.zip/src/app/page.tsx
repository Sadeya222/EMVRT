import Link from "next/link";
import { Simulator } from "./simulator";

export const dynamic = "force-dynamic";

const DOCS = [
  ["architecture", "Architecture, schema & API plan"],
  ["security", "Security model"],
  ["deployment", "Deployment"],
  ["agent-installation", "Agent installation"],
  ["emulator-integration", "Emulator integration & streaming"],
  ["local-development", "Local development & tests"],
  ["roadmap", "Roadmap"],
  ["readme", "README / quick start"],
];

const STATS = [
  ["Rust workspace", "api · agent · common · scheduler"],
  ["Rust tests", "52 passing (unit + sqlx integration)"],
  ["Dashboard", "React · Vite · TanStack · Radix"],
  ["Infra", "Compose · PostgreSQL · MinIO · Caddy"],
];

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl px-5 py-12">
      <p className="text-xs font-medium uppercase tracking-widest text-emerald-400">Sandbox preview</p>
      <h1 className="mt-2 text-4xl font-semibold tracking-tight text-white">Device Platform</h1>
      <p className="mt-3 max-w-3xl text-slate-400">
        Self-hosted, Android-only emulator platform. The production code lives in <code className="text-emerald-300">device-platform/</code>
        {" "}(Rust control plane + host agent, React/Vite dashboard) and starts with <code className="text-emerald-300">docker compose up --build</code>.
        This preview runs inside the sandbox and exercises the session state machine against PostgreSQL.
      </p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map(([k, v]) => (
          <div key={k} className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <p className="text-xs text-slate-500">{k}</p>
            <p className="mt-1 text-sm text-slate-200">{v}</p>
          </div>
        ))}
      </div>
      <section className="mt-12" aria-labelledby="sim">
        <h2 id="sim" className="mb-1 text-xl font-semibold text-white">Session lifecycle simulator</h2>
        <p className="mb-4 text-sm text-slate-400">REQUESTED → QUEUED → ASSIGNED → BOOTING → INSTALLING → READY → ACTIVE → ENDING → WIPED, with FAILED/CANCELLED. Invalid transitions fail safely (HTTP 409).</p>
        <Simulator />
      </section>
      <section className="mt-12" aria-labelledby="docs">
        <h2 id="docs" className="mb-4 text-xl font-semibold text-white">Documentation</h2>
        <ul className="grid gap-2 sm:grid-cols-2">
          {DOCS.map(([slug, title]) => (
            <li key={slug}><Link href={`/docs/${slug}`} className="block rounded-lg border border-slate-800 px-4 py-3 text-sm text-slate-200 hover:border-emerald-600 hover:text-white">{title}</Link></li>
          ))}
        </ul>
      </section>
    </main>
  );
}
