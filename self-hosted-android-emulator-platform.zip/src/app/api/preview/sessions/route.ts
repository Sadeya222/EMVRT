import { db } from "@/db";
import { previewSessionEvents, previewSessions } from "@/db/schema";
import { desc, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";
const PROFILES = ["Pixel 6 · Android 14", "Pixel 4 · Android 11", "Generic Tablet · Android 13"];

export async function GET() {
  const sessions = await db.select().from(previewSessions).orderBy(desc(previewSessions.createdAt)).limit(10);
  const events = sessions.length
    ? await db.select().from(previewSessionEvents).where(inArray(previewSessionEvents.sessionId, sessions.map((s) => s.id))).orderBy(previewSessionEvents.createdAt)
    : [];
  return Response.json({ sessions: sessions.map((s) => ({ ...s, events: events.filter((e) => e.sessionId === s.id) })) });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { profile?: string };
  const profile = PROFILES.includes(body.profile ?? "") ? body.profile! : PROFILES[0];
  const session = await db.transaction(async (tx) => {
    const [s] = await tx.insert(previewSessions).values({ state: "REQUESTED", profile }).returning();
    await tx.insert(previewSessionEvents).values({ sessionId: s.id, fromState: null, toState: "REQUESTED" });
    return s;
  });
  return Response.json(session, { status: 201 });
}
