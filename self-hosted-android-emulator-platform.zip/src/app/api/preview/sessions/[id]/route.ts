import { db } from "@/db";
import { previewSessionEvents, previewSessions } from "@/db/schema";
import { canTransition, isState } from "@/lib/session-state";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Strict, compare-and-swap state transition (same semantics as the Rust orchestrator). */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return Response.json({ error: { code: "not_found", message: "not found" } }, { status: 404 });
  const body = (await req.json().catch(() => ({}))) as { to?: unknown };
  if (!isState(body.to)) return Response.json({ error: { code: "bad_request", message: "unknown target state" } }, { status: 400 });
  const to = body.to;
  const result = await db.transaction(async (tx) => {
    const [current] = await tx.select().from(previewSessions).where(eq(previewSessions.id, id));
    if (!current || !isState(current.state)) return { status: 404, body: { error: { code: "not_found", message: "not found" } } };
    if (!canTransition(current.state, to)) {
      return { status: 409, body: { error: { code: "conflict", message: `invalid session transition ${current.state} -> ${to}` } } };
    }
    const updated = await tx
      .update(previewSessions)
      .set({ state: to, updatedAt: new Date() })
      .where(and(eq(previewSessions.id, id), eq(previewSessions.state, current.state)))
      .returning();
    if (updated.length !== 1) return { status: 409, body: { error: { code: "conflict", message: "session changed concurrently" } } };
    await tx.insert(previewSessionEvents).values({ sessionId: id, fromState: current.state, toState: to });
    return { status: 200, body: updated[0] };
  });
  return Response.json(result.body, { status: result.status });
}
