"use client";

import { useCallback, useEffect, useState } from "react";
import { STATES, isTerminal, nextStates, type SessionState } from "@/lib/session-state";

type Ev = { id: string; fromState: string | null; toState: string; createdAt: string };
type S = { id: string; state: SessionState; profile: string; createdAt: string; events: Ev[] };

const color = (s: string) =>
  s === "READY" || s === "ACTIVE" ? "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30"
  : s === "FAILED" ? "bg-red-500/15 text-red-300 ring-red-500/30"
  : s === "WIPED" ? "bg-violet-500/15 text-violet-300 ring-violet-500/30"
  : s === "ENDING" ? "bg-amber-500/15 text-amber-300 ring-amber-500/30"
  : s === "CANCELLED" || s === "REQUESTED" || s === "QUEUED" ? "bg-slate-700/40 text-slate-300 ring-slate-600"
  : "bg-sky-500/15 text-sky-300 ring-sky-500/30";

export function Simulator() {
  const [sessions, setSessions] = useState<S[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [invalidTarget, setInvalidTarget] = useState<SessionState>("ACTIVE");

  const load = useCallback(async () => {
    const r = await fetch("/api/preview/sessions", { cache: "no-store" });
    if (r.ok) setSessions((await r.json()).sessions);
  }, []);
  useEffect(() => {
    // Initial fetch of persisted simulator sessions.
    void load();
  }, [load]);

  const act = async (fn: () => Promise<Response>) => {
    setBusy(true);
    setError(null);
    try {
      const r = await fn();
      if (!r.ok) setError((await r.json()).error?.message ?? `HTTP ${r.status}`);
      await load();
    } finally {
      setBusy(false);
    }
  };
  const create = () => act(() => fetch("/api/preview/sessions", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" }));
  const move = (id: string, to: SessionState) => act(() => fetch(`/api/preview/sessions/${id}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ to }) }));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <button onClick={create} disabled={busy} className="rounded-md bg-emerald-500 px-4 py-2 text-sm font-medium text-slate-950 hover:bg-emerald-400 disabled:opacity-50">Request session</button>
        <span className="text-xs text-slate-500">Persisted in PostgreSQL via Drizzle · transitions validated server-side with compare-and-swap.</span>
      </div>
      {error && <p role="alert" className="rounded-md border border-red-900 bg-red-950/40 px-3 py-2 text-sm text-red-200">Rejected: {error}</p>}
      {sessions.length === 0 && <p className="rounded-lg border border-dashed border-slate-700 p-6 text-center text-sm text-slate-400">No simulated sessions yet.</p>}
      <ul className="space-y-3">
        {sessions.map((s) => (
          <li key={s.id} className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <code className="text-xs text-slate-500">{s.id.slice(-8)}</code>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${color(s.state)}`}>{s.state}</span>
                <span className="text-sm text-slate-300">{s.profile}</span>
              </div>
              {!isTerminal(s.state) && (
                <div className="flex flex-wrap gap-2">
                  {nextStates(s.state).map((n) => (
                    <button key={n} disabled={busy} onClick={() => move(s.id, n)} className="rounded border border-slate-700 px-2.5 py-1 text-xs text-slate-200 hover:bg-slate-800 disabled:opacity-50">→ {n}</button>
                  ))}
                  <span className="flex items-center gap-1">
                    <select aria-label="Invalid transition target" value={invalidTarget} onChange={(e) => setInvalidTarget(e.target.value as SessionState)} className="rounded border border-slate-700 bg-slate-950 px-1 py-1 text-xs">
                      {STATES.map((x) => <option key={x}>{x}</option>)}
                    </select>
                    <button disabled={busy} onClick={() => move(s.id, invalidTarget)} className="rounded border border-red-900 px-2.5 py-1 text-xs text-red-300 hover:bg-red-950 disabled:opacity-50">try</button>
                  </span>
                </div>
              )}
            </div>
            <ol className="mt-3 flex flex-wrap gap-1 text-[11px] text-slate-500">
              {s.events.map((e, i) => <li key={e.id}>{i > 0 && "→ "}{e.toState}</li>)}
            </ol>
          </li>
        ))}
      </ul>
    </div>
  );
}
