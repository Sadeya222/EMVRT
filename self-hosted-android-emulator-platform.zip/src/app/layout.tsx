import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Device Platform — Self-hosted Android emulator platform",
  description: "Sandbox preview of the Device Platform control plane.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
