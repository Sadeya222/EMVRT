# Device Platform

A **self-hosted, Android-only** emulator platform: upload APKs, start isolated Android emulator
sessions on **your own Linux/KVM hosts**, and debug them in the browser (logcat, screenshots,
accessibility tree, tap/swipe/text/deep links, rotation, exportable action history).

> Built for teams with **no infrastructure budget**: this is not a hosted emulator farm. The control
> plane runs anywhere Docker Compose runs; emulators run on machines you already own.

| Component | Stack |
|---|---|
| Control plane API | Rust · Tokio · Axum · SQLx · PostgreSQL · utoipa (OpenAPI) · tracing · argon2 |
| Host agent (`device-agent`) | Rust · outbound WebSocket · Docker CLI · ADB |
| Scheduler | PostgreSQL row locks (`FOR UPDATE SKIP LOCKED`) |
| Dashboard | React · TypeScript · Vite · Tailwind · Radix UI · TanStack Router/Query · Zustand |
| Storage / proxy | MinIO (presigned URLs) · Caddy |

## Quick start (local demo with the FakeEmulatorAdapter)

Requirements: Docker with Compose v2.24+, `openssl`.

```bash
scripts/dev-setup.sh                 # writes .env with random secrets (dev only)
docker compose up --build            # postgres, minio, api, web, caddy
scripts/bootstrap.sh you@example.com "Acme"   # prints a one-time owner invite link
```

1. Open the printed link (it points at `http://localhost:8080/accept-invite?token=…`) and set a password.
2. **Hosts → Enroll host** → copy the generated command and run it:
   `AGENT_ENROLLMENT_TOKEN=dpe_… docker compose --profile fake-agent up -d fake-agent`
3. **Applications → New application → Upload APK** (validated, checksummed, quarantined, then approved).
4. **Sessions → New session** → the viewer shows a *simulated* display (clearly labelled “fake adapter”)
   where clicks become taps, drags become swipes, plus logcat, accessibility tree, screenshots and history.

| URL | What |
|---|---|
| http://localhost:8080 | Dashboard (via Caddy) |
| http://localhost:8080/docs | OpenAPI explorer · raw spec at `/openapi.json` |
| http://localhost:9001 | MinIO console (localhost only) |

For **real emulators** install `device-agent` on a Linux host with KVM — see
[docs/agent-installation.md](docs/agent-installation.md) and [docs/emulator-integration.md](docs/emulator-integration.md).

## Repository layout

```
apps/web               React dashboard
crates/api             Axum control plane (bin: device-api)
crates/agent           Host agent (bin: device-agent) + Fake/Android adapters
crates/common          State machine, typed agent protocol, roles, APK validator
crates/scheduler       Scheduler trait + PgScheduler
packages/api-client    TS client, types generated from the Rust OpenAPI document
packages/embed-sdk     Embed a session stream in another page (short-lived tokens only)
migrations             SQLx migrations (applied automatically on API start)
infra                  docker-compose, Dockerfiles, Caddyfiles, systemd unit
docs                   Architecture, security, deployment, agent, emulator, roadmap
```

## Quality gates

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
DATABASE_URL=postgres://user:pass@localhost:5432/postgres cargo test --workspace   # sqlx::test creates throwaway DBs
pnpm install && pnpm lint && pnpm typecheck && pnpm test && pnpm build
pnpm --filter @dp/web exec playwright install --with-deps chromium && pnpm e2e
```

`scripts/check.sh` runs all of them. Regenerate the TS client after API changes with `pnpm generate:api`.

## Honest status

* ✅ Auth, tenancy, RBAC, API keys, audit, uploads + APK validation, scheduler, agent protocol,
  session lifecycle, FakeEmulatorAdapter, dashboard — implemented and covered by tests.
* ⚠️ `AndroidEmulatorAdapter` and WebRTC streaming are **environment-dependent**: they require Docker,
  `/dev/kvm`, `adb`, allow-listed official emulator images and (for streaming) a TLS node ingress.
  They are implemented against the official tooling but cannot be exercised in CI without KVM.
  Follow the manual verification checklist in [docs/emulator-integration.md](docs/emulator-integration.md).
* ❌ iOS is not supported.

See [docs/roadmap.md](docs/roadmap.md).
