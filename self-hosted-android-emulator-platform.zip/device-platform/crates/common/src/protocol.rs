//! Typed WebSocket protocol between the control plane and `device-agent`.
//!
//! There is intentionally **no** "run shell command" message. Every command is a closed enum
//! variant with validated, typed fields, and carries a unique `command_id` used for idempotency.
use serde::{Deserialize, Serialize};
use utoipa::ToSchema;
use uuid::Uuid;

/// Maximum WebSocket frame accepted on either side.
pub const MAX_WS_MESSAGE_BYTES: usize = 4 * 1024 * 1024;
/// Maximum accessibility XML size returned by the agent.
pub const MAX_UI_XML_BYTES: usize = 2 * 1024 * 1024;
pub const PROTOCOL_VERSION: u32 = 1;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
pub struct HostReport {
    pub hostname: String,
    pub os: String,
    pub docker_version: Option<String>,
    pub kvm_available: bool,
    pub cpu_count: u32,
    pub ram_mb: u64,
    pub disk_free_mb: u64,
    pub active_sessions: u32,
    pub emulator_capacity: u32,
    /// `fake` or `android-emulator`.
    pub adapter: String,
    pub agent_version: String,
}

/// Messages sent by the agent to the control plane.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum AgentMessage {
    Hello {
        protocol_version: u32,
        report: HostReport,
    },
    Heartbeat {
        report: HostReport,
    },
    CommandAck {
        command_id: Uuid,
    },
    CommandResult {
        command_id: Uuid,
        outcome: CommandOutcome,
    },
    LogLines {
        session_id: Uuid,
        lines: Vec<LogLine>,
    },
    SessionLost {
        session_id: Uuid,
        reason: String,
    },
}

/// Messages sent by the control plane to the agent.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ControlMessage {
    Welcome {
        host_id: Uuid,
        heartbeat_interval_secs: u64,
    },
    Command {
        command: AgentCommand,
    },
    Ping,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AgentCommand {
    pub command_id: Uuid,
    pub session_id: Uuid,
    #[serde(flatten)]
    pub kind: CommandKind,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
pub struct DeviceProfileSpec {
    pub slug: String,
    pub api_level: i32,
    pub abi: String,
    pub screen_width: i32,
    pub screen_height: i32,
    pub density: i32,
    /// Key into the agent's allow-listed image map. Never a raw image reference.
    pub image_key: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
pub struct ResourceLimits {
    pub cpus: u32,
    pub memory_mb: u32,
    pub disk_mb: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind")]
pub enum CommandKind {
    PrepareDevice {
        profile: DeviceProfileSpec,
    },
    StartEmulator {
        profile: DeviceProfileSpec,
        limits: ResourceLimits,
    },
    InstallApp {
        download_url: String,
        sha256: String,
        size_bytes: u64,
        package_name: String,
    },
    StartSession {},
    SendInput {
        input: InputAction,
    },
    CaptureScreenshot {
        upload_url: String,
    },
    FetchUiXml {},
    StartLogcat {},
    StopSession {
        reason: String,
    },
    ResetDevice {},
}

impl CommandKind {
    pub fn name(&self) -> &'static str {
        match self {
            CommandKind::PrepareDevice { .. } => "PrepareDevice",
            CommandKind::StartEmulator { .. } => "StartEmulator",
            CommandKind::InstallApp { .. } => "InstallApp",
            CommandKind::StartSession {} => "StartSession",
            CommandKind::SendInput { .. } => "SendInput",
            CommandKind::CaptureScreenshot { .. } => "CaptureScreenshot",
            CommandKind::FetchUiXml {} => "FetchUiXml",
            CommandKind::StartLogcat {} => "StartLogcat",
            CommandKind::StopSession { .. } => "StopSession",
            CommandKind::ResetDevice {} => "ResetDevice",
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum KeyCode {
    Home,
    Back,
    AppSwitch,
    Enter,
    Delete,
    VolumeUp,
    VolumeDown,
    Power,
}

impl KeyCode {
    /// Android `KEYCODE_*` value.
    pub fn android_code(self) -> u32 {
        match self {
            KeyCode::Home => 3,
            KeyCode::Back => 4,
            KeyCode::AppSwitch => 187,
            KeyCode::Enter => 66,
            KeyCode::Delete => 67,
            KeyCode::VolumeUp => 24,
            KeyCode::VolumeDown => 25,
            KeyCode::Power => 26,
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, ToSchema)]
#[serde(rename_all = "snake_case")]
pub enum Orientation {
    Portrait,
    Landscape,
    ReversePortrait,
    ReverseLandscape,
}

impl Orientation {
    pub fn user_rotation(self) -> u32 {
        match self {
            Orientation::Portrait => 0,
            Orientation::Landscape => 1,
            Orientation::ReversePortrait => 2,
            Orientation::ReverseLandscape => 3,
        }
    }
}

/// User input forwarded to the device. Validated before it is ever sent to an agent,
/// and re-validated by the agent.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum InputAction {
    Tap {
        x: u32,
        y: u32,
    },
    Swipe {
        x1: u32,
        y1: u32,
        x2: u32,
        y2: u32,
        duration_ms: u32,
    },
    Text {
        text: String,
    },
    Key {
        key: KeyCode,
    },
    Rotate {
        orientation: Orientation,
    },
    DeepLink {
        uri: String,
    },
}

pub const MAX_COORD: u32 = 10_000;
pub const MAX_TEXT_LEN: usize = 500;
pub const MAX_URI_LEN: usize = 2048;
const BLOCKED_SCHEMES: &[&str] = &[
    "file",
    "content",
    "javascript",
    "data",
    "intent",
    "android-app",
];

impl InputAction {
    pub fn name(&self) -> &'static str {
        match self {
            InputAction::Tap { .. } => "tap",
            InputAction::Swipe { .. } => "swipe",
            InputAction::Text { .. } => "text",
            InputAction::Key { .. } => "key",
            InputAction::Rotate { .. } => "rotate",
            InputAction::DeepLink { .. } => "deep_link",
        }
    }

    pub fn validate(&self) -> Result<(), String> {
        let coord = |v: u32| {
            if v > MAX_COORD {
                Err(format!("coordinate {v} out of range"))
            } else {
                Ok(())
            }
        };
        match self {
            InputAction::Tap { x, y } => {
                coord(*x)?;
                coord(*y)
            }
            InputAction::Swipe {
                x1,
                y1,
                x2,
                y2,
                duration_ms,
            } => {
                for v in [x1, y1, x2, y2] {
                    coord(*v)?;
                }
                if *duration_ms == 0 || *duration_ms > 10_000 {
                    return Err("duration_ms must be 1..=10000".into());
                }
                Ok(())
            }
            InputAction::Text { text } => {
                if text.is_empty() || text.chars().count() > MAX_TEXT_LEN {
                    return Err(format!("text must be 1..={MAX_TEXT_LEN} characters"));
                }
                if text.chars().any(|c| c.is_control()) {
                    return Err("text must not contain control characters".into());
                }
                Ok(())
            }
            InputAction::Key { .. } | InputAction::Rotate { .. } => Ok(()),
            InputAction::DeepLink { uri } => validate_deep_link(uri),
        }
    }
}

pub fn validate_deep_link(uri: &str) -> Result<(), String> {
    if uri.is_empty() || uri.len() > MAX_URI_LEN {
        return Err("uri length invalid".into());
    }
    if uri.chars().any(|c| c.is_control() || c.is_whitespace()) {
        return Err("uri must not contain whitespace or control characters".into());
    }
    let (scheme, rest) = uri.split_once(':').ok_or("uri must have a scheme")?;
    let valid_scheme = !scheme.is_empty()
        && scheme
            .chars()
            .next()
            .is_some_and(|c| c.is_ascii_alphabetic())
        && scheme
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, '+' | '-' | '.'));
    if !valid_scheme || rest.is_empty() {
        return Err("invalid uri scheme".into());
    }
    if BLOCKED_SCHEMES.contains(&scheme.to_ascii_lowercase().as_str()) {
        return Err(format!("scheme '{scheme}' is not allowed"));
    }
    Ok(())
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
pub struct LogLine {
    pub ts: String,
    pub level: String,
    pub tag: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, ToSchema)]
pub struct StreamInfo {
    /// `fake` (simulated display from screenshots) or `webrtc` (official emulator web endpoint).
    pub kind: String,
    /// Host-local endpoint of the emulator web/gRPC proxy, if any. Never exposed directly to
    /// browsers; the control plane combines it with the node ingress configuration.
    pub endpoint: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum CommandData {
    Done,
    Booted { boot_ms: u64 },
    Installed { package_name: String },
    Stream { info: StreamInfo },
    UiXml { xml: String },
    Screenshot { bytes: u64 },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CommandOutcome {
    pub ok: bool,
    pub data: Option<CommandData>,
    pub error: Option<String>,
}

impl CommandOutcome {
    pub fn ok(data: CommandData) -> Self {
        Self {
            ok: true,
            data: Some(data),
            error: None,
        }
    }
    pub fn err(msg: impl Into<String>) -> Self {
        Self {
            ok: false,
            data: None,
            error: Some(msg.into()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn command_wire_format_is_stable() {
        let cmd = AgentCommand {
            command_id: Uuid::nil(),
            session_id: Uuid::nil(),
            kind: CommandKind::SendInput {
                input: InputAction::Tap { x: 1, y: 2 },
            },
        };
        let json = serde_json::to_value(ControlMessage::Command {
            command: cmd.clone(),
        })
        .unwrap();
        assert_eq!(json["type"], "command");
        assert_eq!(json["command"]["kind"], "SendInput");
        assert_eq!(json["command"]["input"]["type"], "tap");
        let back: ControlMessage = serde_json::from_value(json).unwrap();
        assert_eq!(back, ControlMessage::Command { command: cmd });
    }

    #[test]
    fn unknown_command_kinds_are_rejected() {
        let raw = r#"{"type":"command","command":{"command_id":"00000000-0000-0000-0000-000000000000","session_id":"00000000-0000-0000-0000-000000000000","kind":"Shell","cmd":"rm -rf /"}}"#;
        assert!(serde_json::from_str::<ControlMessage>(raw).is_err());
    }

    #[test]
    fn input_validation() {
        assert!(InputAction::Tap { x: 10, y: 10 }.validate().is_ok());
        assert!(InputAction::Tap { x: 20_000, y: 10 }.validate().is_err());
        assert!(InputAction::Text {
            text: "hello world".into()
        }
        .validate()
        .is_ok());
        assert!(InputAction::Text {
            text: "a\nb".into()
        }
        .validate()
        .is_err());
        assert!(InputAction::Text {
            text: String::new()
        }
        .validate()
        .is_err());
        assert!(InputAction::Swipe {
            x1: 0,
            y1: 0,
            x2: 1,
            y2: 1,
            duration_ms: 0
        }
        .validate()
        .is_err());
    }

    #[test]
    fn deep_link_validation() {
        assert!(validate_deep_link("https://example.com/a?b=c").is_ok());
        assert!(validate_deep_link("myapp://open/item/42").is_ok());
        assert!(validate_deep_link("file:///data/data").is_err());
        assert!(validate_deep_link("javascript:alert(1)").is_err());
        assert!(validate_deep_link("https://a.com/x y").is_err());
        assert!(validate_deep_link("noscheme").is_err());
        assert!(validate_deep_link("1abc://x").is_err());
    }
}
