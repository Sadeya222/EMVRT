//! Strict session state machine. Every state change in the system MUST go through
//! [`transition`]; the database layer additionally uses compare-and-swap updates.
use serde::{Deserialize, Serialize};
use std::fmt;
use std::str::FromStr;
use utoipa::ToSchema;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SessionState {
    Requested,
    Queued,
    Assigned,
    Booting,
    Installing,
    Ready,
    Active,
    Ending,
    Wiped,
    Failed,
    Cancelled,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum TransitionError {
    #[error("invalid session transition {from} -> {to}")]
    Invalid {
        from: SessionState,
        to: SessionState,
    },
    #[error("session is already in terminal state {0}")]
    Terminal(SessionState),
}

impl SessionState {
    pub const ALL: [SessionState; 11] = [
        Self::Requested,
        Self::Queued,
        Self::Assigned,
        Self::Booting,
        Self::Installing,
        Self::Ready,
        Self::Active,
        Self::Ending,
        Self::Wiped,
        Self::Failed,
        Self::Cancelled,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Requested => "REQUESTED",
            Self::Queued => "QUEUED",
            Self::Assigned => "ASSIGNED",
            Self::Booting => "BOOTING",
            Self::Installing => "INSTALLING",
            Self::Ready => "READY",
            Self::Active => "ACTIVE",
            Self::Ending => "ENDING",
            Self::Wiped => "WIPED",
            Self::Failed => "FAILED",
            Self::Cancelled => "CANCELLED",
        }
    }

    /// Terminal states never change again.
    pub fn is_terminal(self) -> bool {
        matches!(self, Self::Wiped | Self::Failed | Self::Cancelled)
    }

    /// States that hold host capacity (count against quota).
    pub fn holds_capacity(self) -> bool {
        matches!(
            self,
            Self::Assigned
                | Self::Booting
                | Self::Installing
                | Self::Ready
                | Self::Active
                | Self::Ending
        )
    }

    /// States in which the user may interact with the device.
    pub fn is_interactive(self) -> bool {
        matches!(self, Self::Ready | Self::Active)
    }

    /// Database values of states that count toward the concurrent-session quota.
    pub fn non_terminal_db_values() -> Vec<&'static str> {
        Self::ALL
            .iter()
            .filter(|s| !s.is_terminal())
            .map(|s| s.as_str())
            .collect()
    }
}

impl fmt::Display for SessionState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl FromStr for SessionState {
    type Err = String;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Self::ALL
            .iter()
            .copied()
            .find(|st| st.as_str() == s)
            .ok_or_else(|| format!("unknown session state {s}"))
    }
}

/// Validate a transition. Returns the new state on success.
pub fn transition(from: SessionState, to: SessionState) -> Result<SessionState, TransitionError> {
    use SessionState::*;
    if from.is_terminal() {
        return Err(TransitionError::Terminal(from));
    }
    let ok = match (from, to) {
        (Requested, Queued | Assigned) => true,
        (Queued, Assigned) => true,
        (Assigned, Booting) => true,
        (Booting, Installing | Ready) => true,
        (Installing, Ready) => true,
        (Ready, Active) => true,
        (Ready | Active, Ending) => true,
        // Teardown can be requested while the device is still being prepared.
        (Assigned | Booting | Installing, Ending) => true,
        (Ending, Wiped) => true,
        // Failure is possible from every non-terminal state.
        (_, Failed) => true,
        // Cancellation only before the device became usable.
        (Requested | Queued | Assigned | Booting | Installing, Cancelled) => true,
        _ => false,
    };
    if ok {
        Ok(to)
    } else {
        Err(TransitionError::Invalid { from, to })
    }
}

#[cfg(test)]
mod tests {
    use super::SessionState::*;
    use super::*;

    #[test]
    fn happy_path_is_valid() {
        let path = [
            Requested, Queued, Assigned, Booting, Installing, Ready, Active, Ending, Wiped,
        ];
        for w in path.windows(2) {
            assert_eq!(transition(w[0], w[1]), Ok(w[1]), "{} -> {}", w[0], w[1]);
        }
    }

    #[test]
    fn boot_without_app_skips_installing() {
        assert!(transition(Booting, Ready).is_ok());
    }

    #[test]
    fn terminal_states_are_final() {
        for t in [Wiped, Failed, Cancelled] {
            for to in SessionState::ALL {
                assert_eq!(transition(t, to), Err(TransitionError::Terminal(t)));
            }
        }
    }

    #[test]
    fn cannot_skip_states() {
        assert!(transition(Requested, Ready).is_err());
        assert!(transition(Queued, Booting).is_err());
        assert!(transition(Assigned, Active).is_err());
        assert!(transition(Installing, Active).is_err());
        assert!(transition(Active, Wiped).is_err());
        assert!(transition(Ready, Booting).is_err());
    }

    #[test]
    fn cancel_only_before_ready() {
        assert!(transition(Booting, Cancelled).is_ok());
        assert!(transition(Ready, Cancelled).is_err());
        assert!(transition(Active, Cancelled).is_err());
        assert!(transition(Ending, Cancelled).is_err());
    }

    #[test]
    fn fail_from_any_non_terminal() {
        for s in SessionState::ALL.iter().filter(|s| !s.is_terminal()) {
            assert_eq!(transition(*s, Failed), Ok(Failed));
        }
    }

    #[test]
    fn no_self_transitions() {
        for s in SessionState::ALL {
            if s == Failed {
                continue;
            }
            assert!(transition(s, s).is_err(), "{s} -> {s} must be rejected");
        }
    }

    #[test]
    fn string_roundtrip() {
        for s in SessionState::ALL {
            assert_eq!(s.as_str().parse::<SessionState>().unwrap(), s);
            assert_eq!(
                serde_json::to_string(&s).unwrap(),
                format!("\"{}\"", s.as_str())
            );
        }
        assert!("BOGUS".parse::<SessionState>().is_err());
    }
}
