//! Shared domain types for the Device Platform control plane and host agent.
pub mod apk;
pub mod protocol;
pub mod roles;
pub mod state;

pub use state::{transition, SessionState, TransitionError};
