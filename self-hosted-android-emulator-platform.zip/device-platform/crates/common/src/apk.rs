//! APK validation: size limits, zip-bomb heuristics, path sanity and a minimal Android binary
//! XML (AXML) parser to extract package name / version from `AndroidManifest.xml`.
use sha2::{Digest, Sha256};
use std::io::{Cursor, Read};

#[derive(Debug, Clone)]
pub struct ApkLimits {
    pub max_file_bytes: u64,
    pub max_total_uncompressed_bytes: u64,
    pub max_entries: usize,
    /// Maximum compression ratio for any single entry larger than 1 MiB.
    pub max_compression_ratio: u64,
    pub max_manifest_bytes: u64,
}

impl Default for ApkLimits {
    fn default() -> Self {
        Self {
            max_file_bytes: 200 * 1024 * 1024,
            max_total_uncompressed_bytes: 1024 * 1024 * 1024,
            max_entries: 20_000,
            max_compression_ratio: 100,
            max_manifest_bytes: 4 * 1024 * 1024,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ApkInfo {
    pub package_name: String,
    pub version_code: i64,
    pub version_name: Option<String>,
    pub min_sdk: Option<i32>,
    pub sha256: String,
    pub size_bytes: u64,
    pub entry_count: usize,
}

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum ApkError {
    #[error("file is too large ({0} bytes)")]
    TooLarge(u64),
    #[error("file is not a ZIP/APK archive")]
    NotZip,
    #[error("archive is corrupt: {0}")]
    Corrupt(String),
    #[error("archive has too many entries ({0})")]
    TooManyEntries(usize),
    #[error("archive looks like a zip bomb: {0}")]
    ZipBomb(String),
    #[error("unsafe entry path: {0}")]
    UnsafePath(String),
    #[error("AndroidManifest.xml is missing")]
    MissingManifest,
    #[error("AndroidManifest.xml is invalid: {0}")]
    InvalidManifest(String),
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}

pub fn validate_apk(bytes: &[u8], limits: &ApkLimits) -> Result<ApkInfo, ApkError> {
    let size = bytes.len() as u64;
    if size > limits.max_file_bytes {
        return Err(ApkError::TooLarge(size));
    }
    if bytes.len() < 4 || &bytes[..4] != b"PK\x03\x04" {
        return Err(ApkError::NotZip);
    }
    let mut zip =
        zip::ZipArchive::new(Cursor::new(bytes)).map_err(|e| ApkError::Corrupt(e.to_string()))?;
    let entries = zip.len();
    if entries > limits.max_entries {
        return Err(ApkError::TooManyEntries(entries));
    }
    let mut total: u64 = 0;
    let mut has_manifest = false;
    for i in 0..entries {
        let f = zip
            .by_index_raw(i)
            .map_err(|e| ApkError::Corrupt(e.to_string()))?;
        let name = f.name().to_string();
        if name.starts_with('/') || name.contains('\\') || name.split('/').any(|p| p == "..") {
            return Err(ApkError::UnsafePath(name));
        }
        let declared = f.size();
        let compressed = f.compressed_size().max(1);
        total = total.saturating_add(declared);
        if total > limits.max_total_uncompressed_bytes {
            return Err(ApkError::ZipBomb(format!(
                "total uncompressed size exceeds {} bytes",
                limits.max_total_uncompressed_bytes
            )));
        }
        if declared > 1024 * 1024 && declared / compressed > limits.max_compression_ratio {
            return Err(ApkError::ZipBomb(format!(
                "entry {name} has compression ratio {}",
                declared / compressed
            )));
        }
        if name == "AndroidManifest.xml" {
            has_manifest = true;
        }
    }
    if !has_manifest {
        return Err(ApkError::MissingManifest);
    }
    // Read the manifest with a hard cap; declared sizes in zip headers can lie.
    let mut manifest = Vec::new();
    {
        let f = zip
            .by_name("AndroidManifest.xml")
            .map_err(|e| ApkError::Corrupt(e.to_string()))?;
        f.take(limits.max_manifest_bytes + 1)
            .read_to_end(&mut manifest)
            .map_err(|e| ApkError::Corrupt(e.to_string()))?;
    }
    if manifest.len() as u64 > limits.max_manifest_bytes {
        return Err(ApkError::ZipBomb("manifest too large".into()));
    }
    let m = parse_manifest(&manifest)?;
    Ok(ApkInfo {
        package_name: m.package_name,
        version_code: m.version_code,
        version_name: m.version_name,
        min_sdk: m.min_sdk,
        sha256: sha256_hex(bytes),
        size_bytes: size,
        entry_count: entries,
    })
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ManifestInfo {
    pub package_name: String,
    pub version_code: i64,
    pub version_name: Option<String>,
    pub min_sdk: Option<i32>,
}

const RES_XML_TYPE: u16 = 0x0003;
const RES_STRING_POOL_TYPE: u16 = 0x0001;
const RES_XML_RESOURCE_MAP_TYPE: u16 = 0x0180;
const RES_XML_START_ELEMENT_TYPE: u16 = 0x0102;
const ATTR_VERSION_CODE: u32 = 0x0101_021b;
const ATTR_VERSION_NAME: u32 = 0x0101_021c;
const ATTR_MIN_SDK: u32 = 0x0101_020c;

fn u16_at(b: &[u8], o: usize) -> Result<u16, ApkError> {
    b.get(o..o + 2)
        .map(|s| u16::from_le_bytes([s[0], s[1]]))
        .ok_or_else(|| ApkError::InvalidManifest(format!("truncated at {o}")))
}
fn u32_at(b: &[u8], o: usize) -> Result<u32, ApkError> {
    b.get(o..o + 4)
        .map(|s| u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
        .ok_or_else(|| ApkError::InvalidManifest(format!("truncated at {o}")))
}

fn parse_string_pool(b: &[u8], start: usize) -> Result<Vec<String>, ApkError> {
    let header_size = u16_at(b, start + 2)? as usize;
    let count = u32_at(b, start + 8)? as usize;
    let flags = u32_at(b, start + 16)?;
    let strings_start = u32_at(b, start + 20)? as usize;
    if count > 100_000 {
        return Err(ApkError::InvalidManifest("string pool too large".into()));
    }
    let utf8 = flags & (1 << 8) != 0;
    let mut out = Vec::with_capacity(count);
    for i in 0..count {
        let off = u32_at(b, start + header_size + i * 4)? as usize;
        let mut p = start + strings_start + off;
        let s = if utf8 {
            // utf16 length (skip), then utf8 length, then bytes.
            let l1 = *b
                .get(p)
                .ok_or_else(|| ApkError::InvalidManifest("bad string".into()))?;
            p += if l1 & 0x80 != 0 { 2 } else { 1 };
            let l2 = *b
                .get(p)
                .ok_or_else(|| ApkError::InvalidManifest("bad string".into()))?
                as usize;
            let len = if l2 & 0x80 != 0 {
                let n = *b
                    .get(p + 1)
                    .ok_or_else(|| ApkError::InvalidManifest("bad string".into()))?
                    as usize;
                p += 2;
                ((l2 & 0x7f) << 8) | n
            } else {
                p += 1;
                l2
            };
            let raw = b
                .get(p..p + len)
                .ok_or_else(|| ApkError::InvalidManifest("bad string".into()))?;
            String::from_utf8_lossy(raw).into_owned()
        } else {
            let mut len = u16_at(b, p)? as usize;
            p += 2;
            if len & 0x8000 != 0 {
                len = ((len & 0x7fff) << 16) | u16_at(b, p)? as usize;
                p += 2;
            }
            let mut units = Vec::with_capacity(len);
            for k in 0..len {
                units.push(u16_at(b, p + k * 2)?);
            }
            String::from_utf16_lossy(&units)
        };
        out.push(s);
    }
    Ok(out)
}

pub fn parse_manifest(b: &[u8]) -> Result<ManifestInfo, ApkError> {
    if u16_at(b, 0)? != RES_XML_TYPE {
        return Err(ApkError::InvalidManifest(
            "not a binary XML document".into(),
        ));
    }
    let mut pos = u16_at(b, 2)? as usize;
    let mut strings: Vec<String> = Vec::new();
    let mut res_ids: Vec<u32> = Vec::new();
    let mut info = ManifestInfo::default();
    let mut saw_manifest = false;
    let mut have_code = false;
    while pos + 8 <= b.len() {
        let ty = u16_at(b, pos)?;
        let header_size = u16_at(b, pos + 2)? as usize;
        let size = u32_at(b, pos + 4)? as usize;
        if size < 8 || pos + size > b.len() {
            return Err(ApkError::InvalidManifest("bad chunk size".into()));
        }
        match ty {
            RES_STRING_POOL_TYPE => strings = parse_string_pool(b, pos)?,
            RES_XML_RESOURCE_MAP_TYPE => {
                let n = (size - header_size) / 4;
                res_ids = (0..n)
                    .map(|i| u32_at(b, pos + header_size + i * 4))
                    .collect::<Result<_, _>>()?;
            }
            RES_XML_START_ELEMENT_TYPE => {
                let ext = pos + header_size;
                let name_idx = u32_at(b, ext + 4)? as usize;
                let attr_start = u16_at(b, ext + 8)? as usize;
                let attr_size = u16_at(b, ext + 10)? as usize;
                let attr_count = u16_at(b, ext + 12)? as usize;
                let el = strings.get(name_idx).map(String::as_str).unwrap_or("");
                for a in 0..attr_count {
                    let ap = ext + attr_start + a * attr_size;
                    let an = u32_at(b, ap + 4)? as usize;
                    let raw = u32_at(b, ap + 8)?;
                    let dtype = *b
                        .get(ap + 15)
                        .ok_or_else(|| ApkError::InvalidManifest("bad attr".into()))?;
                    let data = u32_at(b, ap + 16)?;
                    let aname = strings.get(an).map(String::as_str).unwrap_or("");
                    let rid = res_ids.get(an).copied().unwrap_or(0);
                    let sval = if raw != u32::MAX {
                        strings.get(raw as usize).cloned()
                    } else if dtype == 0x03 {
                        strings.get(data as usize).cloned()
                    } else {
                        None
                    };
                    let ival = if dtype == 0x10 || dtype == 0x11 {
                        Some(data as i32 as i64)
                    } else {
                        None
                    };
                    match el {
                        "manifest" => {
                            if aname == "package" {
                                info.package_name = sval.unwrap_or_default();
                            } else if rid == ATTR_VERSION_CODE || aname == "versionCode" {
                                if let Some(v) = ival.or_else(|| sval.and_then(|s| s.parse().ok()))
                                {
                                    info.version_code = v;
                                    have_code = true;
                                }
                            } else if rid == ATTR_VERSION_NAME || aname == "versionName" {
                                info.version_name = sval.or(ival.map(|v| v.to_string()));
                            }
                        }
                        "uses-sdk" if rid == ATTR_MIN_SDK || aname == "minSdkVersion" => {
                            info.min_sdk = ival
                                .map(|v| v as i32)
                                .or_else(|| sval.and_then(|s| s.parse().ok()));
                        }
                        _ => {}
                    }
                }
                if el == "manifest" {
                    saw_manifest = true;
                }
            }
            _ => {}
        }
        pos += size;
    }
    if !saw_manifest {
        return Err(ApkError::InvalidManifest("no <manifest> element".into()));
    }
    if !is_valid_package_name(&info.package_name) {
        return Err(ApkError::InvalidManifest(format!(
            "invalid package name '{}'",
            info.package_name
        )));
    }
    if !have_code {
        return Err(ApkError::InvalidManifest("missing versionCode".into()));
    }
    Ok(info)
}

pub fn is_valid_package_name(p: &str) -> bool {
    if p.is_empty() || p.len() > 255 {
        return false;
    }
    let parts: Vec<&str> = p.split('.').collect();
    parts.len() >= 2
        && parts.iter().all(|s| {
            let mut c = s.chars();
            matches!(c.next(), Some(ch) if ch.is_ascii_alphabetic())
                && c.all(|ch| ch.is_ascii_alphanumeric() || ch == '_')
        })
}

/// Test/demo helper: build a minimal, valid binary AndroidManifest.xml.
pub mod testing {
    fn push_u16(v: &mut Vec<u8>, x: u16) {
        v.extend_from_slice(&x.to_le_bytes());
    }
    fn push_u32(v: &mut Vec<u8>, x: u32) {
        v.extend_from_slice(&x.to_le_bytes());
    }

    /// Strings: 0 "versionCode" 1 "versionName" 2 "package" 3 "manifest" 4 <pkg> 5 <vname>
    pub fn build_manifest(pkg: &str, version_code: u32, version_name: &str) -> Vec<u8> {
        let strs = [
            "versionCode",
            "versionName",
            "package",
            "manifest",
            pkg,
            version_name,
        ];
        let mut data = Vec::new();
        let mut offsets = Vec::new();
        for s in strs {
            offsets.push(data.len() as u32);
            let units: Vec<u16> = s.encode_utf16().collect();
            push_u16(&mut data, units.len() as u16);
            for u in units {
                push_u16(&mut data, u);
            }
            push_u16(&mut data, 0);
        }
        while data.len() % 4 != 0 {
            data.push(0);
        }
        let mut pool = Vec::new();
        let header = 28u16;
        let strings_start = header as u32 + 4 * strs.len() as u32;
        push_u16(&mut pool, 0x0001);
        push_u16(&mut pool, header);
        push_u32(&mut pool, strings_start + data.len() as u32);
        push_u32(&mut pool, strs.len() as u32);
        push_u32(&mut pool, 0);
        push_u32(&mut pool, 0);
        push_u32(&mut pool, strings_start);
        push_u32(&mut pool, 0);
        for o in offsets {
            push_u32(&mut pool, o);
        }
        pool.extend_from_slice(&data);

        let mut resmap = Vec::new();
        push_u16(&mut resmap, 0x0180);
        push_u16(&mut resmap, 8);
        push_u32(&mut resmap, 16);
        push_u32(&mut resmap, super::ATTR_VERSION_CODE);
        push_u32(&mut resmap, super::ATTR_VERSION_NAME);

        let attrs: [(u32, u32, u8, u32); 3] = [
            (2, 4, 0x03, 4),
            (0, u32::MAX, 0x10, version_code),
            (1, 5, 0x03, 5),
        ];
        let mut el = Vec::new();
        push_u16(&mut el, 0x0102);
        push_u16(&mut el, 16);
        push_u32(&mut el, (16 + 20 + 20 * attrs.len()) as u32);
        push_u32(&mut el, 1);
        push_u32(&mut el, u32::MAX);
        push_u32(&mut el, u32::MAX);
        push_u32(&mut el, 3);
        push_u16(&mut el, 20);
        push_u16(&mut el, 20);
        push_u16(&mut el, attrs.len() as u16);
        push_u16(&mut el, 0);
        push_u16(&mut el, 0);
        push_u16(&mut el, 0);
        for (name, raw, ty, d) in attrs {
            push_u32(&mut el, u32::MAX);
            push_u32(&mut el, name);
            push_u32(&mut el, raw);
            push_u16(&mut el, 8);
            el.push(0);
            el.push(ty);
            push_u32(&mut el, d);
        }

        let body_len = pool.len() + resmap.len() + el.len();
        let mut out = Vec::new();
        push_u16(&mut out, 0x0003);
        push_u16(&mut out, 8);
        push_u32(&mut out, (8 + body_len) as u32);
        out.extend(pool);
        out.extend(resmap);
        out.extend(el);
        out
    }

    /// Build a tiny but structurally valid APK (zip) for tests and demo uploads.
    pub fn build_apk(pkg: &str, version_code: u32, version_name: &str) -> Vec<u8> {
        use std::io::Write;
        let mut buf = std::io::Cursor::new(Vec::new());
        {
            let mut w = zip::ZipWriter::new(&mut buf);
            let opts: zip::write::SimpleFileOptions = zip::write::SimpleFileOptions::default();
            w.start_file("AndroidManifest.xml", opts).unwrap();
            w.write_all(&build_manifest(pkg, version_code, version_name))
                .unwrap();
            w.start_file("classes.dex", opts).unwrap();
            w.write_all(b"dex\n035\0").unwrap();
            w.finish().unwrap();
        }
        buf.into_inner()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn parses_generated_manifest() {
        let m = parse_manifest(&testing::build_manifest("com.example.demo", 42, "1.4.2")).unwrap();
        assert_eq!(m.package_name, "com.example.demo");
        assert_eq!(m.version_code, 42);
        assert_eq!(m.version_name.as_deref(), Some("1.4.2"));
    }

    #[test]
    fn validates_apk() {
        let apk = testing::build_apk("com.example.demo", 7, "0.7");
        let info = validate_apk(&apk, &ApkLimits::default()).unwrap();
        assert_eq!(info.package_name, "com.example.demo");
        assert_eq!(info.version_code, 7);
        assert_eq!(info.sha256.len(), 64);
        assert_eq!(info.size_bytes, apk.len() as u64);
    }

    #[test]
    fn rejects_non_zip_and_oversize() {
        assert_eq!(
            validate_apk(b"hello world", &ApkLimits::default()),
            Err(ApkError::NotZip)
        );
        let limits = ApkLimits {
            max_file_bytes: 10,
            ..Default::default()
        };
        assert!(matches!(
            validate_apk(&testing::build_apk("a.b", 1, "1"), &limits),
            Err(ApkError::TooLarge(_))
        ));
    }

    #[test]
    fn rejects_zip_bomb() {
        let mut buf = std::io::Cursor::new(Vec::new());
        {
            let mut w = zip::ZipWriter::new(&mut buf);
            let opts = zip::write::SimpleFileOptions::default()
                .compression_method(zip::CompressionMethod::Deflated);
            w.start_file("AndroidManifest.xml", opts).unwrap();
            w.write_all(&testing::build_manifest("com.bomb.app", 1, "1"))
                .unwrap();
            w.start_file("assets/zeros.bin", opts).unwrap();
            w.write_all(&vec![0u8; 16 * 1024 * 1024]).unwrap();
            w.finish().unwrap();
        }
        let res = validate_apk(&buf.into_inner(), &ApkLimits::default());
        assert!(matches!(res, Err(ApkError::ZipBomb(_))), "{res:?}");
    }

    #[test]
    fn rejects_missing_manifest() {
        let mut buf = std::io::Cursor::new(Vec::new());
        {
            let mut w = zip::ZipWriter::new(&mut buf);
            w.start_file("classes.dex", zip::write::SimpleFileOptions::default())
                .unwrap();
            w.write_all(b"x").unwrap();
            w.finish().unwrap();
        }
        assert_eq!(
            validate_apk(&buf.into_inner(), &ApkLimits::default()),
            Err(ApkError::MissingManifest)
        );
    }

    #[test]
    fn package_names() {
        assert!(is_valid_package_name("com.example.app"));
        assert!(!is_valid_package_name("com"));
        assert!(!is_valid_package_name("com..x"));
        assert!(!is_valid_package_name("1com.x"));
        assert!(!is_valid_package_name("com.ex ample"));
    }
}
