//! Organization roles and permissions.
use serde::{Deserialize, Serialize};
use std::str::FromStr;
use utoipa::ToSchema;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "lowercase")]
pub enum Role {
    Viewer,
    Developer,
    Admin,
    Owner,
}

impl Role {
    pub fn as_str(self) -> &'static str {
        match self {
            Role::Viewer => "viewer",
            Role::Developer => "developer",
            Role::Admin => "admin",
            Role::Owner => "owner",
        }
    }
    pub fn allows(self, perm: Perm) -> bool {
        self >= perm.min_role()
    }
}

impl FromStr for Role {
    type Err = String;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "viewer" => Ok(Role::Viewer),
            "developer" => Ok(Role::Developer),
            "admin" => Ok(Role::Admin),
            "owner" => Ok(Role::Owner),
            _ => Err(format!("unknown role {s}")),
        }
    }
}

/// Fine-grained permission. Each maps to a minimum role and (for API keys) a scope.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Perm {
    ReadApps,
    WriteApps,
    ReadSessions,
    WriteSessions,
    ReadHosts,
    ManageHosts,
    ManageMembers,
    ManageApiKeys,
    ManageSettings,
    ReadAudit,
    ReadUsage,
}

impl Perm {
    pub fn min_role(self) -> Role {
        use Perm::*;
        match self {
            ReadApps | ReadSessions | ReadHosts | ReadUsage => Role::Viewer,
            WriteApps | WriteSessions => Role::Developer,
            ManageHosts | ManageMembers | ManageApiKeys | ManageSettings | ReadAudit => Role::Admin,
        }
    }
    /// API key scope that grants this permission (None = never grantable via API key).
    pub fn scope(self) -> Option<&'static str> {
        use Perm::*;
        match self {
            ReadApps => Some("apps:read"),
            WriteApps => Some("apps:write"),
            ReadSessions => Some("sessions:read"),
            WriteSessions => Some("sessions:write"),
            ReadHosts => Some("hosts:read"),
            ReadUsage => Some("usage:read"),
            ManageHosts | ManageMembers | ManageApiKeys | ManageSettings | ReadAudit => None,
        }
    }
}

pub const API_KEY_SCOPES: &[&str] = &[
    "apps:read",
    "apps:write",
    "sessions:read",
    "sessions:write",
    "hosts:read",
    "usage:read",
];

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn role_hierarchy() {
        assert!(Role::Owner.allows(Perm::ManageMembers));
        assert!(Role::Admin.allows(Perm::ManageApiKeys));
        assert!(!Role::Developer.allows(Perm::ManageHosts));
        assert!(Role::Developer.allows(Perm::WriteSessions));
        assert!(!Role::Viewer.allows(Perm::WriteApps));
        assert!(Role::Viewer.allows(Perm::ReadSessions));
    }
    #[test]
    fn admin_perms_not_grantable_to_keys() {
        assert!(Perm::ManageApiKeys.scope().is_none());
        assert!(Perm::ReadAudit.scope().is_none());
    }
}
