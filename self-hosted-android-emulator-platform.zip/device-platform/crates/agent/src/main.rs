//! device-agent: runs on a customer-owned Linux/KVM host and dials OUT to the control plane.
use anyhow::{bail, Context};
use dp_agent::adapter::android::{AndroidConfig, AndroidEmulatorAdapter};
use dp_agent::adapter::fake::FakeEmulatorAdapter;
use dp_agent::adapter::EmulatorAdapter;
use dp_agent::executor::Executor;
use dp_agent::sysinfo;
use dp_common::protocol::{
    AgentMessage, ControlMessage, HostReport, LogLine, MAX_WS_MESSAGE_BYTES, PROTOCOL_VERSION,
};
use futures::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;
use tokio_tungstenite::tungstenite::client::IntoClientRequest;
use tokio_tungstenite::tungstenite::protocol::WebSocketConfig;
use tokio_tungstenite::tungstenite::Message;
use uuid::Uuid;

#[derive(Serialize, Deserialize)]
struct Credentials {
    host_id: Uuid,
    agent_id: Uuid,
    agent_secret: String,
}

struct Settings {
    control_plane: String,
    state_dir: PathBuf,
    capacity: u32,
    stream_base_url: Option<String>,
    allow_insecure: bool,
}

fn env(name: &str) -> Option<String> {
    std::env::var(name).ok().filter(|v| !v.is_empty())
}

fn load_images() -> anyhow::Result<HashMap<String, String>> {
    let raw = match (env("AGENT_IMAGES_FILE"), env("AGENT_IMAGES")) {
        (Some(path), _) => std::fs::read_to_string(&path).with_context(|| format!("read {path}"))?,
        (None, Some(json)) => json,
        (None, None) => bail!("AGENT_IMAGES_FILE or AGENT_IMAGES (JSON map image_key -> image) is required for the android-emulator adapter"),
    };
    let map: HashMap<String, String> =
        serde_json::from_str(&raw).context("image allow-list must be a JSON object")?;
    for (k, v) in &map {
        if k.is_empty() || v.contains(char::is_whitespace) || v.starts_with('-') {
            bail!("invalid allow-list entry {k}");
        }
    }
    Ok(map)
}

async fn save_credentials(path: &Path, c: &Credentials) -> anyhow::Result<()> {
    use tokio::io::AsyncWriteExt;
    let mut opts = tokio::fs::OpenOptions::new();
    opts.write(true).create(true).truncate(true);
    #[cfg(unix)]
    opts.mode(0o600);
    let mut f = opts.open(path).await?;
    f.write_all(&serde_json::to_vec_pretty(c)?).await?;
    Ok(())
}

async fn build_report(adapter: &Arc<dyn EmulatorAdapter>, s: &Settings) -> HostReport {
    let caps = adapter.capabilities().await;
    sysinfo::report(sysinfo::ReportInputs {
        adapter: adapter.name(),
        docker_version: caps.docker_version,
        kvm: caps.kvm,
        active_sessions: adapter.active_sessions().await,
        capacity: s.capacity,
        state_dir: &s.state_dir,
    })
    .await
}

async fn enroll(
    s: &Settings,
    adapter: &Arc<dyn EmulatorAdapter>,
    token: &str,
) -> anyhow::Result<Credentials> {
    #[derive(Serialize)]
    struct Req<'a> {
        enrollment_token: &'a str,
        report: HostReport,
        stream_base_url: Option<String>,
    }
    let report = build_report(adapter, s).await;
    let res = reqwest::Client::new()
        .post(format!("{}/v1/agent/enroll", s.control_plane))
        .json(&Req {
            enrollment_token: token,
            report,
            stream_base_url: s.stream_base_url.clone(),
        })
        .send()
        .await?;
    if !res.status().is_success() {
        bail!(
            "enrollment failed: HTTP {} (token expired or already used?)",
            res.status()
        );
    }
    Ok(res.json().await?)
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()),
        )
        .init();
    let settings = Settings {
        control_plane: env("CONTROL_PLANE_URL")
            .context("CONTROL_PLANE_URL is required")?
            .trim_end_matches('/')
            .to_string(),
        state_dir: env("AGENT_STATE_DIR")
            .unwrap_or_else(|| "/var/lib/device-agent".into())
            .into(),
        capacity: env("AGENT_CAPACITY")
            .map(|v| v.parse())
            .transpose()?
            .unwrap_or(2),
        stream_base_url: env("AGENT_STREAM_BASE_URL"),
        allow_insecure: env("AGENT_ALLOW_INSECURE").as_deref() == Some("true"),
    };
    if settings.control_plane.starts_with("http://") && !settings.allow_insecure {
        bail!("CONTROL_PLANE_URL must be https:// (set AGENT_ALLOW_INSECURE=true only for local development)");
    }
    tokio::fs::create_dir_all(&settings.state_dir).await?;
    let work_dir = settings.state_dir.join("work");

    let adapter: Arc<dyn EmulatorAdapter> = match env("AGENT_ADAPTER")
        .as_deref()
        .unwrap_or("android-emulator")
    {
        "fake" => {
            tracing::warn!("using FakeEmulatorAdapter: no real Android emulator will be started");
            Arc::new(FakeEmulatorAdapter::new(Duration::from_millis(
                env("FAKE_BOOT_MS")
                    .and_then(|v| v.parse().ok())
                    .unwrap_or(2500),
            )))
        }
        "android-emulator" => {
            let home = env("HOME").unwrap_or_else(|| "/root".into());
            Arc::new(AndroidEmulatorAdapter::new(AndroidConfig {
                images: load_images()?,
                docker: env("AGENT_DOCKER_BIN").unwrap_or_else(|| "docker".into()),
                adb: env("AGENT_ADB_BIN").unwrap_or_else(|| "adb".into()),
                network: env("AGENT_EMULATOR_NETWORK").unwrap_or_else(|| "dp-emulators".into()),
                publish_bind: env("AGENT_PUBLISH_BIND").unwrap_or_else(|| "127.0.0.1".into()),
                data_mount: Some(
                    env("AGENT_EMULATOR_DATA_MOUNT").unwrap_or_else(|| "/android-home".into()),
                )
                .filter(|v| v != "none"),
                adb_key_path: env("AGENT_ADB_KEY")
                    .map(PathBuf::from)
                    .unwrap_or_else(|| PathBuf::from(home).join(".android/adbkey")),
                boot_timeout: Duration::from_secs(
                    env("AGENT_BOOT_TIMEOUT_SECS")
                        .and_then(|v| v.parse().ok())
                        .unwrap_or(480),
                ),
                work_dir: work_dir.clone(),
            }))
        }
        other => bail!("unknown AGENT_ADAPTER {other}"),
    };
    match adapter.reap_orphans().await {
        Ok(n) if n > 0 => tracing::info!(removed = n, "reaped orphaned emulator containers"),
        Ok(_) => {}
        Err(e) => tracing::warn!(error = %e, "orphan reaping failed"),
    }

    let cred_path = settings.state_dir.join("credentials.json");
    let creds: Credentials = match tokio::fs::read(&cred_path).await {
        Ok(b) => serde_json::from_slice(&b).context("corrupt credentials.json")?,
        Err(_) => {
            let token = env("AGENT_ENROLLMENT_TOKEN")
                .context("not enrolled yet: AGENT_ENROLLMENT_TOKEN is required")?;
            let c = enroll(&settings, &adapter, &token).await?;
            save_credentials(&cred_path, &c).await?;
            tracing::info!(host_id = %c.host_id, "enrolled; the enrollment token is now consumed and can be removed");
            c
        }
    };

    let (log_tx, log_rx) = mpsc::channel::<(Uuid, LogLine)>(4096);
    let executor = Arc::new(Executor::new(adapter.clone(), work_dir, log_tx));
    let log_rx = Arc::new(tokio::sync::Mutex::new(log_rx));
    let mut backoff = 1u64;
    loop {
        match run_connection(&settings, &creds, executor.clone(), log_rx.clone()).await {
            Ok(()) => {
                tracing::info!("connection closed");
                backoff = 1;
            }
            Err(e) => tracing::warn!(error = %e, "connection failed"),
        }
        let wait = backoff.min(30);
        tokio::time::sleep(Duration::from_secs(wait)).await;
        backoff = (backoff * 2).min(30);
    }
}

async fn run_connection(
    s: &Settings,
    creds: &Credentials,
    executor: Arc<Executor>,
    log_rx: Arc<tokio::sync::Mutex<mpsc::Receiver<(Uuid, LogLine)>>>,
) -> anyhow::Result<()> {
    let ws_url = format!(
        "{}/v1/agent/connect",
        s.control_plane
            .replacen("https://", "wss://", 1)
            .replacen("http://", "ws://", 1)
    );
    let mut req = ws_url.into_client_request()?;
    req.headers_mut().insert(
        "authorization",
        format!("Bearer {}.{}", creds.agent_id, creds.agent_secret).parse()?,
    );
    let cfg = WebSocketConfig {
        max_message_size: Some(MAX_WS_MESSAGE_BYTES),
        max_frame_size: Some(MAX_WS_MESSAGE_BYTES),
        ..Default::default()
    };
    let (ws, _) = tokio_tungstenite::connect_async_with_config(req, Some(cfg), false).await?;
    tracing::info!("connected to control plane");
    let (mut sink, mut stream) = ws.split();
    let (out_tx, mut out_rx) = mpsc::channel::<AgentMessage>(256);

    let writer = tokio::spawn(async move {
        while let Some(m) = out_rx.recv().await {
            let Ok(t) = serde_json::to_string(&m) else {
                continue;
            };
            if sink.send(Message::Text(t)).await.is_err() {
                break;
            }
        }
    });

    let adapter = executor.adapter().clone();
    out_tx
        .send(AgentMessage::Hello {
            protocol_version: PROTOCOL_VERSION,
            report: build_report(&adapter, s).await,
        })
        .await?;

    // Heartbeats.
    let hb_tx = out_tx.clone();
    let hb_settings = Settings {
        control_plane: s.control_plane.clone(),
        state_dir: s.state_dir.clone(),
        capacity: s.capacity,
        stream_base_url: None,
        allow_insecure: s.allow_insecure,
    };
    let hb_adapter = adapter.clone();
    let heartbeat = tokio::spawn(async move {
        let mut t = tokio::time::interval(Duration::from_secs(15));
        loop {
            t.tick().await;
            let report = build_report(&hb_adapter, &hb_settings).await;
            if hb_tx
                .send(AgentMessage::Heartbeat { report })
                .await
                .is_err()
            {
                break;
            }
        }
    });

    // Batch logcat lines per session once a second.
    let lg_tx = out_tx.clone();
    let logs = tokio::spawn(async move {
        let mut rx = log_rx.lock().await;
        let mut t = tokio::time::interval(Duration::from_secs(1));
        let mut batch: HashMap<Uuid, Vec<LogLine>> = HashMap::new();
        loop {
            tokio::select! {
                m = rx.recv() => match m {
                    Some((sid, line)) => {
                        let v = batch.entry(sid).or_default();
                        if v.len() < 500 { v.push(line); }
                    }
                    None => break,
                },
                _ = t.tick() => {
                    for (session_id, lines) in batch.drain() {
                        if lg_tx.send(AgentMessage::LogLines { session_id, lines }).await.is_err() { return; }
                    }
                }
            }
        }
    });

    let result: anyhow::Result<()> = async {
        while let Some(msg) = stream.next().await {
            let text = match msg? {
                Message::Text(t) => t,
                Message::Close(_) => break,
                _ => continue,
            };
            match serde_json::from_str::<ControlMessage>(&text) {
                Ok(ControlMessage::Welcome { host_id, .. }) => tracing::info!(%host_id, "welcomed by control plane"),
                Ok(ControlMessage::Ping) => {}
                Ok(ControlMessage::Command { command }) => {
                    let id = command.command_id;
                    tracing::info!(command = command.kind.name(), session = %command.session_id, %id, "command received");
                    out_tx.send(AgentMessage::CommandAck { command_id: id }).await?;
                    let ex = executor.clone();
                    let tx = out_tx.clone();
                    tokio::spawn(async move {
                        if let Some(outcome) = ex.execute(command).await {
                            let _ = tx.send(AgentMessage::CommandResult { command_id: id, outcome }).await;
                        }
                    });
                }
                // Unknown/untyped messages are dropped: the agent only understands typed commands.
                Err(e) => tracing::warn!(error = %e, "ignoring unrecognised control message"),
            }
        }
        Ok(())
    }
    .await;
    heartbeat.abort();
    logs.abort();
    writer.abort();
    result
}
