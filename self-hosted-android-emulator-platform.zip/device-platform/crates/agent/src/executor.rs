//! Executes typed commands against an adapter with command-id based idempotency.
use crate::adapter::{EmulatorAdapter, LogSender};
use dp_common::protocol::{AgentCommand, CommandData, CommandKind, CommandOutcome};
use futures::StreamExt;
use sha2::{Digest, Sha256};
use std::collections::{HashMap, HashSet, VecDeque};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use uuid::Uuid;

const CACHE_SIZE: usize = 2048;
const MAX_SCREENSHOT: usize = 16 * 1024 * 1024;

#[derive(Default)]
struct Cache {
    order: VecDeque<Uuid>,
    results: HashMap<Uuid, CommandOutcome>,
    in_flight: HashSet<Uuid>,
}

pub enum Dedup {
    Run,
    Cached(CommandOutcome),
    InFlight,
}

pub struct Executor {
    adapter: Arc<dyn EmulatorAdapter>,
    cache: Mutex<Cache>,
    http: reqwest::Client,
    work_dir: PathBuf,
    log_tx: LogSender,
}

impl Executor {
    pub fn new(adapter: Arc<dyn EmulatorAdapter>, work_dir: PathBuf, log_tx: LogSender) -> Self {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(300))
            .build()
            .expect("http client");
        Self {
            adapter,
            cache: Mutex::new(Cache::default()),
            http,
            work_dir,
            log_tx,
        }
    }

    pub fn adapter(&self) -> &Arc<dyn EmulatorAdapter> {
        &self.adapter
    }

    fn begin(&self, id: Uuid) -> Dedup {
        let mut c = self.cache.lock().unwrap();
        if let Some(r) = c.results.get(&id) {
            return Dedup::Cached(r.clone());
        }
        if !c.in_flight.insert(id) {
            return Dedup::InFlight;
        }
        Dedup::Run
    }

    fn finish(&self, id: Uuid, outcome: &CommandOutcome) {
        let mut c = self.cache.lock().unwrap();
        c.in_flight.remove(&id);
        c.results.insert(id, outcome.clone());
        c.order.push_back(id);
        while c.order.len() > CACHE_SIZE {
            if let Some(old) = c.order.pop_front() {
                c.results.remove(&old);
            }
        }
    }

    /// Execute a command. Returns None if the same command is already running (the original
    /// execution will report the result). Re-delivered completed commands return the cached result
    /// without touching the device again.
    pub async fn execute(&self, cmd: AgentCommand) -> Option<CommandOutcome> {
        match self.begin(cmd.command_id) {
            Dedup::Cached(r) => return Some(r),
            Dedup::InFlight => return None,
            Dedup::Run => {}
        }
        let name = cmd.kind.name();
        let outcome = match self.dispatch(cmd.session_id, cmd.kind).await {
            Ok(d) => CommandOutcome::ok(d),
            Err(e) => {
                tracing::warn!(command = name, session = %cmd.session_id, error = %e, "command failed");
                CommandOutcome::err(format!("{e:#}"))
            }
        };
        self.finish(cmd.command_id, &outcome);
        Some(outcome)
    }

    async fn dispatch(&self, s: Uuid, kind: CommandKind) -> anyhow::Result<CommandData> {
        let a = &self.adapter;
        Ok(match kind {
            CommandKind::PrepareDevice { profile } => {
                a.prepare(&profile).await?;
                CommandData::Done
            }
            CommandKind::StartEmulator { profile, limits } => CommandData::Booted {
                boot_ms: a.start(s, &profile, &limits).await?,
            },
            CommandKind::InstallApp {
                download_url,
                sha256,
                size_bytes,
                package_name,
            } => {
                anyhow::ensure!(
                    dp_common::apk::is_valid_package_name(&package_name),
                    "invalid package name"
                );
                let path = self
                    .download_verified(s, &download_url, &sha256, size_bytes)
                    .await?;
                let res = a.install(s, &path, &package_name).await;
                let _ = tokio::fs::remove_file(&path).await;
                res?;
                CommandData::Installed { package_name }
            }
            CommandKind::StartSession {} => CommandData::Stream {
                info: a.stream_info(s).await?,
            },
            CommandKind::SendInput { input } => {
                input.validate().map_err(anyhow::Error::msg)?;
                a.input(s, &input).await?;
                CommandData::Done
            }
            CommandKind::CaptureScreenshot { upload_url } => {
                let png = a.screenshot(s).await?;
                anyhow::ensure!(png.len() <= MAX_SCREENSHOT, "screenshot too large");
                let len = png.len() as u64;
                let res = self
                    .http
                    .put(&upload_url)
                    .header("content-type", "image/png")
                    .body(png)
                    .send()
                    .await?;
                anyhow::ensure!(
                    res.status().is_success(),
                    "screenshot upload failed: {}",
                    res.status()
                );
                CommandData::Screenshot { bytes: len }
            }
            CommandKind::FetchUiXml {} => {
                let xml = a.ui_xml(s).await?;
                anyhow::ensure!(
                    xml.len() <= dp_common::protocol::MAX_UI_XML_BYTES,
                    "UI XML too large"
                );
                CommandData::UiXml { xml }
            }
            CommandKind::StartLogcat {} => {
                a.start_logcat(s, self.log_tx.clone()).await?;
                CommandData::Done
            }
            CommandKind::StopSession { .. } => {
                a.stop(s).await?;
                CommandData::Done
            }
            CommandKind::ResetDevice {} => {
                a.reset(s).await?;
                CommandData::Done
            }
        })
    }

    /// Download an artifact with a hard size cap and verify its SHA-256 before use.
    async fn download_verified(
        &self,
        s: Uuid,
        url: &str,
        sha256: &str,
        size: u64,
    ) -> anyhow::Result<PathBuf> {
        let res = self.http.get(url).send().await?;
        anyhow::ensure!(
            res.status().is_success(),
            "artifact download failed: {}",
            res.status()
        );
        let mut hasher = Sha256::new();
        let mut buf = Vec::with_capacity(size.min(256 * 1024 * 1024) as usize);
        let mut stream = res.bytes_stream();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            anyhow::ensure!(
                buf.len() as u64 + chunk.len() as u64 <= size,
                "artifact larger than declared"
            );
            hasher.update(&chunk);
            buf.extend_from_slice(&chunk);
        }
        anyhow::ensure!(buf.len() as u64 == size, "artifact size mismatch");
        verify_sha256(&hex::encode(hasher.finalize()), sha256)?;
        tokio::fs::create_dir_all(&self.work_dir).await?;
        let path = self.work_dir.join(format!("{s}.apk"));
        tokio::fs::write(&path, &buf).await?;
        Ok(path)
    }
}

pub fn verify_sha256(actual: &str, expected: &str) -> anyhow::Result<()> {
    anyhow::ensure!(
        actual.eq_ignore_ascii_case(expected),
        "artifact checksum mismatch"
    );
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::adapter::fake::FakeEmulatorAdapter;
    use dp_common::protocol::{DeviceProfileSpec, InputAction, ResourceLimits};
    use std::sync::atomic::Ordering;
    use std::time::Duration;

    fn profile() -> DeviceProfileSpec {
        DeviceProfileSpec {
            slug: "p".into(),
            api_level: 34,
            abi: "x86_64".into(),
            screen_width: 1080,
            screen_height: 2400,
            density: 420,
            image_key: "k".into(),
        }
    }

    fn setup() -> (Arc<FakeEmulatorAdapter>, Executor) {
        let fake = Arc::new(FakeEmulatorAdapter::new(Duration::from_millis(50)));
        let (tx, _rx) = tokio::sync::mpsc::channel(16);
        let ex = Executor::new(fake.clone(), std::env::temp_dir(), tx);
        (fake, ex)
    }

    #[tokio::test]
    async fn redelivered_command_is_not_executed_twice() {
        let (fake, ex) = setup();
        let session = Uuid::now_v7();
        let cmd = AgentCommand {
            command_id: Uuid::now_v7(),
            session_id: session,
            kind: CommandKind::StartEmulator {
                profile: profile(),
                limits: ResourceLimits {
                    cpus: 2,
                    memory_mb: 2048,
                    disk_mb: 4096,
                },
            },
        };
        let first = ex.execute(cmd.clone()).await.unwrap();
        let second = ex.execute(cmd.clone()).await.unwrap();
        assert!(first.ok);
        assert_eq!(first, second);
        assert_eq!(fake.counters.start.load(Ordering::SeqCst), 1);

        let tap = AgentCommand {
            command_id: Uuid::now_v7(),
            session_id: session,
            kind: CommandKind::SendInput {
                input: InputAction::Tap { x: 5, y: 5 },
            },
        };
        ex.execute(tap.clone()).await.unwrap();
        ex.execute(tap.clone()).await.unwrap();
        ex.execute(tap).await.unwrap();
        assert_eq!(fake.counters.input.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn concurrent_duplicate_reports_in_flight() {
        let (fake, ex) = setup();
        let ex = Arc::new(ex);
        let cmd = AgentCommand {
            command_id: Uuid::now_v7(),
            session_id: Uuid::now_v7(),
            kind: CommandKind::StartEmulator {
                profile: profile(),
                limits: ResourceLimits {
                    cpus: 1,
                    memory_mb: 1024,
                    disk_mb: 1024,
                },
            },
        };
        let (a, b) = tokio::join!(ex.execute(cmd.clone()), ex.execute(cmd.clone()));
        assert_eq!([a.is_some(), b.is_some()].iter().filter(|x| **x).count(), 1);
        assert_eq!(fake.counters.start.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn invalid_input_is_rejected_by_agent() {
        let (fake, ex) = setup();
        let s = Uuid::now_v7();
        ex.execute(AgentCommand {
            command_id: Uuid::now_v7(),
            session_id: s,
            kind: CommandKind::StartEmulator {
                profile: profile(),
                limits: ResourceLimits {
                    cpus: 1,
                    memory_mb: 1024,
                    disk_mb: 1024,
                },
            },
        })
        .await;
        let out = ex
            .execute(AgentCommand {
                command_id: Uuid::now_v7(),
                session_id: s,
                kind: CommandKind::SendInput {
                    input: InputAction::DeepLink {
                        uri: "file:///etc/passwd".into(),
                    },
                },
            })
            .await
            .unwrap();
        assert!(!out.ok);
        assert_eq!(fake.counters.input.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn checksum_verification() {
        assert!(verify_sha256("ABCD", "abcd").is_ok());
        assert!(verify_sha256("abcd", "abce").is_err());
    }
}
