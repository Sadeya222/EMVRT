//! device-agent library: adapters, executor, system report.
pub mod adapter;
pub mod executor;
pub mod sysinfo;
