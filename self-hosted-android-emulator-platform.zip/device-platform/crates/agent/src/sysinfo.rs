use dp_common::protocol::HostReport;
use std::path::Path;

fn read(p: &str) -> Option<String> {
    std::fs::read_to_string(p)
        .ok()
        .map(|s| s.trim().to_string())
}

pub fn hostname() -> String {
    read("/proc/sys/kernel/hostname")
        .or_else(|| std::env::var("HOSTNAME").ok())
        .unwrap_or_else(|| "unknown".into())
}

pub fn os_name() -> String {
    read("/etc/os-release")
        .and_then(|s| {
            s.lines().find_map(|l| {
                l.strip_prefix("PRETTY_NAME=")
                    .map(|v| v.trim_matches('"').to_string())
            })
        })
        .unwrap_or_else(|| std::env::consts::OS.to_string())
}

pub fn ram_mb() -> u64 {
    read("/proc/meminfo")
        .and_then(|s| {
            s.lines()
                .find(|l| l.starts_with("MemTotal:"))
                .and_then(|l| l.split_whitespace().nth(1))
                .and_then(|v| v.parse::<u64>().ok())
        })
        .map(|kb| kb / 1024)
        .unwrap_or(0)
}

pub fn kvm_available() -> bool {
    std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open("/dev/kvm")
        .is_ok()
}

pub async fn disk_free_mb(path: &Path) -> u64 {
    let out = tokio::process::Command::new("df")
        .arg("-Pk")
        .arg(path)
        .output()
        .await;
    out.ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .and_then(|s| {
            s.lines()
                .nth(1)
                .and_then(|l| l.split_whitespace().nth(3))
                .and_then(|v| v.parse::<u64>().ok())
        })
        .map(|kb| kb / 1024)
        .unwrap_or(0)
}

pub struct ReportInputs<'a> {
    pub adapter: &'a str,
    pub docker_version: Option<String>,
    pub kvm: bool,
    pub active_sessions: u32,
    pub capacity: u32,
    pub state_dir: &'a Path,
}

pub async fn report(i: ReportInputs<'_>) -> HostReport {
    HostReport {
        hostname: hostname(),
        os: os_name(),
        docker_version: i.docker_version,
        kvm_available: i.kvm,
        cpu_count: std::thread::available_parallelism()
            .map(|n| n.get() as u32)
            .unwrap_or(1),
        ram_mb: ram_mb(),
        disk_free_mb: disk_free_mb(i.state_dir).await,
        active_sessions: i.active_sessions,
        emulator_capacity: i.capacity,
        adapter: i.adapter.to_string(),
        agent_version: env!("CARGO_PKG_VERSION").to_string(),
    }
}
