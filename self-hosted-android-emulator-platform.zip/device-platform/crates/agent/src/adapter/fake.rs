//! FakeEmulatorAdapter: deterministic in-memory device used for automated tests and the local
//! demo. It is clearly reported as adapter `fake` and never pretends to be a real emulator.
use super::{Capabilities, EmulatorAdapter, LogSender};
use async_trait::async_trait;
use dp_common::protocol::{
    DeviceProfileSpec, InputAction, LogLine, Orientation, ResourceLimits, StreamInfo,
};
use std::collections::HashMap;
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Duration;
use uuid::Uuid;

#[derive(Default)]
pub struct Counters {
    pub prepare: AtomicUsize,
    pub start: AtomicUsize,
    pub install: AtomicUsize,
    pub input: AtomicUsize,
    pub stop: AtomicUsize,
}

struct Device {
    width: u32,
    height: u32,
    orientation: Orientation,
    packages: Vec<String>,
    taps: Vec<(u32, u32)>,
    text: String,
    screen: String,
    log: Option<LogSender>,
}

pub struct FakeEmulatorAdapter {
    devices: Mutex<HashMap<Uuid, Device>>,
    boot_delay: Duration,
    pub counters: Counters,
}

impl FakeEmulatorAdapter {
    pub fn new(boot_delay: Duration) -> Self {
        Self {
            devices: Mutex::new(HashMap::new()),
            boot_delay,
            counters: Counters::default(),
        }
    }

    fn with<T>(&self, s: Uuid, f: impl FnOnce(&mut Device) -> T) -> anyhow::Result<T> {
        let mut d = self.devices.lock().unwrap();
        let dev = d
            .get_mut(&s)
            .ok_or_else(|| anyhow::anyhow!("no device for session {s}"))?;
        Ok(f(dev))
    }

    fn log(&self, s: Uuid, level: &str, tag: &str, msg: String) {
        let tx = self
            .devices
            .lock()
            .unwrap()
            .get(&s)
            .and_then(|d| d.log.clone());
        if let Some(tx) = tx {
            let _ = tx.try_send((
                s,
                LogLine {
                    ts: now_ts(),
                    level: level.into(),
                    tag: tag.into(),
                    message: msg,
                },
            ));
        }
    }
}

fn now_ts() -> String {
    let d = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default();
    let s = d.as_secs() % 86_400;
    format!(
        "{:02}:{:02}:{:02}.{:03}",
        s / 3600,
        (s / 60) % 60,
        s % 60,
        d.subsec_millis()
    )
}

#[async_trait]
impl EmulatorAdapter for FakeEmulatorAdapter {
    fn name(&self) -> &'static str {
        "fake"
    }
    async fn capabilities(&self) -> Capabilities {
        Capabilities {
            kvm: false,
            docker_version: None,
        }
    }
    async fn active_sessions(&self) -> u32 {
        self.devices.lock().unwrap().len() as u32
    }
    async fn prepare(&self, _profile: &DeviceProfileSpec) -> anyhow::Result<()> {
        self.counters.prepare.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
    async fn start(
        &self,
        session: Uuid,
        p: &DeviceProfileSpec,
        _l: &ResourceLimits,
    ) -> anyhow::Result<u64> {
        if self.devices.lock().unwrap().contains_key(&session) {
            return Ok(0); // idempotent
        }
        self.counters.start.fetch_add(1, Ordering::SeqCst);
        tokio::time::sleep(self.boot_delay).await;
        self.devices.lock().unwrap().insert(
            session,
            Device {
                width: p.screen_width.max(1) as u32,
                height: p.screen_height.max(1) as u32,
                orientation: Orientation::Portrait,
                packages: vec![],
                taps: vec![],
                text: String::new(),
                screen: "launcher".into(),
                log: None,
            },
        );
        Ok(self.boot_delay.as_millis() as u64)
    }
    async fn install(&self, session: Uuid, apk: &Path, package: &str) -> anyhow::Result<()> {
        anyhow::ensure!(apk.exists(), "apk file missing");
        self.counters.install.fetch_add(1, Ordering::SeqCst);
        self.with(session, |d| {
            if !d.packages.iter().any(|p| p == package) {
                d.packages.push(package.to_string());
            }
            d.screen = package.to_string();
        })?;
        self.log(
            session,
            "I",
            "PackageManager",
            format!("Package {package} installed (fake)"),
        );
        self.log(
            session,
            "I",
            "ActivityManager",
            format!("Displayed {package}/.MainActivity"),
        );
        Ok(())
    }
    async fn stream_info(&self, session: Uuid) -> anyhow::Result<StreamInfo> {
        self.with(session, |_| ())?;
        Ok(StreamInfo {
            kind: "fake".into(),
            endpoint: None,
        })
    }
    async fn input(&self, session: Uuid, input: &InputAction) -> anyhow::Result<()> {
        input.validate().map_err(anyhow::Error::msg)?;
        self.counters.input.fetch_add(1, Ordering::SeqCst);
        let msg = self.with(session, |d| match input {
            InputAction::Tap { x, y } => {
                d.taps.push((*x, *y));
                if d.taps.len() > 20 {
                    d.taps.remove(0);
                }
                format!("tap at ({x},{y})")
            }
            InputAction::Swipe {
                x1,
                y1,
                x2,
                y2,
                duration_ms,
            } => format!("swipe ({x1},{y1})->({x2},{y2}) {duration_ms}ms"),
            InputAction::Text { text } => {
                d.text.push_str(text);
                format!("text input ({} chars)", text.chars().count())
            }
            InputAction::Key { key } => {
                if matches!(key, dp_common::protocol::KeyCode::Home) {
                    d.screen = "launcher".into();
                }
                format!("key {key:?}")
            }
            InputAction::Rotate { orientation } => {
                d.orientation = *orientation;
                format!("rotation -> {orientation:?}")
            }
            InputAction::DeepLink { uri } => {
                d.screen = format!("deeplink:{uri}");
                format!("VIEW intent for {uri}")
            }
        })?;
        self.log(session, "D", "InputDispatcher", msg);
        Ok(())
    }
    async fn screenshot(&self, session: Uuid) -> anyhow::Result<Vec<u8>> {
        let (w, h, o, taps, has_app) = self.with(session, |d| {
            (
                d.width,
                d.height,
                d.orientation,
                d.taps.clone(),
                !d.packages.is_empty(),
            )
        })?;
        let (w, h) = if matches!(o, Orientation::Landscape | Orientation::ReverseLandscape) {
            (h, w)
        } else {
            (w, h)
        };
        Ok(render_png(w, h, &taps, has_app))
    }
    async fn ui_xml(&self, session: Uuid) -> anyhow::Result<String> {
        let (w, h, screen, text, pkg) = self.with(session, |d| {
            (
                d.width,
                d.height,
                d.screen.clone(),
                d.text.clone(),
                d.packages.last().cloned(),
            )
        })?;
        let pkg = pkg.unwrap_or_else(|| "com.android.launcher3".into());
        let esc = |s: &str| {
            s.replace('&', "&amp;")
                .replace('<', "&lt;")
                .replace('>', "&gt;")
                .replace('"', "&quot;")
        };
        Ok(format!(
            r#"<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><hierarchy rotation="0"><node index="0" text="" resource-id="" class="android.widget.FrameLayout" package="{pkg}" content-desc="" clickable="false" enabled="true" focusable="false" bounds="[0,0][{w},{h}]"><node index="0" text="Fake emulator · {screen}" resource-id="{pkg}:id/title" class="android.widget.TextView" package="{pkg}" content-desc="Screen title" clickable="false" enabled="true" focusable="false" bounds="[0,120][{w},260]" /><node index="1" text="{text}" resource-id="{pkg}:id/input" class="android.widget.EditText" package="{pkg}" content-desc="Text field" clickable="true" enabled="true" focusable="true" bounds="[40,300][{w2},420]" /><node index="2" text="Continue" resource-id="{pkg}:id/continue" class="android.widget.Button" package="{pkg}" content-desc="Continue button" clickable="true" enabled="true" focusable="true" bounds="[40,460][{w2},580]" /></node></hierarchy>"#,
            pkg = esc(&pkg),
            screen = esc(&screen),
            text = esc(&text),
            w2 = w.saturating_sub(40),
        ))
    }
    async fn start_logcat(&self, session: Uuid, tx: LogSender) -> anyhow::Result<()> {
        self.with(session, |d| d.log = Some(tx.clone()))?;
        let _ = tx
            .send((
                session,
                LogLine {
                    ts: now_ts(),
                    level: "I".into(),
                    tag: "FakeEmulator".into(),
                    message: "logcat started (fake adapter)".into(),
                },
            ))
            .await;
        Ok(())
    }
    async fn stop(&self, session: Uuid) -> anyhow::Result<()> {
        self.counters.stop.fetch_add(1, Ordering::SeqCst);
        self.devices.lock().unwrap().remove(&session);
        Ok(())
    }
    async fn reset(&self, session: Uuid) -> anyhow::Result<()> {
        self.with(session, |d| {
            d.taps.clear();
            d.text.clear();
            d.screen = "launcher".into();
        })
    }
    async fn reap_orphans(&self) -> anyhow::Result<usize> {
        Ok(0)
    }
}

// ---- minimal PNG encoder (stored deflate blocks) -------------------------------------------

fn crc32(data: &[u8]) -> u32 {
    let mut c = 0xFFFF_FFFFu32;
    for &b in data {
        c ^= b as u32;
        for _ in 0..8 {
            c = if c & 1 != 0 {
                0xEDB8_8320 ^ (c >> 1)
            } else {
                c >> 1
            };
        }
    }
    !c
}

fn adler32(data: &[u8]) -> u32 {
    let (mut a, mut b) = (1u32, 0u32);
    for &x in data {
        a = (a + x as u32) % 65521;
        b = (b + a) % 65521;
    }
    (b << 16) | a
}

fn chunk(out: &mut Vec<u8>, ty: &[u8; 4], data: &[u8]) {
    out.extend_from_slice(&(data.len() as u32).to_be_bytes());
    let mut c = Vec::with_capacity(4 + data.len());
    c.extend_from_slice(ty);
    c.extend_from_slice(data);
    out.extend_from_slice(&c);
    out.extend_from_slice(&crc32(&c).to_be_bytes());
}

/// Render a simple phone-like frame at 1/4 resolution.
pub fn render_png(full_w: u32, full_h: u32, taps: &[(u32, u32)], has_app: bool) -> Vec<u8> {
    let (w, h) = ((full_w / 4).clamp(16, 1024), (full_h / 4).clamp(16, 1024));
    let mut raw = Vec::with_capacity(((w * 3 + 1) * h) as usize);
    for y in 0..h {
        raw.push(0);
        for x in 0..w {
            let mut px = if y < h / 20 {
                [17, 24, 39]
            } else if has_app && y > h / 8 && y < h / 4 {
                [16, 185, 129]
            } else {
                [30 + (y * 40 / h) as u8, 41, 59 + (x * 40 / w) as u8]
            };
            for (tx, ty) in taps {
                let (dx, dy) = ((x * 4) as i64 - *tx as i64, (y * 4) as i64 - *ty as i64);
                if dx * dx + dy * dy < 40 * 40 {
                    px = [250, 204, 21];
                }
            }
            raw.extend_from_slice(&px);
        }
    }
    let mut z = vec![0x78, 0x01];
    let mut chunks = raw.chunks(65_535).peekable();
    while let Some(c) = chunks.next() {
        z.push(if chunks.peek().is_none() { 1 } else { 0 });
        z.extend_from_slice(&(c.len() as u16).to_le_bytes());
        z.extend_from_slice(&(!(c.len() as u16)).to_le_bytes());
        z.extend_from_slice(c);
    }
    z.extend_from_slice(&adler32(&raw).to_be_bytes());
    let mut out = b"\x89PNG\r\n\x1a\n".to_vec();
    let mut ihdr = Vec::new();
    ihdr.extend_from_slice(&w.to_be_bytes());
    ihdr.extend_from_slice(&h.to_be_bytes());
    ihdr.extend_from_slice(&[8, 2, 0, 0, 0]);
    chunk(&mut out, b"IHDR", &ihdr);
    chunk(&mut out, b"IDAT", &z);
    chunk(&mut out, b"IEND", &[]);
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn png_has_signature_and_iend() {
        let p = render_png(1080, 2400, &[(100, 100)], true);
        assert!(p.starts_with(b"\x89PNG\r\n\x1a\n"));
        assert!(p.ends_with(&[0xAE, 0x42, 0x60, 0x82]));
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    }
}
