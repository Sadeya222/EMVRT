//! Emulator adapter abstraction. The executor only talks to this trait.
pub mod android;
pub mod fake;

use async_trait::async_trait;
use dp_common::protocol::{DeviceProfileSpec, InputAction, LogLine, ResourceLimits, StreamInfo};
use std::path::Path;
use tokio::sync::mpsc;
use uuid::Uuid;

pub type LogSender = mpsc::Sender<(Uuid, LogLine)>;

#[derive(Debug, Clone, Default)]
pub struct Capabilities {
    pub kvm: bool,
    pub docker_version: Option<String>,
}

#[async_trait]
pub trait EmulatorAdapter: Send + Sync {
    fn name(&self) -> &'static str;
    async fn capabilities(&self) -> Capabilities;
    async fn active_sessions(&self) -> u32;
    /// Ensure the (allow-listed) image for the profile is available locally.
    async fn prepare(&self, profile: &DeviceProfileSpec) -> anyhow::Result<()>;
    /// Start an emulator for the session and block until Android reports boot completion.
    /// Returns boot time in milliseconds. Must be idempotent for the same session.
    async fn start(
        &self,
        session: Uuid,
        profile: &DeviceProfileSpec,
        limits: &ResourceLimits,
    ) -> anyhow::Result<u64>;
    async fn install(&self, session: Uuid, apk: &Path, package: &str) -> anyhow::Result<()>;
    async fn stream_info(&self, session: Uuid) -> anyhow::Result<StreamInfo>;
    async fn input(&self, session: Uuid, input: &InputAction) -> anyhow::Result<()>;
    async fn screenshot(&self, session: Uuid) -> anyhow::Result<Vec<u8>>;
    async fn ui_xml(&self, session: Uuid) -> anyhow::Result<String>;
    async fn start_logcat(&self, session: Uuid, tx: LogSender) -> anyhow::Result<()>;
    /// Destroy the emulator and all per-session resources. Idempotent.
    async fn stop(&self, session: Uuid) -> anyhow::Result<()>;
    async fn reset(&self, session: Uuid) -> anyhow::Result<()>;
    /// Remove leftovers from a previous agent run. Returns the number of resources removed.
    async fn reap_orphans(&self) -> anyhow::Result<usize>;
}
