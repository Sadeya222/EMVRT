//! AndroidEmulatorAdapter: drives the official Android Emulator container images
//! (https://github.com/google/android-emulator-container-scripts) through the Docker CLI and ADB.
//!
//! Security properties:
//! * Images come ONLY from the operator-configured allow-list (`image_key` -> image reference).
//! * Every process is spawned with a fixed argv; nothing goes through a local shell.
//! * Values that reach `adb shell` (which is a remote shell) are integers, enum-derived constants
//!   or single-quoted strings that were validated by `InputAction::validate`.
//! * Containers get CPU/memory/pids limits, `no-new-privileges`, dropped capabilities, a dedicated
//!   bridge network, ADB published on loopback only, and an ephemeral per-session volume.
//! * The Docker socket is never mounted into emulator containers.
//!
//! Environment-dependent: requires Docker, /dev/kvm and `adb` on the host. It is exercised by the
//! manual checklist in docs/emulator-integration.md, not by CI (CI has no KVM).
use super::{Capabilities, EmulatorAdapter, LogSender};
use anyhow::{bail, Context};
use async_trait::async_trait;
use dp_common::protocol::{DeviceProfileSpec, InputAction, LogLine, ResourceLimits, StreamInfo};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::Mutex;
use std::time::{Duration, Instant};
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::process::{Child, Command};
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct AndroidConfig {
    /// image_key -> image reference. The only images this agent will ever run.
    pub images: HashMap<String, String>,
    pub docker: String,
    pub adb: String,
    pub network: String,
    /// Address to publish the emulator gRPC/web port on (127.0.0.1 unless a node ingress needs otherwise).
    pub publish_bind: String,
    /// Mount point inside the image that holds AVD state; backed by a per-session volume.
    pub data_mount: Option<String>,
    pub adb_key_path: PathBuf,
    pub boot_timeout: Duration,
    pub work_dir: PathBuf,
}

struct Running {
    serial: String,
    grpc_endpoint: Option<String>,
    packages: Vec<String>,
    logcat: Option<Child>,
}

pub struct AndroidEmulatorAdapter {
    cfg: AndroidConfig,
    sessions: Mutex<HashMap<Uuid, Running>>,
}

fn container_name(s: Uuid) -> String {
    format!("dp-{s}")
}
fn volume_name(s: Uuid) -> String {
    format!("dp-vol-{s}")
}

/// Quote a string for the remote `sh` that `adb shell` uses.
pub fn shell_quote(s: &str) -> String {
    format!("'{}'", s.replace('\'', "'\\''"))
}

/// `input text` treats spaces specially; encode them as %s and quote the rest.
pub fn input_text_arg(s: &str) -> String {
    shell_quote(&s.replace('%', "\\%").replace(' ', "%s"))
}

async fn run(bin: &str, args: &[&str], timeout: Duration) -> anyhow::Result<std::process::Output> {
    let fut = Command::new(bin)
        .args(args)
        .stdin(Stdio::null())
        .kill_on_drop(true)
        .output();
    let out = tokio::time::timeout(timeout, fut)
        .await
        .with_context(|| format!("{bin} {} timed out", args.first().unwrap_or(&"")))??;
    Ok(out)
}

async fn run_ok(bin: &str, args: &[&str], timeout: Duration) -> anyhow::Result<String> {
    let out = run(bin, args, timeout).await?;
    if !out.status.success() {
        bail!(
            "{bin} {} failed: {}",
            args.first().unwrap_or(&""),
            String::from_utf8_lossy(&out.stderr).trim()
        );
    }
    Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
}

/// Parse a `logcat -v threadtime` line: "MM-DD HH:MM:SS.mmm  PID  TID L TAG: message".
pub fn parse_threadtime(line: &str) -> Option<LogLine> {
    let mut it = line.split_whitespace();
    let date = it.next()?;
    let time = it.next()?;
    let _pid = it.next()?;
    let _tid = it.next()?;
    let level = it.next()?;
    if level.len() != 1 {
        return None;
    }
    let rest_start = line.find(&format!(" {level} "))? + 3;
    let rest = &line[rest_start..];
    let (tag, msg) = rest.split_once(": ").unwrap_or((rest, ""));
    Some(LogLine {
        ts: format!("{date} {time}"),
        level: level.into(),
        tag: tag.trim().into(),
        message: msg.into(),
    })
}

impl AndroidEmulatorAdapter {
    pub fn new(cfg: AndroidConfig) -> Self {
        Self {
            cfg,
            sessions: Mutex::new(HashMap::new()),
        }
    }

    fn image(&self, key: &str) -> anyhow::Result<&str> {
        self.cfg
            .images
            .get(key)
            .map(String::as_str)
            .with_context(|| format!("image_key '{key}' is not in this agent's allow-list"))
    }

    fn serial(&self, s: Uuid) -> anyhow::Result<String> {
        self.sessions
            .lock()
            .unwrap()
            .get(&s)
            .map(|r| r.serial.clone())
            .with_context(|| format!("no emulator for session {s}"))
    }

    async fn adb(&self, serial: &str, args: &[&str], timeout: Duration) -> anyhow::Result<String> {
        let mut full = vec!["-s", serial];
        full.extend_from_slice(args);
        run_ok(&self.cfg.adb, &full, timeout).await
    }

    async fn ensure_network(&self) -> anyhow::Result<()> {
        let d = &self.cfg.docker;
        if run(
            d,
            &["network", "inspect", &self.cfg.network],
            Duration::from_secs(15),
        )
        .await?
        .status
        .success()
        {
            return Ok(());
        }
        // Inter-container communication disabled: sessions cannot reach each other.
        run_ok(
            d,
            &[
                "network",
                "create",
                "--driver",
                "bridge",
                "--opt",
                "com.docker.network.bridge.enable_icc=false",
                "--label",
                "dp.managed=true",
                &self.cfg.network,
            ],
            Duration::from_secs(30),
        )
        .await?;
        Ok(())
    }

    async fn published_port(&self, name: &str, port: &str) -> anyhow::Result<String> {
        let out = run_ok(
            &self.cfg.docker,
            &["port", name, port],
            Duration::from_secs(10),
        )
        .await?;
        out.lines()
            .next()
            .map(|l| l.trim().replace("0.0.0.0", "127.0.0.1"))
            .context("port not published")
    }
}

#[async_trait]
impl EmulatorAdapter for AndroidEmulatorAdapter {
    fn name(&self) -> &'static str {
        "android-emulator"
    }

    async fn capabilities(&self) -> Capabilities {
        let docker_version = run_ok(
            &self.cfg.docker,
            &["version", "--format", "{{.Server.Version}}"],
            Duration::from_secs(10),
        )
        .await
        .ok();
        Capabilities {
            kvm: crate::sysinfo::kvm_available(),
            docker_version,
        }
    }

    async fn active_sessions(&self) -> u32 {
        self.sessions.lock().unwrap().len() as u32
    }

    async fn prepare(&self, profile: &DeviceProfileSpec) -> anyhow::Result<()> {
        let image = self.image(&profile.image_key)?.to_string();
        if !crate::sysinfo::kvm_available() {
            bail!("/dev/kvm is not accessible to the agent");
        }
        if !run(
            &self.cfg.docker,
            &["image", "inspect", &image],
            Duration::from_secs(15),
        )
        .await?
        .status
        .success()
        {
            tracing::info!(%image, "pulling allow-listed emulator image");
            run_ok(
                &self.cfg.docker,
                &["pull", &image],
                Duration::from_secs(1800),
            )
            .await?;
        }
        self.ensure_network().await
    }

    async fn start(
        &self,
        session: Uuid,
        profile: &DeviceProfileSpec,
        limits: &ResourceLimits,
    ) -> anyhow::Result<u64> {
        if self.sessions.lock().unwrap().contains_key(&session) {
            return Ok(0); // idempotent re-delivery
        }
        let image = self.image(&profile.image_key)?.to_string();
        let started = Instant::now();
        let name = container_name(session);
        let vol = volume_name(session);
        let d = &self.cfg.docker;
        // Re-delivery after an agent crash: remove any half-created container first.
        let _ = run(d, &["rm", "-f", "-v", &name], Duration::from_secs(30)).await;
        run_ok(
            d,
            &[
                "volume",
                "create",
                "--label",
                "dp.managed=true",
                "--label",
                &format!("dp.session={session}"),
                &vol,
            ],
            Duration::from_secs(30),
        )
        .await?;

        // Pass the ADB key through a 0600 env-file rather than argv (visible in `ps`).
        let key = tokio::fs::read_to_string(&self.cfg.adb_key_path)
            .await
            .with_context(|| format!("read adb key {}", self.cfg.adb_key_path.display()))?;
        tokio::fs::create_dir_all(&self.cfg.work_dir).await?;
        let env_file = self.cfg.work_dir.join(format!("{session}.env"));
        write_private(
            &env_file,
            format!("ADBKEY={}\n", key.replace('\n', "\\n")).as_bytes(),
        )
        .await?;

        let cpus = limits.cpus.clamp(1, 16).to_string();
        let mem = format!("{}m", limits.memory_mb.clamp(1024, 32768) + 512);
        let session_label = format!("dp.session={session}");
        let grpc_publish = format!("{}::8554", self.cfg.publish_bind);
        let env_file_s = env_file.to_string_lossy().to_string();
        let mount = self
            .cfg
            .data_mount
            .as_ref()
            .map(|m| format!("type=volume,src={vol},dst={m}"));
        let mut args: Vec<&str> = vec![
            "run",
            "-d",
            "--name",
            &name,
            "--label",
            "dp.managed=true",
            "--label",
            &session_label,
            "--device",
            "/dev/kvm",
            "--cpus",
            &cpus,
            "--memory",
            &mem,
            "--memory-swap",
            &mem,
            "--pids-limit",
            "2048",
            "--security-opt",
            "no-new-privileges:true",
            "--cap-drop",
            "NET_RAW",
            "--cap-drop",
            "MKNOD",
            "--cap-drop",
            "AUDIT_WRITE",
            "--network",
            &self.cfg.network,
            "--tmpfs",
            "/tmp:rw,size=512m",
            "--env-file",
            &env_file_s,
            "-p",
            "127.0.0.1::5555",
            "-p",
            &grpc_publish,
        ];
        if let Some(m) = &mount {
            args.push("--mount");
            args.push(m);
        }
        args.push(&image);
        let res = run_ok(d, &args, Duration::from_secs(120)).await;
        let _ = tokio::fs::remove_file(&env_file).await;
        res?;

        let adb_addr = self.published_port(&name, "5555/tcp").await?;
        let grpc = self.published_port(&name, "8554/tcp").await.ok();
        self.sessions.lock().unwrap().insert(
            session,
            Running {
                serial: adb_addr.clone(),
                grpc_endpoint: grpc,
                packages: vec![],
                logcat: None,
            },
        );

        // Wait for ADB and Android boot completion.
        let deadline = Instant::now() + self.cfg.boot_timeout;
        loop {
            let _ = run(
                &self.cfg.adb,
                &["connect", &adb_addr],
                Duration::from_secs(10),
            )
            .await;
            if let Ok(v) = self
                .adb(
                    &adb_addr,
                    &["shell", "getprop", "sys.boot_completed"],
                    Duration::from_secs(10),
                )
                .await
            {
                if v.trim() == "1" {
                    break;
                }
            }
            if Instant::now() > deadline {
                let _ = self.stop(session).await;
                bail!(
                    "emulator did not finish booting within {}s",
                    self.cfg.boot_timeout.as_secs()
                );
            }
            tokio::time::sleep(Duration::from_secs(3)).await;
        }
        // Make the device deterministic for testing.
        for setting in [
            "window_animation_scale",
            "transition_animation_scale",
            "animator_duration_scale",
        ] {
            let _ = self
                .adb(
                    &adb_addr,
                    &["shell", "settings", "put", "global", setting, "0"],
                    Duration::from_secs(10),
                )
                .await;
        }
        Ok(started.elapsed().as_millis() as u64)
    }

    async fn install(&self, session: Uuid, apk: &Path, package: &str) -> anyhow::Result<()> {
        let serial = self.serial(session)?;
        let path = apk.to_string_lossy().to_string();
        let out = self
            .adb(&serial, &["install", "-r", &path], Duration::from_secs(300))
            .await?;
        if !out.contains("Success") {
            bail!("adb install failed: {}", out.lines().last().unwrap_or(""));
        }
        if let Some(r) = self.sessions.lock().unwrap().get_mut(&session) {
            r.packages.push(package.to_string());
        }
        // Launch the app's launcher activity.
        let _ = self
            .adb(
                &serial,
                &[
                    "shell",
                    "monkey",
                    "-p",
                    &shell_quote(package),
                    "-c",
                    "android.intent.category.LAUNCHER",
                    "1",
                ],
                Duration::from_secs(30),
            )
            .await;
        Ok(())
    }

    async fn stream_info(&self, session: Uuid) -> anyhow::Result<StreamInfo> {
        let ep = self
            .sessions
            .lock()
            .unwrap()
            .get(&session)
            .map(|r| r.grpc_endpoint.clone())
            .context("no emulator")?;
        Ok(StreamInfo {
            kind: "webrtc".into(),
            endpoint: ep,
        })
    }

    async fn input(&self, session: Uuid, input: &InputAction) -> anyhow::Result<()> {
        input.validate().map_err(anyhow::Error::msg)?;
        let s = self.serial(session)?;
        let t = Duration::from_secs(15);
        match input {
            InputAction::Tap { x, y } => {
                self.adb(
                    &s,
                    &["shell", "input", "tap", &x.to_string(), &y.to_string()],
                    t,
                )
                .await?;
            }
            InputAction::Swipe {
                x1,
                y1,
                x2,
                y2,
                duration_ms,
            } => {
                let v = [x1, y1, x2, y2, duration_ms].map(|n| n.to_string());
                self.adb(
                    &s,
                    &["shell", "input", "swipe", &v[0], &v[1], &v[2], &v[3], &v[4]],
                    t,
                )
                .await?;
            }
            InputAction::Text { text } => {
                self.adb(&s, &["shell", "input", "text", &input_text_arg(text)], t)
                    .await?;
            }
            InputAction::Key { key } => {
                self.adb(
                    &s,
                    &[
                        "shell",
                        "input",
                        "keyevent",
                        &key.android_code().to_string(),
                    ],
                    t,
                )
                .await?;
            }
            InputAction::Rotate { orientation } => {
                self.adb(
                    &s,
                    &[
                        "shell",
                        "settings",
                        "put",
                        "system",
                        "accelerometer_rotation",
                        "0",
                    ],
                    t,
                )
                .await?;
                self.adb(
                    &s,
                    &[
                        "shell",
                        "settings",
                        "put",
                        "system",
                        "user_rotation",
                        &orientation.user_rotation().to_string(),
                    ],
                    t,
                )
                .await?;
            }
            InputAction::DeepLink { uri } => {
                self.adb(
                    &s,
                    &[
                        "shell",
                        "am",
                        "start",
                        "-W",
                        "-a",
                        "android.intent.action.VIEW",
                        "-d",
                        &shell_quote(uri),
                    ],
                    Duration::from_secs(30),
                )
                .await?;
            }
        }
        Ok(())
    }

    async fn screenshot(&self, session: Uuid) -> anyhow::Result<Vec<u8>> {
        let s = self.serial(session)?;
        let out = run(
            &self.cfg.adb,
            &["-s", &s, "exec-out", "screencap", "-p"],
            Duration::from_secs(20),
        )
        .await?;
        if !out.status.success() || !out.stdout.starts_with(b"\x89PNG") {
            bail!("screencap failed");
        }
        Ok(out.stdout)
    }

    async fn ui_xml(&self, session: Uuid) -> anyhow::Result<String> {
        let s = self.serial(session)?;
        self.adb(
            &s,
            &["shell", "uiautomator", "dump", "/sdcard/dp_window.xml"],
            Duration::from_secs(30),
        )
        .await?;
        let xml = self
            .adb(
                &s,
                &["exec-out", "cat", "/sdcard/dp_window.xml"],
                Duration::from_secs(15),
            )
            .await?;
        if !xml.contains("<hierarchy") {
            bail!("uiautomator returned no hierarchy");
        }
        Ok(xml)
    }

    async fn start_logcat(&self, session: Uuid, tx: LogSender) -> anyhow::Result<()> {
        let s = self.serial(session)?;
        let mut child = Command::new(&self.cfg.adb)
            .args(["-s", &s, "logcat", "-v", "threadtime", "-T", "1"])
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .stdin(Stdio::null())
            .kill_on_drop(true)
            .spawn()?;
        let stdout = child.stdout.take().context("no stdout")?;
        tokio::spawn(async move {
            let mut lines = BufReader::new(stdout).lines();
            while let Ok(Some(l)) = lines.next_line().await {
                if let Some(parsed) = parse_threadtime(&l) {
                    if tx.send((session, parsed)).await.is_err() {
                        break;
                    }
                }
            }
        });
        if let Some(r) = self.sessions.lock().unwrap().get_mut(&session) {
            r.logcat = Some(child);
        }
        Ok(())
    }

    async fn stop(&self, session: Uuid) -> anyhow::Result<()> {
        let running = self.sessions.lock().unwrap().remove(&session);
        if let Some(mut r) = running {
            if let Some(mut c) = r.logcat.take() {
                let _ = c.kill().await;
            }
            let _ = run(
                &self.cfg.adb,
                &["disconnect", &r.serial],
                Duration::from_secs(10),
            )
            .await;
        }
        let d = &self.cfg.docker;
        let out = run(
            d,
            &["rm", "-f", "-v", &container_name(session)],
            Duration::from_secs(60),
        )
        .await?;
        if !out.status.success()
            && !String::from_utf8_lossy(&out.stderr).contains("No such container")
        {
            bail!(
                "failed to remove container: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            );
        }
        let _ = run(
            d,
            &["volume", "rm", "-f", &volume_name(session)],
            Duration::from_secs(30),
        )
        .await;
        Ok(())
    }

    async fn reset(&self, session: Uuid) -> anyhow::Result<()> {
        let s = self.serial(session)?;
        let pkgs = self
            .sessions
            .lock()
            .unwrap()
            .get(&session)
            .map(|r| r.packages.clone())
            .unwrap_or_default();
        for p in pkgs {
            self.adb(
                &s,
                &["shell", "pm", "clear", &shell_quote(&p)],
                Duration::from_secs(30),
            )
            .await?;
        }
        self.adb(
            &s,
            &["shell", "input", "keyevent", "3"],
            Duration::from_secs(10),
        )
        .await?;
        Ok(())
    }

    async fn reap_orphans(&self) -> anyhow::Result<usize> {
        let d = &self.cfg.docker;
        let names = run_ok(
            d,
            &[
                "ps",
                "-a",
                "--filter",
                "label=dp.managed=true",
                "--format",
                "{{.Names}}",
            ],
            Duration::from_secs(20),
        )
        .await?;
        let mut n = 0;
        for name in names.lines().filter(|l| l.starts_with("dp-")) {
            if run(d, &["rm", "-f", "-v", name], Duration::from_secs(60))
                .await?
                .status
                .success()
            {
                n += 1;
            }
        }
        let vols = run_ok(
            d,
            &["volume", "ls", "-q", "--filter", "label=dp.managed=true"],
            Duration::from_secs(20),
        )
        .await?;
        for v in vols.lines().filter(|l| l.starts_with("dp-vol-")) {
            let _ = run(d, &["volume", "rm", "-f", v], Duration::from_secs(30)).await;
        }
        Ok(n)
    }
}

async fn write_private(path: &Path, data: &[u8]) -> anyhow::Result<()> {
    use tokio::io::AsyncWriteExt;
    let mut opts = tokio::fs::OpenOptions::new();
    opts.write(true).create(true).truncate(true);
    #[cfg(unix)]
    opts.mode(0o600);
    let mut f = opts.open(path).await?;
    f.write_all(data).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quoting_neutralises_shell_metacharacters() {
        assert_eq!(shell_quote("a'b; rm -rf /"), "'a'\\''b; rm -rf /'");
        assert_eq!(input_text_arg("hello world"), "'hello%sworld'");
        assert_eq!(
            shell_quote("myapp://x?a=1&b=$(id)"),
            "'myapp://x?a=1&b=$(id)'"
        );
    }

    #[test]
    fn parses_threadtime() {
        let l = parse_threadtime(
            "01-02 03:04:05.678  1234  1250 I ActivityManager: Displayed com.x/.Main: +1s",
        )
        .unwrap();
        assert_eq!(l.level, "I");
        assert_eq!(l.tag, "ActivityManager");
        assert_eq!(l.message, "Displayed com.x/.Main: +1s");
        assert!(parse_threadtime("--------- beginning of main").is_none());
    }

    #[test]
    fn rejects_unlisted_images() {
        let a = AndroidEmulatorAdapter::new(AndroidConfig {
            images: HashMap::from([("ok".to_string(), "registry/img:1".to_string())]),
            docker: "docker".into(),
            adb: "adb".into(),
            network: "n".into(),
            publish_bind: "127.0.0.1".into(),
            data_mount: None,
            adb_key_path: "/nonexistent".into(),
            boot_timeout: Duration::from_secs(1),
            work_dir: std::env::temp_dir(),
        });
        assert!(a.image("ok").is_ok());
        assert!(a.image("evil/image:latest").is_err());
    }
}
