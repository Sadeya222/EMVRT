#![allow(dead_code)]
use axum::body::Body;
use axum::http::{Request, StatusCode};
use axum::Router;
use dp_api::{auth, config::Config, router, AppState};
use http_body_util::BodyExt;
use serde_json::Value;
use sqlx::PgPool;
use tower::ServiceExt;
use uuid::Uuid;

pub const PASSWORD: &str = "correct-horse-battery-staple";

pub struct Tenant {
    pub org: Uuid,
    pub user: Uuid,
    pub email: String,
    pub app: Uuid,
    pub version: Uuid,
    pub host: Uuid,
    pub session: Uuid,
}

pub fn app(pool: &PgPool) -> (Router, AppState) {
    let state = AppState::new(pool.clone(), Config::for_tests("unused"));
    (router(state.clone()), state)
}

pub async fn seed(pool: &PgPool, role: &str) -> Tenant {
    let org = Uuid::now_v7();
    let user = Uuid::now_v7();
    let email = format!("{}@example.com", user.simple());
    sqlx::query("INSERT INTO organizations (id, name, slug) VALUES ($1, 'Org', $2)")
        .bind(org)
        .bind(org.to_string())
        .execute(pool)
        .await
        .unwrap();
    sqlx::query("INSERT INTO users (id, email, password_hash) VALUES ($1,$2,$3)")
        .bind(user)
        .bind(&email)
        .bind(auth::hash_password(PASSWORD).unwrap())
        .execute(pool)
        .await
        .unwrap();
    sqlx::query("INSERT INTO memberships (id, org_id, user_id, role) VALUES ($1,$2,$3,$4)")
        .bind(Uuid::now_v7())
        .bind(org)
        .bind(user)
        .bind(role)
        .execute(pool)
        .await
        .unwrap();
    let app = Uuid::now_v7();
    sqlx::query("INSERT INTO apps (id, org_id, name) VALUES ($1,$2,'App')")
        .bind(app)
        .bind(org)
        .execute(pool)
        .await
        .unwrap();
    let version = Uuid::now_v7();
    sqlx::query("INSERT INTO app_versions (id, org_id, app_id, status, object_key, file_name, declared_size, sha256, size_bytes, package_name, version_code) VALUES ($1,$2,$3,'approved','k','a.apk',10,'00',10,'com.example.app',1)")
        .bind(version).bind(org).bind(app).execute(pool).await.unwrap();
    let host = Uuid::now_v7();
    sqlx::query("INSERT INTO hosts (id, org_id, name, adapter, emulator_capacity, status, last_heartbeat_at) VALUES ($1,$2,'h','fake',2,'online',now())")
        .bind(host).bind(org).execute(pool).await.unwrap();
    let session = Uuid::now_v7();
    sqlx::query("INSERT INTO sessions (id, org_id, profile_id, host_id, state, timeout_minutes) VALUES ($1,$2,'01900000-0000-7000-8000-000000000001',$3,'WIPED',10)")
        .bind(session).bind(org).bind(host).execute(pool).await.unwrap();
    Tenant {
        org,
        user,
        email,
        app,
        version,
        host,
        session,
    }
}

pub struct Client {
    pub cookie: String,
    pub csrf: String,
    pub bearer: Option<String>,
}

pub async fn login(app: &Router, email: &str) -> Client {
    let req = Request::post("/v1/auth/login")
        .header("content-type", "application/json")
        .body(Body::from(
            serde_json::json!({ "email": email, "password": PASSWORD }).to_string(),
        ))
        .unwrap();
    let res = app.clone().oneshot(req).await.unwrap();
    assert_eq!(res.status(), StatusCode::OK, "login failed");
    let mut cookie = Vec::new();
    let mut csrf = String::new();
    for v in res.headers().get_all("set-cookie") {
        let kv = v.to_str().unwrap().split(';').next().unwrap().to_string();
        if let Some(c) = kv.strip_prefix("dp_csrf=") {
            csrf = c.to_string();
        }
        cookie.push(kv);
    }
    Client {
        cookie: cookie.join("; "),
        csrf,
        bearer: None,
    }
}

pub async fn call(
    app: &Router,
    c: &Client,
    method: &str,
    uri: &str,
    body: Option<Value>,
    with_csrf: bool,
) -> (StatusCode, Value) {
    let mut b = Request::builder()
        .method(method)
        .uri(uri)
        .header("content-type", "application/json");
    if let Some(t) = &c.bearer {
        b = b.header("authorization", format!("Bearer {t}"));
    } else {
        b = b.header("cookie", &c.cookie);
        if with_csrf {
            b = b.header("x-csrf-token", &c.csrf);
        }
    }
    let req = b
        .body(
            body.map(|v| Body::from(v.to_string()))
                .unwrap_or_else(Body::empty),
        )
        .unwrap();
    let res = app.clone().oneshot(req).await.unwrap();
    let status = res.status();
    let bytes = res.into_body().collect().await.unwrap().to_bytes();
    (
        status,
        serde_json::from_slice(&bytes).unwrap_or(Value::Null),
    )
}
