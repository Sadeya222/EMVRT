//! Command idempotency on the control-plane side.
mod common;
use common::*;
use dp_common::protocol::{AgentMessage, CommandData, CommandOutcome, LogLine};
use sqlx::PgPool;
use uuid::Uuid;

async fn insert_command(pool: &PgPool, t: &Tenant) -> Uuid {
    let id = Uuid::now_v7();
    sqlx::query("INSERT INTO session_commands (id, org_id, session_id, host_id, kind, payload, status) VALUES ($1,$2,$3,$4,'StartSession','{}','sent')")
        .bind(id).bind(t.org).bind(t.session).bind(t.host).execute(pool).await.unwrap();
    id
}

#[sqlx::test(migrations = "../../migrations")]
async fn duplicate_results_are_ignored(pool: PgPool) {
    let t = seed(&pool, "owner").await;
    let (_, state) = app(&pool);
    let id = insert_command(&pool, &t).await;
    assert!(state
        .hub
        .complete(&pool, t.host, id, CommandOutcome::ok(CommandData::Done))
        .await
        .unwrap());
    assert!(!state
        .hub
        .complete(&pool, t.host, id, CommandOutcome::err("late duplicate"))
        .await
        .unwrap());
    let (status, err): (String, Option<String>) =
        sqlx::query_as("SELECT status, error FROM session_commands WHERE id=$1")
            .bind(id)
            .fetch_one(&pool)
            .await
            .unwrap();
    assert_eq!(status, "succeeded");
    assert_eq!(err, None);
}

#[sqlx::test(migrations = "../../migrations")]
async fn hosts_cannot_complete_other_hosts_commands(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let b = seed(&pool, "owner").await;
    let (_, state) = app(&pool);
    let id = insert_command(&pool, &a).await;
    assert!(!state
        .hub
        .complete(&pool, b.host, id, CommandOutcome::ok(CommandData::Done))
        .await
        .unwrap());
}

#[sqlx::test(migrations = "../../migrations")]
async fn command_ids_are_unique(pool: PgPool) {
    let t = seed(&pool, "owner").await;
    let id = insert_command(&pool, &t).await;
    let dup = sqlx::query("INSERT INTO session_commands (id, org_id, session_id, host_id, kind, payload, status) VALUES ($1,$2,$3,$4,'StartSession','{}','sent')")
        .bind(id).bind(t.org).bind(t.session).bind(t.host).execute(&pool).await;
    assert!(dup.is_err());
}

#[sqlx::test(migrations = "../../migrations")]
async fn agents_cannot_inject_logs_into_foreign_sessions(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let b = seed(&pool, "owner").await;
    let (_, state) = app(&pool);
    let line = LogLine {
        ts: "t".into(),
        level: "I".into(),
        tag: "x".into(),
        message: "m".into(),
    };
    dp_api::routes::agent::handle_message(
        &state,
        b.host,
        b.org,
        AgentMessage::LogLines {
            session_id: a.session,
            lines: vec![line.clone()],
        },
    )
    .await
    .unwrap();
    let n: i64 = sqlx::query_scalar("SELECT count(*) FROM session_log_lines")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(n, 0);
    dp_api::routes::agent::handle_message(
        &state,
        a.host,
        a.org,
        AgentMessage::LogLines {
            session_id: a.session,
            lines: vec![line],
        },
    )
    .await
    .unwrap();
    let n: i64 = sqlx::query_scalar("SELECT count(*) FROM session_log_lines WHERE org_id=$1")
        .bind(a.org)
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(n, 1);
}
