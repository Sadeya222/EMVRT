//! Organization isolation and authorization integration tests.
mod common;
use axum::http::StatusCode;
use common::*;
use serde_json::json;
use sqlx::PgPool;

#[sqlx::test(migrations = "../../migrations")]
async fn users_cannot_read_other_orgs_resources(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let b = seed(&pool, "owner").await;
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;

    let (s, _) = call(
        &app,
        &ca,
        "GET",
        &format!("/v1/apps/{}", a.app),
        None,
        false,
    )
    .await;
    assert_eq!(s, StatusCode::OK);
    for uri in [
        format!("/v1/apps/{}", b.app),
        format!("/v1/sessions/{}", b.session),
        format!("/v1/sessions/{}/events", b.session),
        format!("/v1/sessions/{}/logs", b.session),
        format!("/v1/hosts/{}", b.host),
        format!("/v1/organizations/{}", b.org),
    ] {
        let (s, _) = call(&app, &ca, "GET", &uri, None, false).await;
        assert_eq!(s, StatusCode::NOT_FOUND, "{uri} must not leak across orgs");
    }
    let (_, list) = call(&app, &ca, "GET", "/v1/apps", None, false).await;
    let ids: Vec<String> = list
        .as_array()
        .unwrap()
        .iter()
        .map(|x| x["id"].as_str().unwrap().to_string())
        .collect();
    assert_eq!(ids, vec![a.app.to_string()]);
    let (_, hosts) = call(&app, &ca, "GET", "/v1/hosts", None, false).await;
    assert_eq!(hosts.as_array().unwrap().len(), 1);
}

#[sqlx::test(migrations = "../../migrations")]
async fn cannot_use_other_orgs_artifacts_or_end_their_sessions(pool: PgPool) {
    let a = seed(&pool, "developer").await;
    let b = seed(&pool, "owner").await;
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;
    let (s, _) = call(&app, &ca, "POST", "/v1/sessions",
        Some(json!({ "profile_id": "01900000-0000-7000-8000-000000000001", "app_version_id": b.version })), true).await;
    assert_eq!(s, StatusCode::NOT_FOUND);
    let (s, _) = call(
        &app,
        &ca,
        "DELETE",
        &format!("/v1/sessions/{}", b.session),
        None,
        true,
    )
    .await;
    assert_eq!(s, StatusCode::NOT_FOUND);
    let (s, _) = call(
        &app,
        &ca,
        "POST",
        &format!("/v1/apps/{}/uploads", b.app),
        Some(json!({ "file_name": "x.apk", "size_bytes": 100 })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::NOT_FOUND);
    let (s, _) = call(
        &app,
        &ca,
        "POST",
        &format!("/v1/apps/{}/versions/{}/finalize", b.app, b.version),
        None,
        true,
    )
    .await;
    assert_eq!(s, StatusCode::NOT_FOUND);
}

#[sqlx::test(migrations = "../../migrations")]
async fn roles_are_enforced(pool: PgPool) {
    let v = seed(&pool, "viewer").await;
    let d = seed(&pool, "developer").await;
    let (app, _) = app(&pool);
    let cv = login(&app, &v.email).await;
    let (s, _) = call(
        &app,
        &cv,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "nope" })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::FORBIDDEN);
    let (s, _) = call(&app, &cv, "GET", "/v1/apps", None, false).await;
    assert_eq!(s, StatusCode::OK);
    let cd = login(&app, &d.email).await;
    let (s, _) = call(
        &app,
        &cd,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "yes" })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::CREATED);
    for (m, uri, body) in [
        (
            "POST",
            "/v1/hosts/enrollment-token",
            Some(json!({ "name": "h" })),
        ),
        (
            "POST",
            "/v1/api-keys",
            Some(json!({ "name": "k", "scopes": ["apps:read"] })),
        ),
        (
            "POST",
            "/v1/auth/invites",
            Some(json!({ "email": "x@example.com", "role": "viewer" })),
        ),
        ("GET", "/v1/audit-logs", None),
    ] {
        let (s, _) = call(&app, &cd, m, uri, body, true).await;
        assert_eq!(s, StatusCode::FORBIDDEN, "developer must not access {uri}");
    }
}

#[sqlx::test(migrations = "../../migrations")]
async fn csrf_is_required_for_cookie_mutations(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;
    let (s, body) = call(
        &app,
        &ca,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "x" })),
        false,
    )
    .await;
    assert_eq!(s, StatusCode::FORBIDDEN);
    assert_eq!(body["error"]["code"], "forbidden");
    let bad = Client {
        csrf: "wrong".into(),
        cookie: ca.cookie.clone(),
        bearer: None,
    };
    let (s, _) = call(
        &app,
        &bad,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "x" })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::FORBIDDEN);
}

#[sqlx::test(migrations = "../../migrations")]
async fn api_keys_are_scoped_and_org_bound(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let b = seed(&pool, "owner").await;
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;
    let (s, created) = call(
        &app,
        &ca,
        "POST",
        "/v1/api-keys",
        Some(json!({ "name": "ci", "scopes": ["apps:read"] })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::CREATED);
    let secret = created["secret"].as_str().unwrap().to_string();
    assert!(secret.starts_with("dpk_"));
    let stored: Vec<u8> = sqlx::query_scalar("SELECT key_hash FROM api_keys WHERE id = $1::uuid")
        .bind(created["key"]["id"].as_str().unwrap())
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_ne!(stored, secret.as_bytes(), "only a hash may be stored");
    let (_, list) = call(&app, &ca, "GET", "/v1/api-keys", None, false).await;
    assert!(
        list[0].get("secret").is_none(),
        "secret must never be returned again"
    );

    let key = Client {
        cookie: String::new(),
        csrf: String::new(),
        bearer: Some(secret.clone()),
    };
    let (s, _) = call(&app, &key, "GET", "/v1/apps", None, false).await;
    assert_eq!(s, StatusCode::OK);
    let (s, _) = call(
        &app,
        &key,
        "GET",
        &format!("/v1/apps/{}", b.app),
        None,
        false,
    )
    .await;
    assert_eq!(s, StatusCode::NOT_FOUND);
    let (s, _) = call(
        &app,
        &key,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "x" })),
        false,
    )
    .await;
    assert_eq!(s, StatusCode::FORBIDDEN);
    let (s, _) = call(&app, &key, "GET", "/v1/sessions", None, false).await;
    assert_eq!(s, StatusCode::FORBIDDEN);
    let (s, _) = call(&app, &key, "GET", "/v1/api-keys", None, false).await;
    assert_eq!(s, StatusCode::FORBIDDEN);

    let (s, _) = call(
        &app,
        &ca,
        "DELETE",
        &format!("/v1/api-keys/{}", created["key"]["id"].as_str().unwrap()),
        None,
        true,
    )
    .await;
    assert_eq!(s, StatusCode::NO_CONTENT);
    let (s, _) = call(&app, &key, "GET", "/v1/apps", None, false).await;
    assert_eq!(s, StatusCode::UNAUTHORIZED);
}

#[sqlx::test(migrations = "../../migrations")]
async fn audit_logs_are_org_scoped(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    let b = seed(&pool, "owner").await;
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;
    call(
        &app,
        &ca,
        "POST",
        "/v1/apps",
        Some(json!({ "name": "audited" })),
        true,
    )
    .await;
    let cb = login(&app, &b.email).await;
    let (_, logs) = call(&app, &cb, "GET", "/v1/audit-logs", None, false).await;
    assert!(logs
        .as_array()
        .unwrap()
        .iter()
        .all(|l| l["action"] != "app.created"));
    let (_, logs) = call(&app, &ca, "GET", "/v1/audit-logs", None, false).await;
    assert!(logs
        .as_array()
        .unwrap()
        .iter()
        .any(|l| l["action"] == "app.created"));
}

#[sqlx::test(migrations = "../../migrations")]
async fn quota_is_enforced_on_session_creation(pool: PgPool) {
    let a = seed(&pool, "owner").await;
    sqlx::query("UPDATE organizations SET max_concurrent_sessions = 0 WHERE id=$1")
        .bind(a.org)
        .execute(&pool)
        .await
        .unwrap();
    let (app, _) = app(&pool);
    let ca = login(&app, &a.email).await;
    let (s, body) = call(
        &app,
        &ca,
        "POST",
        "/v1/sessions",
        Some(json!({ "profile_id": "01900000-0000-7000-8000-000000000001" })),
        true,
    )
    .await;
    assert_eq!(s, StatusCode::TOO_MANY_REQUESTS);
    assert_eq!(body["error"]["code"], "quota_exceeded");
}
