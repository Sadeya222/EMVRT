use anyhow::Context;
use dp_api::{auth, config::Config, router, spawn_background, AppState};
use sqlx::postgres::PgPoolOptions;
use std::net::SocketAddr;
use uuid::Uuid;

fn init_tracing() {
    use tracing_subscriber::EnvFilter;
    let filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("info,sqlx=warn,tower_http=info"));
    if std::env::var("LOG_FORMAT").as_deref() == Ok("json") {
        tracing_subscriber::fmt()
            .with_env_filter(filter)
            .json()
            .init();
    } else {
        tracing_subscriber::fmt().with_env_filter(filter).init();
    }
}

fn arg(args: &[String], name: &str) -> Option<String> {
    args.iter()
        .position(|a| a == name)
        .and_then(|i| args.get(i + 1))
        .cloned()
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let args: Vec<String> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        // Print the OpenAPI document (used to generate packages/api-client). Needs no DB.
        Some("openapi") => {
            println!("{}", dp_api::openapi_doc().to_pretty_json()?);
            return Ok(());
        }
        Some("bootstrap-invite") => {
            init_tracing();
            let cfg = Config::from_env()?;
            let email = arg(&args, "--email").context("--email is required")?.trim().to_lowercase();
            let org = arg(&args, "--org").unwrap_or_else(|| "My Organization".into());
            let db = PgPoolOptions::new().max_connections(2).connect(&cfg.database_url).await?;
            sqlx::migrate!("../../migrations").run(&db).await?;
            let token = auth::random_token("dpi_", 32);
            sqlx::query(
                "INSERT INTO invites (id, org_id, email, role, token_hash, bootstrap_org_name, expires_at)
                 VALUES ($1, NULL, $2, 'owner', $3, $4, now() + interval '24 hours')",
            )
            .bind(Uuid::now_v7())
            .bind(&email)
            .bind(auth::token_hash(&token))
            .bind(&org)
            .execute(&db)
            .await?;
            // Printed to stdout for the operator only; never logged.
            println!("One-time owner invite for {email} (organization \"{org}\"), valid 24h:");
            println!("{}/accept-invite?token={}", cfg.public_url, token);
            return Ok(());
        }
        Some("serve") | None => {}
        Some(other) => anyhow::bail!("unknown command {other}; use serve | openapi | bootstrap-invite --email <e> [--org <name>]"),
    }

    init_tracing();
    let cfg = Config::from_env()?;
    if cfg.is_dev() {
        tracing::warn!("APP_ENV=development: insecure cookies and local defaults are enabled. NEVER use this mode in production.");
    }
    tracing::info!(config = ?cfg, "starting device-api");
    let db = PgPoolOptions::new()
        .max_connections(20)
        .connect(&cfg.database_url)
        .await
        .context("connect database")?;
    sqlx::migrate!("../../migrations")
        .run(&db)
        .await
        .context("run migrations")?;
    let bind = cfg.bind;
    let state = AppState::new(db, cfg);
    spawn_background(state.clone());
    let app = router(state);
    let listener = tokio::net::TcpListener::bind(bind).await?;
    tracing::info!(%bind, "listening");
    axum::serve(
        listener,
        app.into_make_service_with_connect_info::<SocketAddr>(),
    )
    .with_graceful_shutdown(async {
        let _ = tokio::signal::ctrl_c().await;
    })
    .await?;
    Ok(())
}
