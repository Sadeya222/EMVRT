use crate::auth::AuthCtx;
use serde_json::Value;
use sqlx::PgExecutor;
use uuid::Uuid;

/// Record a security-sensitive action. Never put secrets in `metadata`.
pub async fn record<'e>(
    db: impl PgExecutor<'e>,
    org_id: Option<Uuid>,
    ctx: Option<&AuthCtx>,
    action: &str,
    target: Option<(&str, String)>,
    metadata: Value,
) -> Result<(), sqlx::Error> {
    let (tt, tid) = match target {
        Some((t, id)) => (Some(t), Some(id)),
        None => (None, None),
    };
    sqlx::query(
        "INSERT INTO audit_logs (id, org_id, actor_user_id, actor_api_key_id, action, target_type, target_id, ip, metadata)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
    )
    .bind(Uuid::now_v7())
    .bind(org_id)
    .bind(ctx.and_then(|c| c.user_id))
    .bind(ctx.and_then(|c| c.api_key_id))
    .bind(action)
    .bind(tt)
    .bind(tid)
    .bind(ctx.and_then(|c| c.ip.clone()))
    .bind(metadata)
    .execute(db)
    .await?;
    tracing::info!(action, org_id = ?org_id, "audit");
    Ok(())
}
