//! Drives sessions through the lifecycle by sending typed commands to the assigned agent.
use crate::error::ApiError;
use crate::storage::Audience;
use crate::AppState;
use dp_common::protocol::{CommandData, CommandKind, DeviceProfileSpec, ResourceLimits};
use dp_common::{transition, SessionState};
use dp_scheduler::{PlacementRequest, ScheduleError};
use serde_json::json;
use sqlx::{FromRow, PgPool, Postgres, Transaction};
use std::time::Duration;
use time::OffsetDateTime;
use uuid::Uuid;

/// Record a session event.
pub async fn event<'e>(
    db: impl sqlx::PgExecutor<'e>,
    org_id: Uuid,
    session_id: Uuid,
    kind: &str,
    states: Option<(SessionState, SessionState)>,
    actor: Option<Uuid>,
    payload: serde_json::Value,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "INSERT INTO session_events (id, org_id, session_id, kind, from_state, to_state, actor_user_id, payload)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
    )
    .bind(Uuid::now_v7())
    .bind(org_id)
    .bind(session_id)
    .bind(kind)
    .bind(states.map(|s| s.0.as_str()))
    .bind(states.map(|s| s.1.as_str()))
    .bind(actor)
    .bind(payload)
    .execute(db)
    .await?;
    Ok(())
}

/// Compare-and-swap state transition, validated by the shared state machine.
/// Returns Conflict if the session is no longer in `from`.
pub async fn cas_transition(
    tx: &mut Transaction<'_, Postgres>,
    org_id: Uuid,
    session_id: Uuid,
    from: SessionState,
    to: SessionState,
    actor: Option<Uuid>,
    payload: serde_json::Value,
) -> Result<(), ApiError> {
    transition(from, to).map_err(|e| ApiError::Conflict(e.to_string()))?;
    let res = sqlx::query(
        r#"UPDATE sessions SET state = $4, updated_at = now(),
              ready_at = CASE WHEN $4 = 'READY' THEN now() ELSE ready_at END,
              expires_at = CASE WHEN $4 = 'READY' THEN now() + make_interval(mins => timeout_minutes) ELSE expires_at END,
              ended_at = CASE WHEN $4 IN ('WIPED','FAILED','CANCELLED') THEN now() ELSE ended_at END
           WHERE id = $1 AND org_id = $2 AND state = $3"#,
    )
    .bind(session_id)
    .bind(org_id)
    .bind(from.as_str())
    .bind(to.as_str())
    .execute(&mut **tx)
    .await?;
    if res.rows_affected() != 1 {
        return Err(ApiError::Conflict(format!("session is no longer {from}")));
    }
    event(
        &mut **tx,
        org_id,
        session_id,
        "state",
        Some((from, to)),
        actor,
        payload,
    )
    .await?;
    Ok(())
}

async fn current_state(
    db: &PgPool,
    org_id: Uuid,
    session_id: Uuid,
) -> Result<(SessionState, Option<Uuid>, Option<Uuid>), ApiError> {
    let (s, h, d): (String, Option<Uuid>, Option<Uuid>) =
        sqlx::query_as("SELECT state, host_id, device_id FROM sessions WHERE id=$1 AND org_id=$2")
            .bind(session_id)
            .bind(org_id)
            .fetch_one(db)
            .await?;
    Ok((
        s.parse()
            .map_err(|e: String| ApiError::Internal(anyhow::anyhow!(e)))?,
        h,
        d,
    ))
}

/// Move to a terminal state exactly once, releasing scheduler capacity and recording usage in the
/// same transaction as the CAS update.
pub async fn finalize(
    state: &AppState,
    org_id: Uuid,
    session_id: Uuid,
    to: SessionState,
    reason: &str,
    actor: Option<Uuid>,
) -> Result<(), ApiError> {
    debug_assert!(to.is_terminal());
    let (from, host_id, device_id) = current_state(&state.db, org_id, session_id).await?;
    if from.is_terminal() {
        return Ok(());
    }
    let mut tx = state.db.begin().await?;
    cas_transition(
        &mut tx,
        org_id,
        session_id,
        from,
        to,
        actor,
        json!({ "reason": reason }),
    )
    .await?;
    let col = if to == SessionState::Failed {
        "failure_reason"
    } else {
        "ended_reason"
    };
    sqlx::query(&format!("UPDATE sessions SET {col} = $2 WHERE id = $1"))
        .bind(session_id)
        .bind(reason)
        .execute(&mut *tx)
        .await?;
    if let Some(h) = host_id {
        if from.holds_capacity() {
            state
                .scheduler
                .release(&mut tx, h, device_id)
                .await
                .map_err(sched_err)?;
        }
    }
    let minutes: Option<i64> = sqlx::query_scalar(
        "SELECT CEIL(EXTRACT(EPOCH FROM (ended_at - ready_at)) / 60)::bigint FROM sessions WHERE id=$1 AND ready_at IS NOT NULL",
    )
    .bind(session_id)
    .fetch_optional(&mut *tx)
    .await?
    .flatten();
    if let Some(m) = minutes {
        sqlx::query("INSERT INTO usage_events (id, org_id, session_id, kind, quantity) VALUES ($1,$2,$3,'session_minutes',$4)")
            .bind(Uuid::now_v7())
            .bind(org_id)
            .bind(session_id)
            .bind(m.max(1))
            .execute(&mut *tx)
            .await?;
    }
    crate::audit::record(
        &mut *tx,
        Some(org_id),
        None,
        "session.ended",
        Some(("session", session_id.to_string())),
        json!({ "final_state": to.as_str(), "reason": reason }),
    )
    .await?;
    tx.commit().await?;
    Ok(())
}

fn sched_err(e: ScheduleError) -> ApiError {
    match e {
        ScheduleError::QuotaExceeded { .. } => ApiError::QuotaExceeded(e.to_string()),
        ScheduleError::NoCapacity(_) => ApiError::Unavailable(e.to_string()),
        ScheduleError::OrgNotFound => ApiError::NotFound,
        ScheduleError::Db(d) => d.into(),
    }
}

/// Try to place a QUEUED session. Returns Ok(true) if assigned.
pub async fn try_assign(
    state: &AppState,
    org_id: Uuid,
    session_id: Uuid,
) -> Result<bool, ApiError> {
    let (profile_id, slug): (Uuid, String) = sqlx::query_as(
        "SELECT p.id, p.slug FROM sessions s JOIN device_profiles p ON p.id = s.profile_id WHERE s.id=$1 AND s.org_id=$2",
    )
    .bind(session_id)
    .bind(org_id)
    .fetch_one(&state.db)
    .await?;
    let mut tx = state.db.begin().await?;
    let req = PlacementRequest {
        org_id,
        session_id,
        profile_id,
        profile_slug: slug,
    };
    match state.scheduler.place(&mut tx, &req).await {
        Ok(p) => {
            sqlx::query(
                "UPDATE sessions SET host_id=$2, device_id=$3 WHERE id=$1 AND state='QUEUED'",
            )
            .bind(session_id)
            .bind(p.host_id)
            .bind(p.device_id)
            .execute(&mut *tx)
            .await?;
            cas_transition(
                &mut tx,
                org_id,
                session_id,
                SessionState::Queued,
                SessionState::Assigned,
                None,
                json!({ "host_id": p.host_id, "warm_device": p.device_id }),
            )
            .await?;
            tx.commit().await?;
            spawn_flow(state.clone(), org_id, session_id);
            Ok(true)
        }
        Err(ScheduleError::NoCapacity(_)) => {
            tx.rollback().await?;
            Ok(false)
        }
        Err(e) => {
            tx.rollback().await?;
            Err(sched_err(e))
        }
    }
}

#[derive(FromRow)]
struct FlowInfo {
    host_id: Uuid,
    api_level: i32,
    abi: String,
    screen_width: i32,
    screen_height: i32,
    density: i32,
    cpu_cores: i32,
    ram_mb: i32,
    disk_mb: i32,
    slug: String,
    image_key: String,
    object_key: Option<String>,
    sha256: Option<String>,
    size_bytes: Option<i64>,
    package_name: Option<String>,
}

pub fn spawn_flow(state: AppState, org_id: Uuid, session_id: Uuid) {
    tokio::spawn(async move {
        if let Err(e) = run_flow(&state, org_id, session_id).await {
            tracing::warn!(%session_id, error = %e, "session flow failed");
            let still_active = matches!(current_state(&state.db, org_id, session_id).await, Ok((s, _, _)) if !s.is_terminal() && s != SessionState::Ending);
            if still_active {
                teardown(&state, org_id, session_id).await;
                let _ = finalize(
                    &state,
                    org_id,
                    session_id,
                    SessionState::Failed,
                    &e.to_string(),
                    None,
                )
                .await;
            }
        }
    });
}

const BOOT_TIMEOUT: Duration = Duration::from_secs(600);

async fn step(
    state: &AppState,
    org_id: Uuid,
    session_id: Uuid,
    from: SessionState,
    to: SessionState,
) -> Result<(), ApiError> {
    let mut tx = state.db.begin().await?;
    cas_transition(&mut tx, org_id, session_id, from, to, None, json!({})).await?;
    tx.commit().await?;
    Ok(())
}

async fn command(
    state: &AppState,
    org_id: Uuid,
    host_id: Uuid,
    session_id: Uuid,
    kind: CommandKind,
    timeout: Duration,
) -> Result<Option<CommandData>, ApiError> {
    let name = kind.name();
    let out = state
        .hub
        .request(&state.db, org_id, host_id, session_id, kind, timeout)
        .await?;
    if out.ok {
        Ok(out.data)
    } else {
        Err(ApiError::Unavailable(format!(
            "{name} failed: {}",
            out.error.unwrap_or_default()
        )))
    }
}

async fn run_flow(state: &AppState, org_id: Uuid, session_id: Uuid) -> Result<(), ApiError> {
    let info: FlowInfo = sqlx::query_as(
        r#"SELECT s.host_id AS host_id, p.api_level, p.abi, p.screen_width, p.screen_height, p.density, p.cpu_cores, p.ram_mb, p.disk_mb,
                  p.slug, p.image_key, v.object_key AS object_key, v.sha256, v.size_bytes, v.package_name
           FROM sessions s
           JOIN device_profiles p ON p.id = s.profile_id
           LEFT JOIN app_versions v ON v.id = s.app_version_id AND v.org_id = s.org_id AND v.status = 'approved'
           WHERE s.id = $1 AND s.org_id = $2 AND s.host_id IS NOT NULL"#,
    )
    .bind(session_id)
    .bind(org_id)
    .fetch_one(&state.db)
    .await?;
    let host = info.host_id;
    let profile = DeviceProfileSpec {
        slug: info.slug.clone(),
        api_level: info.api_level,
        abi: info.abi.clone(),
        screen_width: info.screen_width,
        screen_height: info.screen_height,
        density: info.density,
        image_key: info.image_key.clone(),
    };
    step(
        state,
        org_id,
        session_id,
        SessionState::Assigned,
        SessionState::Booting,
    )
    .await?;
    command(
        state,
        org_id,
        host,
        session_id,
        CommandKind::PrepareDevice {
            profile: profile.clone(),
        },
        BOOT_TIMEOUT,
    )
    .await?;
    let limits = ResourceLimits {
        cpus: info.cpu_cores as u32,
        memory_mb: info.ram_mb as u32,
        disk_mb: info.disk_mb as u32,
    };
    command(
        state,
        org_id,
        host,
        session_id,
        CommandKind::StartEmulator { profile, limits },
        BOOT_TIMEOUT,
    )
    .await?;

    let mut from = SessionState::Booting;
    if let (Some(key), Some(sha), Some(size), Some(pkg)) = (
        info.object_key,
        info.sha256,
        info.size_bytes,
        info.package_name,
    ) {
        step(
            state,
            org_id,
            session_id,
            SessionState::Booting,
            SessionState::Installing,
        )
        .await?;
        from = SessionState::Installing;
        // Short-lived (5 min) URL for the approved artifact only.
        let url = state.storage.presign(
            Audience::Agent,
            "GET",
            &key,
            300,
            None,
            OffsetDateTime::now_utc(),
        )?;
        command(
            state,
            org_id,
            host,
            session_id,
            CommandKind::InstallApp {
                download_url: url,
                sha256: sha,
                size_bytes: size as u64,
                package_name: pkg,
            },
            Duration::from_secs(300),
        )
        .await?;
    }
    let data = command(
        state,
        org_id,
        host,
        session_id,
        CommandKind::StartSession {},
        Duration::from_secs(60),
    )
    .await?;
    if let Some(CommandData::Stream { info }) = data {
        sqlx::query("UPDATE sessions SET stream_kind=$2, stream_endpoint=$3 WHERE id=$1")
            .bind(session_id)
            .bind(&info.kind)
            .bind(&info.endpoint)
            .execute(&state.db)
            .await?;
    }
    step(state, org_id, session_id, from, SessionState::Ready).await?;
    if let Err(e) = command(
        state,
        org_id,
        host,
        session_id,
        CommandKind::StartLogcat {},
        Duration::from_secs(30),
    )
    .await
    {
        event(
            &state.db,
            org_id,
            session_id,
            "warning",
            None,
            None,
            json!({ "message": format!("logcat unavailable: {e}") }),
        )
        .await?;
    }
    Ok(())
}

/// Best-effort StopSession; the agent destroys the container and its ephemeral volume.
async fn teardown(state: &AppState, org_id: Uuid, session_id: Uuid) -> bool {
    let Ok((_, Some(host), _)) = current_state(&state.db, org_id, session_id).await else {
        return false;
    };
    match state
        .hub
        .request(
            &state.db,
            org_id,
            host,
            session_id,
            CommandKind::StopSession {
                reason: "teardown".into(),
            },
            Duration::from_secs(120),
        )
        .await
    {
        Ok(o) => o.ok,
        Err(_) => false,
    }
}

/// End a session (user action, timeout, admin). Idempotent.
pub async fn end_session(
    state: &AppState,
    org_id: Uuid,
    session_id: Uuid,
    reason: &str,
    actor: Option<Uuid>,
) -> Result<SessionState, ApiError> {
    let (cur, _, _) = current_state(&state.db, org_id, session_id).await?;
    match cur {
        s if s.is_terminal() || s == SessionState::Ending => Ok(s),
        SessionState::Requested | SessionState::Queued => {
            finalize(
                state,
                org_id,
                session_id,
                SessionState::Cancelled,
                reason,
                actor,
            )
            .await?;
            Ok(SessionState::Cancelled)
        }
        s => {
            let mut tx = state.db.begin().await?;
            cas_transition(
                &mut tx,
                org_id,
                session_id,
                s,
                SessionState::Ending,
                actor,
                json!({ "reason": reason }),
            )
            .await?;
            sqlx::query("UPDATE sessions SET ended_reason=$2 WHERE id=$1")
                .bind(session_id)
                .bind(reason)
                .execute(&mut *tx)
                .await?;
            tx.commit().await?;
            let st = state.clone();
            let reason = reason.to_string();
            tokio::spawn(async move {
                let wiped = teardown(&st, org_id, session_id).await;
                let (to, why) = if wiped {
                    (SessionState::Wiped, reason)
                } else {
                    (SessionState::Failed, "wipe_unconfirmed".to_string())
                };
                if let Err(e) = finalize(&st, org_id, session_id, to, &why, None).await {
                    tracing::error!(%session_id, error = %e, "finalize failed");
                }
            });
            Ok(SessionState::Ending)
        }
    }
}
