//! Minimal S3 (MinIO) client: AWS SigV4 query-string presigning plus a few server-side calls
//! made through presigned URLs. Avoids pulling the full AWS SDK into the control plane.
use crate::config::S3Config;
use anyhow::{bail, Context};
use futures::StreamExt;
use hmac::{Hmac, Mac};
use sha2::{Digest, Sha256};
use time::OffsetDateTime;

type HmacSha256 = Hmac<Sha256>;

pub struct Storage {
    cfg: S3Config,
    http: reqwest::Client,
}

#[derive(Clone, Copy)]
pub enum Audience {
    Internal,
    Browser,
    Agent,
}

fn uri_encode(s: &str, encode_slash: bool) -> String {
    let mut out = String::with_capacity(s.len());
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            b'/' if !encode_slash => out.push('/'),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

fn hmac(key: &[u8], msg: &[u8]) -> Vec<u8> {
    let mut m = HmacSha256::new_from_slice(key).expect("hmac key");
    m.update(msg);
    m.finalize().into_bytes().to_vec()
}

impl Storage {
    pub fn new(cfg: S3Config) -> Self {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(120))
            .build()
            .expect("reqwest client");
        Self { cfg, http }
    }

    pub fn bucket(&self) -> &str {
        &self.cfg.bucket
    }

    /// Produce a SigV4 presigned URL. If `content_length` is set it becomes a signed header, so the
    /// uploader cannot send a different number of bytes than were declared and size-checked.
    pub fn presign(
        &self,
        audience: Audience,
        method: &str,
        key: &str,
        expires_secs: u64,
        content_length: Option<u64>,
        now: OffsetDateTime,
    ) -> anyhow::Result<String> {
        let endpoint = match audience {
            Audience::Internal => &self.cfg.internal_endpoint,
            Audience::Browser => &self.cfg.public_endpoint,
            Audience::Agent => &self.cfg.agent_endpoint,
        };
        let url = url::Url::parse(endpoint).context("invalid S3 endpoint")?;
        let host = match (url.host_str(), url.port()) {
            (Some(h), Some(p)) => format!("{h}:{p}"),
            (Some(h), None) => h.to_string(),
            _ => bail!("S3 endpoint has no host"),
        };
        let base_path = url.path().trim_end_matches('/');
        let canonical_uri = format!(
            "{}/{}/{}",
            base_path,
            uri_encode(&self.cfg.bucket, true),
            uri_encode(key, false)
        );
        let date = format!("{:04}{:02}{:02}", now.year(), now.month() as u8, now.day());
        let amz_date = format!(
            "{date}T{:02}{:02}{:02}Z",
            now.hour(),
            now.minute(),
            now.second()
        );
        let scope = format!("{date}/{}/s3/aws4_request", self.cfg.region);
        let signed_headers = if content_length.is_some() {
            "content-length;host"
        } else {
            "host"
        };
        let mut params = [
            (
                "X-Amz-Algorithm".to_string(),
                "AWS4-HMAC-SHA256".to_string(),
            ),
            (
                "X-Amz-Credential".to_string(),
                format!("{}/{}", self.cfg.access_key, scope),
            ),
            ("X-Amz-Date".to_string(), amz_date.clone()),
            (
                "X-Amz-Expires".to_string(),
                expires_secs.min(7 * 24 * 3600).to_string(),
            ),
            (
                "X-Amz-SignedHeaders".to_string(),
                signed_headers.to_string(),
            ),
        ];
        params.sort();
        let query = params
            .iter()
            .map(|(k, v)| format!("{}={}", uri_encode(k, true), uri_encode(v, true)))
            .collect::<Vec<_>>()
            .join("&");
        let canonical_headers = match content_length {
            Some(len) => format!("content-length:{len}\nhost:{host}\n"),
            None => format!("host:{host}\n"),
        };
        let canonical_request =
            format!("{method}\n{canonical_uri}\n{query}\n{canonical_headers}\n{signed_headers}\nUNSIGNED-PAYLOAD");
        let string_to_sign = format!(
            "AWS4-HMAC-SHA256\n{amz_date}\n{scope}\n{}",
            hex::encode(Sha256::digest(canonical_request.as_bytes()))
        );
        let k_date = hmac(
            format!("AWS4{}", self.cfg.secret_key).as_bytes(),
            date.as_bytes(),
        );
        let k_region = hmac(&k_date, self.cfg.region.as_bytes());
        let k_service = hmac(&k_region, b"s3");
        let k_signing = hmac(&k_service, b"aws4_request");
        let signature = hex::encode(hmac(&k_signing, string_to_sign.as_bytes()));
        Ok(format!(
            "{}://{}{}?{}&X-Amz-Signature={}",
            url.scheme(),
            host,
            canonical_uri,
            query,
            signature
        ))
    }

    /// Returns the object size, or None if it does not exist.
    pub async fn head(&self, key: &str) -> anyhow::Result<Option<u64>> {
        let url = self.presign(
            Audience::Internal,
            "HEAD",
            key,
            60,
            None,
            OffsetDateTime::now_utc(),
        )?;
        let res = self.http.head(url).send().await?;
        if res.status() == reqwest::StatusCode::NOT_FOUND {
            return Ok(None);
        }
        if !res.status().is_success() {
            bail!("HEAD object failed with {}", res.status());
        }
        Ok(res.content_length())
    }

    /// Download an object, aborting once more than `max_bytes` have been received.
    pub async fn get_limited(&self, key: &str, max_bytes: u64) -> anyhow::Result<Vec<u8>> {
        let url = self.presign(
            Audience::Internal,
            "GET",
            key,
            120,
            None,
            OffsetDateTime::now_utc(),
        )?;
        let res = self.http.get(url).send().await?;
        if !res.status().is_success() {
            bail!("GET object failed with {}", res.status());
        }
        let mut out = Vec::new();
        let mut stream = res.bytes_stream();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            if out.len() as u64 + chunk.len() as u64 > max_bytes {
                bail!("object exceeds {max_bytes} bytes");
            }
            out.extend_from_slice(&chunk);
        }
        Ok(out)
    }

    pub async fn delete(&self, key: &str) -> anyhow::Result<()> {
        let url = self.presign(
            Audience::Internal,
            "DELETE",
            key,
            60,
            None,
            OffsetDateTime::now_utc(),
        )?;
        let res = self.http.delete(url).send().await?;
        if !res.status().is_success() && res.status() != reqwest::StatusCode::NOT_FOUND {
            bail!("DELETE object failed with {}", res.status());
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn presign_matches_aws_reference_shape() {
        let s = Storage::new(S3Config {
            internal_endpoint: "http://minio:9000".into(),
            public_endpoint: "https://s3.example.com".into(),
            agent_endpoint: "https://s3.example.com".into(),
            region: "us-east-1".into(),
            bucket: "apks".into(),
            access_key: "AKIDEXAMPLE".into(),
            secret_key: "secret".into(),
        });
        let now = time::macros::datetime!(2025-01-02 03:04:05 UTC);
        let u = s
            .presign(
                Audience::Browser,
                "PUT",
                "orgs/a b/x.apk",
                900,
                Some(10),
                now,
            )
            .unwrap();
        assert!(u.starts_with("https://s3.example.com/apks/orgs/a%20b/x.apk?"));
        assert!(u.contains("X-Amz-Date=20250102T030405Z"));
        assert!(u.contains("X-Amz-SignedHeaders=content-length%3Bhost"));
        assert!(
            u.contains("X-Amz-Credential=AKIDEXAMPLE%2F20250102%2Fus-east-1%2Fs3%2Faws4_request")
        );
        let sig = u.rsplit("X-Amz-Signature=").next().unwrap();
        assert_eq!(sig.len(), 64);
        // Deterministic for identical inputs; different for a different host.
        assert_eq!(
            u,
            s.presign(
                Audience::Browser,
                "PUT",
                "orgs/a b/x.apk",
                900,
                Some(10),
                now
            )
            .unwrap()
        );
        let internal = s
            .presign(
                Audience::Internal,
                "PUT",
                "orgs/a b/x.apk",
                900,
                Some(10),
                now,
            )
            .unwrap();
        assert!(internal.starts_with("http://minio:9000/apks/"));
        assert_ne!(internal.rsplit('=').next(), u.rsplit('=').next());
    }
}
