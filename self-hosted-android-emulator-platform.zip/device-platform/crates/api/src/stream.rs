//! StreamProvider abstraction. The control plane never proxies media. It either hands out a
//! short-lived token for a secure node ingress, or explains why streaming is unavailable.
use crate::config::{Config, StreamMode};
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use time::OffsetDateTime;
use utoipa::ToSchema;
use uuid::Uuid;

pub const STREAM_TOKEN_TTL_SECS: i64 = 300;

#[derive(Debug, Clone, Serialize, ToSchema)]
pub struct StreamAccess {
    /// `fake`, `local-dev` or `gateway`.
    pub provider: String,
    /// URL to embed (iframe). Contains only a short-lived token, never long-lived credentials.
    pub url: Option<String>,
    #[serde(with = "time::serde::rfc3339")]
    pub expires_at: OffsetDateTime,
}

pub struct StreamContext<'a> {
    pub org_id: Uuid,
    pub session_id: Uuid,
    pub host_id: Uuid,
    pub host_adapter: &'a str,
    pub host_stream_base_url: Option<&'a str>,
}

pub enum StreamDecision {
    Available(StreamAccess),
    Unavailable {
        message: String,
        instructions: Vec<String>,
    },
}

pub trait StreamProvider: Send + Sync {
    fn name(&self) -> &'static str;
    fn issue(&self, ctx: &StreamContext<'_>, now: OffsetDateTime) -> StreamDecision;
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct StreamClaims {
    pub sid: Uuid,
    pub hid: Uuid,
    pub oid: Uuid,
    pub exp: i64,
}

pub fn sign_token(secret: &[u8], claims: &StreamClaims) -> String {
    let payload = URL_SAFE_NO_PAD.encode(serde_json::to_vec(claims).expect("claims"));
    let mut mac = Hmac::<Sha256>::new_from_slice(secret).expect("key");
    mac.update(payload.as_bytes());
    format!(
        "{payload}.{}",
        URL_SAFE_NO_PAD.encode(mac.finalize().into_bytes())
    )
}

pub fn verify_token(secret: &[u8], token: &str, now: OffsetDateTime) -> Option<StreamClaims> {
    let (payload, sig) = token.split_once('.')?;
    let sig = URL_SAFE_NO_PAD.decode(sig).ok()?;
    let mut mac = Hmac::<Sha256>::new_from_slice(secret).ok()?;
    mac.update(payload.as_bytes());
    mac.verify_slice(&sig).ok()?; // constant-time
    let claims: StreamClaims =
        serde_json::from_slice(&URL_SAFE_NO_PAD.decode(payload).ok()?).ok()?;
    (claims.exp > now.unix_timestamp()).then_some(claims)
}

fn is_private_url(u: &str) -> bool {
    let Ok(url) = url::Url::parse(u) else {
        return false;
    };
    match url.host() {
        Some(url::Host::Domain(d)) => {
            d == "localhost" || d.ends_with(".local") || d.ends_with(".internal")
        }
        Some(url::Host::Ipv4(ip)) => ip.is_loopback() || ip.is_private(),
        Some(url::Host::Ipv6(ip)) => ip.is_loopback(),
        None => false,
    }
}

/// FakeEmulatorAdapter hosts: the dashboard renders a simulated display from real screenshots.
pub struct FakeStreamProvider;
impl StreamProvider for FakeStreamProvider {
    fn name(&self) -> &'static str {
        "fake"
    }
    fn issue(&self, _ctx: &StreamContext<'_>, now: OffsetDateTime) -> StreamDecision {
        StreamDecision::Available(StreamAccess {
            provider: "fake".into(),
            url: None,
            expires_at: now + time::Duration::seconds(STREAM_TOKEN_TTL_SECS),
        })
    }
}

/// Gateway provider: the host's node ingress (Caddy forward_auth -> /v1/stream/verify) validates
/// the short-lived token before proxying emulator signaling traffic.
pub struct GatewayStreamProvider {
    pub secret: Vec<u8>,
    pub allow_private: bool,
}
impl StreamProvider for GatewayStreamProvider {
    fn name(&self) -> &'static str {
        if self.allow_private {
            "local-dev"
        } else {
            "gateway"
        }
    }
    fn issue(&self, ctx: &StreamContext<'_>, now: OffsetDateTime) -> StreamDecision {
        let Some(base) = ctx.host_stream_base_url else {
            return unavailable(
                "This host has no stream ingress configured.",
                &["Set AGENT_STREAM_BASE_URL on the host agent (e.g. https://node1.example.com).",
                  "Deploy infra/node-ingress/Caddyfile on the host so stream traffic is token-checked."],
            );
        };
        let secure = base.starts_with("https://");
        if !secure && !(self.allow_private && is_private_url(base)) {
            return unavailable(
                "The host stream ingress is not served over HTTPS.",
                &[
                    "Public streaming requires TLS on the node ingress.",
                    "Use STREAM_MODE=local-dev only for loopback/private development hosts.",
                ],
            );
        }
        let exp = now + time::Duration::seconds(STREAM_TOKEN_TTL_SECS);
        let token = sign_token(
            &self.secret,
            &StreamClaims {
                sid: ctx.session_id,
                hid: ctx.host_id,
                oid: ctx.org_id,
                exp: exp.unix_timestamp(),
            },
        );
        StreamDecision::Available(StreamAccess {
            provider: self.name().into(),
            url: Some(format!(
                "{}/sessions/{}/?dp_token={}",
                base.trim_end_matches('/'),
                ctx.session_id,
                token
            )),
            expires_at: exp,
        })
    }
}

pub struct DisabledStreamProvider;
impl StreamProvider for DisabledStreamProvider {
    fn name(&self) -> &'static str {
        "disabled"
    }
    fn issue(&self, _ctx: &StreamContext<'_>, _now: OffsetDateTime) -> StreamDecision {
        unavailable(
            "Browser streaming is not configured for this deployment.",
            &["Set STREAM_MODE=gateway on the API and STREAM_TOKEN_SECRET (shared with the node ingress).",
              "On each emulator host, run infra/node-ingress (Caddy + TLS) and set AGENT_STREAM_BASE_URL.",
              "Plan TURN/STUN for WebRTC if browsers and hosts are on different networks.",
              "See docs/emulator-integration.md#streaming."],
        )
    }
}

fn unavailable(message: &str, instructions: &[&str]) -> StreamDecision {
    StreamDecision::Unavailable {
        message: message.into(),
        instructions: instructions.iter().map(|s| s.to_string()).collect(),
    }
}

/// Select the provider for a given host.
pub fn provider_for(cfg: &Config, host_adapter: &str) -> Box<dyn StreamProvider> {
    if host_adapter == "fake" {
        return Box::new(FakeStreamProvider);
    }
    match cfg.stream_mode {
        StreamMode::Disabled => Box::new(DisabledStreamProvider),
        StreamMode::LocalDev if cfg.is_dev() => Box::new(GatewayStreamProvider {
            secret: cfg.stream_token_secret.clone(),
            allow_private: true,
        }),
        StreamMode::LocalDev => Box::new(DisabledStreamProvider),
        StreamMode::Gateway => Box::new(GatewayStreamProvider {
            secret: cfg.stream_token_secret.clone(),
            allow_private: false,
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ctx(base: Option<&str>) -> StreamContext<'_> {
        StreamContext {
            org_id: Uuid::nil(),
            session_id: Uuid::now_v7(),
            host_id: Uuid::nil(),
            host_adapter: "android-emulator",
            host_stream_base_url: base,
        }
    }

    #[test]
    fn token_roundtrip_and_expiry() {
        let now = OffsetDateTime::now_utc();
        let c = StreamClaims {
            sid: Uuid::nil(),
            hid: Uuid::nil(),
            oid: Uuid::nil(),
            exp: now.unix_timestamp() + 60,
        };
        let t = sign_token(b"k", &c);
        assert_eq!(verify_token(b"k", &t, now), Some(c));
        assert!(verify_token(b"other", &t, now).is_none());
        assert!(verify_token(b"k", &t, now + time::Duration::seconds(61)).is_none());
        let mut tampered = t.clone();
        tampered.insert(3, 'x');
        assert!(verify_token(b"k", &tampered, now).is_none());
    }

    #[test]
    fn gateway_requires_https() {
        let p = GatewayStreamProvider {
            secret: b"k".to_vec(),
            allow_private: false,
        };
        let now = OffsetDateTime::now_utc();
        assert!(matches!(
            p.issue(&ctx(Some("http://node.example.com")), now),
            StreamDecision::Unavailable { .. }
        ));
        assert!(matches!(
            p.issue(&ctx(None), now),
            StreamDecision::Unavailable { .. }
        ));
        match p.issue(&ctx(Some("https://node.example.com")), now) {
            StreamDecision::Available(a) => {
                let url = a.url.unwrap();
                assert!(url.contains("dp_token="));
                assert!(a.expires_at <= now + time::Duration::seconds(STREAM_TOKEN_TTL_SECS));
            }
            _ => panic!("expected available"),
        }
    }

    #[test]
    fn local_dev_allows_private_only() {
        let p = GatewayStreamProvider {
            secret: b"k".to_vec(),
            allow_private: true,
        };
        let now = OffsetDateTime::now_utc();
        assert!(matches!(
            p.issue(&ctx(Some("http://192.168.1.20:8443")), now),
            StreamDecision::Available(_)
        ));
        assert!(matches!(
            p.issue(&ctx(Some("http://8.8.8.8")), now),
            StreamDecision::Unavailable { .. }
        ));
    }
}
