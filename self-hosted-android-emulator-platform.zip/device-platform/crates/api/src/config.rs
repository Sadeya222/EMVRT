use anyhow::{bail, Context};
use std::net::SocketAddr;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppEnv {
    Development,
    Production,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StreamMode {
    Disabled,
    LocalDev,
    Gateway,
}

#[derive(Clone)]
pub struct S3Config {
    /// Endpoint the API itself uses (e.g. http://minio:9000 inside compose).
    pub internal_endpoint: String,
    /// Endpoint embedded in presigned URLs handed to browsers.
    pub public_endpoint: String,
    /// Endpoint embedded in presigned URLs handed to host agents.
    pub agent_endpoint: String,
    pub region: String,
    pub bucket: String,
    pub access_key: String,
    pub secret_key: String,
}

impl std::fmt::Debug for S3Config {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // Never print credentials.
        f.debug_struct("S3Config")
            .field("internal_endpoint", &self.internal_endpoint)
            .field("public_endpoint", &self.public_endpoint)
            .field("bucket", &self.bucket)
            .finish_non_exhaustive()
    }
}

#[derive(Clone)]
pub struct Config {
    pub env: AppEnv,
    pub bind: SocketAddr,
    pub database_url: String,
    pub public_url: String,
    pub cors_origins: Vec<String>,
    pub cookie_secure: bool,
    pub trust_proxy: bool,
    pub s3: S3Config,
    pub stream_mode: StreamMode,
    pub stream_token_secret: Vec<u8>,
    pub max_apk_bytes: u64,
    pub auth_session_hours: i64,
}

impl std::fmt::Debug for Config {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Config")
            .field("env", &self.env)
            .field("bind", &self.bind)
            .field("public_url", &self.public_url)
            .field("cors_origins", &self.cors_origins)
            .field("cookie_secure", &self.cookie_secure)
            .field("stream_mode", &self.stream_mode)
            .field("s3", &self.s3)
            .finish_non_exhaustive()
    }
}

fn var(name: &str) -> anyhow::Result<String> {
    std::env::var(name).with_context(|| format!("missing required environment variable {name}"))
}
fn var_or(name: &str, default: &str) -> String {
    std::env::var(name).unwrap_or_else(|_| default.to_string())
}

impl Config {
    pub fn from_env() -> anyhow::Result<Self> {
        let env = match var_or("APP_ENV", "development").as_str() {
            "production" => AppEnv::Production,
            "development" => AppEnv::Development,
            other => bail!("APP_ENV must be development or production, got {other}"),
        };
        let public_url = var("PUBLIC_URL")?;
        let s3_public = var("S3_PUBLIC_ENDPOINT")?;
        let cfg = Config {
            env,
            bind: var_or("API_BIND", "0.0.0.0:8081")
                .parse()
                .context("API_BIND")?,
            database_url: var("DATABASE_URL")?,
            cors_origins: var_or("CORS_ALLOWED_ORIGINS", &public_url)
                .split(',')
                .map(|s| s.trim().trim_end_matches('/').to_string())
                .filter(|s| !s.is_empty())
                .collect(),
            public_url: public_url.trim_end_matches('/').to_string(),
            cookie_secure: var_or(
                "COOKIE_SECURE",
                if env == AppEnv::Production {
                    "true"
                } else {
                    "false"
                },
            ) == "true",
            trust_proxy: var_or("TRUST_PROXY", "false") == "true",
            s3: S3Config {
                internal_endpoint: var("S3_ENDPOINT")?,
                agent_endpoint: var_or("S3_AGENT_ENDPOINT", &s3_public),
                public_endpoint: s3_public,
                region: var_or("S3_REGION", "us-east-1"),
                bucket: var("S3_BUCKET")?,
                access_key: var("S3_ACCESS_KEY")?,
                secret_key: var("S3_SECRET_KEY")?,
            },
            stream_mode: match var_or("STREAM_MODE", "disabled").as_str() {
                "gateway" => StreamMode::Gateway,
                "local-dev" => StreamMode::LocalDev,
                "disabled" => StreamMode::Disabled,
                other => bail!("STREAM_MODE must be disabled, local-dev or gateway, got {other}"),
            },
            stream_token_secret: var("STREAM_TOKEN_SECRET")?.into_bytes(),
            max_apk_bytes: var_or("MAX_APK_BYTES", "209715200")
                .parse()
                .context("MAX_APK_BYTES")?,
            auth_session_hours: var_or("AUTH_SESSION_HOURS", "12")
                .parse()
                .context("AUTH_SESSION_HOURS")?,
        };
        cfg.validate()?;
        Ok(cfg)
    }

    /// Refuse to start with unsafe settings in production.
    pub fn validate(&self) -> anyhow::Result<()> {
        if self.stream_token_secret.len() < 32 {
            bail!("STREAM_TOKEN_SECRET must be at least 32 bytes");
        }
        if self.cors_origins.iter().any(|o| o == "*") {
            bail!("wildcard CORS is not supported; list explicit origins");
        }
        if self.env == AppEnv::Production {
            if !self.cookie_secure {
                bail!("COOKIE_SECURE must be true in production");
            }
            if !self.public_url.starts_with("https://") {
                bail!("PUBLIC_URL must use https:// in production");
            }
            if self.stream_mode == StreamMode::LocalDev {
                bail!("STREAM_MODE=local-dev is not allowed in production");
            }
            let weak = ["minioadmin", "changeme", "password", "dev-only-unsafe"];
            if weak
                .iter()
                .any(|w| self.s3.secret_key.contains(w) || self.s3.access_key == *w)
            {
                bail!("refusing to start with default/unsafe S3 credentials in production");
            }
            if String::from_utf8_lossy(&self.stream_token_secret).contains("dev-only-unsafe") {
                bail!("refusing to start with the development STREAM_TOKEN_SECRET in production");
            }
        }
        Ok(())
    }

    pub fn is_dev(&self) -> bool {
        self.env == AppEnv::Development
    }

    /// Deterministic configuration for tests (never used by the binary).
    pub fn for_tests(database_url: &str) -> Self {
        Config {
            env: AppEnv::Development,
            bind: "127.0.0.1:0".parse().unwrap(),
            database_url: database_url.into(),
            public_url: "http://localhost:8080".into(),
            cors_origins: vec!["http://localhost:8080".into()],
            cookie_secure: false,
            trust_proxy: false,
            s3: S3Config {
                internal_endpoint: "http://127.0.0.1:9000".into(),
                public_endpoint: "http://localhost:9000".into(),
                agent_endpoint: "http://localhost:9000".into(),
                region: "us-east-1".into(),
                bucket: "test".into(),
                access_key: "test-access".into(),
                secret_key: "test-secret".into(),
            },
            stream_mode: StreamMode::Disabled,
            stream_token_secret: b"test-stream-secret-test-stream-secret!!".to_vec(),
            max_apk_bytes: 50 * 1024 * 1024,
            auth_session_hours: 12,
        }
    }
}
