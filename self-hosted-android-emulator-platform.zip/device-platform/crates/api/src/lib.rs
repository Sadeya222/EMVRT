//! Device Platform control-plane API.
pub mod audit;
pub mod auth;
pub mod config;
pub mod error;
pub mod hub;
pub mod orchestrator;
pub mod ratelimit;
pub mod routes;
pub mod storage;
pub mod stream;

use axum::http::{header, HeaderName, HeaderValue, Method};
use axum::response::{Html, IntoResponse};
use axum::routing::{delete, get, patch, post};
use axum::{Json, Router};
use config::Config;
use dp_common::SessionState;
use dp_scheduler::{PgScheduler, Scheduler};
use sqlx::PgPool;
use std::sync::Arc;
use std::time::Duration;
use tower_http::cors::{AllowOrigin, CorsLayer};
use tower_http::limit::RequestBodyLimitLayer;
use tower_http::request_id::{MakeRequestUuid, PropagateRequestIdLayer, SetRequestIdLayer};
use tower_http::set_header::SetResponseHeaderLayer;
use tower_http::trace::TraceLayer;
use utoipa::OpenApi;
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
    pub cfg: Arc<Config>,
    pub storage: Arc<storage::Storage>,
    pub hub: Arc<hub::AgentHub>,
    pub limiter: Arc<ratelimit::RateLimiter>,
    pub scheduler: Arc<dyn Scheduler>,
}

impl AppState {
    pub fn new(db: PgPool, cfg: Config) -> Self {
        let storage = Arc::new(storage::Storage::new(cfg.s3.clone()));
        Self {
            db,
            cfg: Arc::new(cfg),
            storage,
            hub: Arc::new(hub::AgentHub::default()),
            limiter: Arc::new(ratelimit::RateLimiter::default()),
            scheduler: Arc::new(PgScheduler),
        }
    }
}

#[derive(OpenApi)]
#[openapi(
    info(title = "Device Platform API", version = "0.1.0", description = "Self-hosted Android emulator platform control plane. Cookie-authenticated mutations require the X-CSRF-Token header; API keys use `Authorization: Bearer dpk_…`."),
    paths(
        routes::misc::health,
        routes::auth::login, routes::auth::logout, routes::auth::me, routes::auth::create_invite, routes::auth::invite_info, routes::auth::accept_invite,
        routes::orgs::list, routes::orgs::create, routes::orgs::get, routes::orgs::activate, routes::orgs::members, routes::orgs::update_settings,
        routes::apps::list, routes::apps::create, routes::apps::get, routes::apps::create_upload, routes::apps::finalize,
        routes::misc::device_profiles,
        routes::hosts::list, routes::hosts::get, routes::hosts::enrollment_token,
        routes::sessions::create, routes::sessions::list, routes::sessions::get, routes::sessions::end, routes::sessions::action,
        routes::sessions::events, routes::sessions::logs, routes::sessions::screenshot, routes::sessions::ui_tree, routes::sessions::stream_token,
        routes::misc::list_api_keys, routes::misc::create_api_key, routes::misc::revoke_api_key,
        routes::misc::usage, routes::misc::audit_logs, routes::misc::stream_verify,
        routes::agent::enroll, routes::agent::connect,
    ),
    components(schemas(
        error::ErrorBody, error::ErrorDetail, routes::misc::Health,
        routes::auth::LoginRequest, routes::auth::MeResponse, routes::auth::OrgMembership, routes::auth::CreateInviteRequest,
        routes::auth::CreateInviteResponse, routes::auth::InviteInfo, routes::auth::AcceptInviteRequest,
        routes::orgs::Organization, routes::orgs::CreateOrgRequest, routes::orgs::Member, routes::orgs::PendingInvite,
        routes::orgs::MembersResponse, routes::orgs::UpdateSettingsRequest,
        routes::apps::AppSummary, routes::apps::AppVersion, routes::apps::AppDetail, routes::apps::CreateAppRequest,
        routes::apps::CreateUploadRequest, routes::apps::CreateUploadResponse,
        routes::misc::DeviceProfile, routes::hosts::Host, routes::hosts::HostSession, routes::hosts::HostDetail,
        routes::hosts::EnrollmentTokenRequest, routes::hosts::EnrollmentTokenResponse,
        routes::sessions::Session, routes::sessions::CreateSessionRequest, routes::sessions::ActionResult, routes::sessions::SessionEvent,
        routes::sessions::LogLineDto, routes::sessions::ScreenshotResponse, routes::sessions::UiTreeResponse, stream::StreamAccess,
        routes::misc::ApiKey, routes::misc::CreateApiKeyRequest, routes::misc::CreateApiKeyResponse,
        routes::misc::Usage, routes::misc::UsageDay, routes::misc::AuditLog,
        routes::agent::EnrollRequest, routes::agent::EnrollResponse,
        dp_common::SessionState, dp_common::roles::Role, dp_common::protocol::InputAction, dp_common::protocol::KeyCode,
        dp_common::protocol::Orientation, dp_common::protocol::HostReport,
    )),
    tags((name = "auth"), (name = "organizations"), (name = "apps"), (name = "devices"), (name = "hosts"), (name = "sessions"),
         (name = "api-keys"), (name = "usage"), (name = "audit"), (name = "stream"), (name = "agent"), (name = "system"))
)]
pub struct ApiDoc;

/// OpenAPI document with globally unique operation ids (`<tag>_<handler>`).
pub fn openapi_doc() -> utoipa::openapi::OpenApi {
    let mut doc = ApiDoc::openapi();
    for item in doc.paths.paths.values_mut() {
        for op in item.operations.values_mut() {
            let tag = op.tags.as_ref().and_then(|t| t.first()).cloned();
            if let (Some(tag), Some(id)) = (tag, op.operation_id.clone()) {
                op.operation_id = Some(format!("{}_{}", tag.replace('-', "_"), id));
            }
        }
    }
    doc
}

async fn openapi_json() -> impl IntoResponse {
    Json(openapi_doc())
}

async fn docs_page() -> impl IntoResponse {
    let html = r#"<!doctype html><html><head><meta charset="utf-8"><title>Device Platform API</title>
<link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"></head>
<body><div id="ui"></div><script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
<script>SwaggerUIBundle({url:'/openapi.json',dom_id:'#ui'});</script></body></html>"#;
    (
        [(header::CONTENT_SECURITY_POLICY, "default-src 'none'; script-src 'unsafe-inline' https://unpkg.com; style-src https://unpkg.com 'unsafe-inline'; img-src data: https:; connect-src 'self'")],
        Html(html),
    )
}

pub fn router(state: AppState) -> Router {
    let v1 = Router::new()
        .route("/health", get(routes::misc::health))
        .route("/auth/login", post(routes::auth::login))
        .route("/auth/logout", post(routes::auth::logout))
        .route("/auth/me", get(routes::auth::me))
        .route("/auth/invites", post(routes::auth::create_invite))
        .route("/auth/invite-info", get(routes::auth::invite_info))
        .route("/auth/accept-invite", post(routes::auth::accept_invite))
        .route(
            "/organizations",
            get(routes::orgs::list).post(routes::orgs::create),
        )
        .route("/organizations/current/members", get(routes::orgs::members))
        .route(
            "/organizations/current/settings",
            patch(routes::orgs::update_settings),
        )
        .route("/organizations/:org_id", get(routes::orgs::get))
        .route(
            "/organizations/:org_id/activate",
            post(routes::orgs::activate),
        )
        .route("/apps", get(routes::apps::list).post(routes::apps::create))
        .route("/apps/:app_id", get(routes::apps::get))
        .route("/apps/:app_id/uploads", post(routes::apps::create_upload))
        .route(
            "/apps/:app_id/versions/:version_id/finalize",
            post(routes::apps::finalize),
        )
        .route("/device-profiles", get(routes::misc::device_profiles))
        .route("/hosts", get(routes::hosts::list))
        .route(
            "/hosts/enrollment-token",
            post(routes::hosts::enrollment_token),
        )
        .route("/hosts/:host_id", get(routes::hosts::get))
        .route(
            "/sessions",
            get(routes::sessions::list).post(routes::sessions::create),
        )
        .route(
            "/sessions/:session_id",
            get(routes::sessions::get).delete(routes::sessions::end),
        )
        .route(
            "/sessions/:session_id/actions",
            post(routes::sessions::action),
        )
        .route(
            "/sessions/:session_id/events",
            get(routes::sessions::events),
        )
        .route("/sessions/:session_id/logs", get(routes::sessions::logs))
        .route(
            "/sessions/:session_id/screenshot",
            post(routes::sessions::screenshot),
        )
        .route(
            "/sessions/:session_id/ui-tree",
            get(routes::sessions::ui_tree),
        )
        .route(
            "/sessions/:session_id/stream-token",
            post(routes::sessions::stream_token),
        )
        .route(
            "/api-keys",
            get(routes::misc::list_api_keys).post(routes::misc::create_api_key),
        )
        .route("/api-keys/:key_id", delete(routes::misc::revoke_api_key))
        .route("/usage", get(routes::misc::usage))
        .route("/audit-logs", get(routes::misc::audit_logs))
        .route("/stream/verify", get(routes::misc::stream_verify))
        .route("/agent/enroll", post(routes::agent::enroll))
        .route("/agent/connect", get(routes::agent::connect));

    let origins: Vec<HeaderValue> = state
        .cfg
        .cors_origins
        .iter()
        .filter_map(|o| o.parse().ok())
        .collect();
    let cors = CorsLayer::new()
        .allow_origin(AllowOrigin::list(origins))
        .allow_credentials(true)
        .allow_methods([Method::GET, Method::POST, Method::PATCH, Method::DELETE])
        .allow_headers([
            header::CONTENT_TYPE,
            header::AUTHORIZATION,
            HeaderName::from_static("x-csrf-token"),
            HeaderName::from_static("x-request-id"),
        ])
        .max_age(Duration::from_secs(600));
    let request_id = HeaderName::from_static("x-request-id");
    let hsts = state.cfg.cookie_secure;

    let mut app = Router::new()
        .nest("/v1", v1)
        .route("/openapi.json", get(openapi_json))
        .route("/docs", get(docs_page))
        .with_state(state)
        .layer(RequestBodyLimitLayer::new(1024 * 1024))
        .layer(cors)
        .layer(SetResponseHeaderLayer::if_not_present(
            header::X_CONTENT_TYPE_OPTIONS,
            HeaderValue::from_static("nosniff"),
        ))
        .layer(SetResponseHeaderLayer::if_not_present(
            header::X_FRAME_OPTIONS,
            HeaderValue::from_static("DENY"),
        ))
        .layer(SetResponseHeaderLayer::if_not_present(
            header::REFERRER_POLICY,
            HeaderValue::from_static("no-referrer"),
        ))
        .layer(SetResponseHeaderLayer::if_not_present(
            header::CONTENT_SECURITY_POLICY,
            HeaderValue::from_static("default-src 'none'; frame-ancestors 'none'"),
        ))
        .layer(SetResponseHeaderLayer::if_not_present(
            header::CACHE_CONTROL,
            HeaderValue::from_static("no-store"),
        ));
    if hsts {
        app = app.layer(SetResponseHeaderLayer::if_not_present(
            header::STRICT_TRANSPORT_SECURITY,
            HeaderValue::from_static("max-age=31536000; includeSubDomains"),
        ));
    }
    app.layer(PropagateRequestIdLayer::new(request_id.clone()))
        .layer(TraceLayer::new_for_http().make_span_with(|req: &axum::http::Request<_>| {
            // Never log query strings (may contain presigned/stream tokens) or headers.
            let rid = req.headers().get("x-request-id").and_then(|v| v.to_str().ok()).unwrap_or("-").to_string();
            tracing::info_span!("http", method = %req.method(), path = %req.uri().path(), request_id = %rid)
        }))
        .layer(SetRequestIdLayer::new(request_id, MakeRequestUuid))
}

/// Periodic maintenance: timeouts, host health, queued placement, retention.
pub fn spawn_background(state: AppState) {
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(Duration::from_secs(5));
        let mut n: u64 = 0;
        loop {
            tick.tick().await;
            n += 1;
            if let Err(e) = maintenance(&state, n).await {
                tracing::warn!(error = %e, "maintenance pass failed");
            }
        }
    });
}

async fn maintenance(state: &AppState, n: u64) -> anyhow::Result<()> {
    // Hosts without heartbeat -> offline.
    sqlx::query("UPDATE hosts SET status='offline', updated_at=now() WHERE status='online' AND (last_heartbeat_at IS NULL OR last_heartbeat_at < now() - interval '60 seconds')")
        .execute(&state.db)
        .await?;
    // Session timeouts.
    let expired: Vec<(Uuid, Uuid)> = sqlx::query_as("SELECT org_id, id FROM sessions WHERE state IN ('READY','ACTIVE') AND expires_at < now() LIMIT 50")
        .fetch_all(&state.db)
        .await?;
    for (org, id) in expired {
        let _ = orchestrator::end_session(state, org, id, "timeout", None).await;
    }
    // Host loss: sessions on hosts silent for >2 minutes fail (resources are reaped by the agent on restart).
    let lost: Vec<(Uuid, Uuid)> = sqlx::query_as(
        "SELECT s.org_id, s.id FROM sessions s JOIN hosts h ON h.id=s.host_id
         WHERE s.state IN ('ASSIGNED','BOOTING','INSTALLING','READY','ACTIVE','ENDING') AND (h.last_heartbeat_at IS NULL OR h.last_heartbeat_at < now() - interval '120 seconds') LIMIT 50",
    )
    .fetch_all(&state.db)
    .await?;
    for (org, id) in lost {
        let _ =
            orchestrator::finalize(state, org, id, SessionState::Failed, "host_lost", None).await;
    }
    // Stuck provisioning.
    let stuck: Vec<(Uuid, Uuid)> = sqlx::query_as(
        "SELECT org_id, id FROM sessions WHERE state IN ('ASSIGNED','BOOTING','INSTALLING') AND updated_at < now() - interval '20 minutes' LIMIT 50",
    )
    .fetch_all(&state.db)
    .await?;
    for (org, id) in stuck {
        let _ = orchestrator::finalize(
            state,
            org,
            id,
            SessionState::Failed,
            "provisioning_timeout",
            None,
        )
        .await;
    }
    // Queued sessions: retry placement for 2 minutes, then fail.
    let queued: Vec<(Uuid, Uuid, bool)> = sqlx::query_as(
        "SELECT org_id, id, created_at < now() - interval '2 minutes' FROM sessions WHERE state='QUEUED' ORDER BY created_at LIMIT 20",
    )
    .fetch_all(&state.db)
    .await?;
    for (org, id, too_old) in queued {
        match orchestrator::try_assign(state, org, id).await {
            Ok(true) => {}
            Ok(false) if too_old => {
                let _ = orchestrator::finalize(
                    state,
                    org,
                    id,
                    SessionState::Failed,
                    "no_capacity",
                    None,
                )
                .await;
            }
            Ok(false) => {}
            Err(_) => {
                let _ = orchestrator::finalize(
                    state,
                    org,
                    id,
                    SessionState::Cancelled,
                    "quota_exceeded",
                    None,
                )
                .await;
            }
        }
    }
    sqlx::query(
        "DELETE FROM devices WHERE status='wiping' AND updated_at < now() - interval '5 minutes'",
    )
    .execute(&state.db)
    .await?;
    // Retention, once a minute.
    if n.is_multiple_of(12) {
        let expired: Vec<(Uuid, String)> = sqlx::query_as(
            "SELECT id, object_key FROM app_versions WHERE status <> 'deleted' AND (
                (expires_at IS NOT NULL AND expires_at < now())
                OR (status = 'pending_upload' AND created_at < now() - interval '1 day')) LIMIT 100",
        )
        .fetch_all(&state.db)
        .await?;
        for (id, key) in expired {
            if state.storage.delete(&key).await.is_ok() {
                sqlx::query(
                    "UPDATE app_versions SET status='deleted', updated_at=now() WHERE id=$1",
                )
                .bind(id)
                .execute(&state.db)
                .await?;
                audit::record(
                    &state.db,
                    None,
                    None,
                    "apk.retention_deleted",
                    Some(("app_version", id.to_string())),
                    serde_json::json!({}),
                )
                .await?;
            }
        }
        sqlx::query("DELETE FROM auth_sessions WHERE expires_at < now() - interval '7 days'")
            .execute(&state.db)
            .await?;
    }
    Ok(())
}
