//! In-memory registry of connected agents + request/response correlation for typed commands.
//! Every command is persisted in `session_commands` (id = command_id) before it is sent, and
//! results are applied with a conditional UPDATE so duplicate deliveries are ignored.
use crate::error::ApiError;
use dp_common::protocol::{AgentCommand, CommandKind, CommandOutcome, ControlMessage};
use sqlx::PgPool;
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Duration;
use tokio::sync::{mpsc, oneshot};
use uuid::Uuid;

struct Conn {
    conn_id: Uuid,
    tx: mpsc::Sender<ControlMessage>,
}

#[derive(Default)]
pub struct AgentHub {
    conns: Mutex<HashMap<Uuid, Conn>>,
    waiters: Mutex<HashMap<Uuid, oneshot::Sender<CommandOutcome>>>,
}

impl AgentHub {
    pub fn register(&self, host_id: Uuid, conn_id: Uuid, tx: mpsc::Sender<ControlMessage>) {
        self.conns
            .lock()
            .unwrap()
            .insert(host_id, Conn { conn_id, tx });
    }

    /// Remove the connection only if it is still the current one (a newer connection may exist).
    pub fn unregister(&self, host_id: Uuid, conn_id: Uuid) -> bool {
        let mut c = self.conns.lock().unwrap();
        if c.get(&host_id).is_some_and(|x| x.conn_id == conn_id) {
            c.remove(&host_id);
            true
        } else {
            false
        }
    }

    pub fn is_connected(&self, host_id: Uuid) -> bool {
        self.conns.lock().unwrap().contains_key(&host_id)
    }

    fn sender(&self, host_id: Uuid) -> Option<mpsc::Sender<ControlMessage>> {
        self.conns
            .lock()
            .unwrap()
            .get(&host_id)
            .map(|c| c.tx.clone())
    }

    pub fn is_awaited(&self, command_id: Uuid) -> bool {
        self.waiters.lock().unwrap().contains_key(&command_id)
    }

    /// Persist, send and await a typed command.
    pub async fn request(
        &self,
        db: &PgPool,
        org_id: Uuid,
        host_id: Uuid,
        session_id: Uuid,
        kind: CommandKind,
        timeout: Duration,
    ) -> Result<CommandOutcome, ApiError> {
        let command_id = Uuid::now_v7();
        let payload = serde_json::to_value(&kind).map_err(|e| ApiError::Internal(e.into()))?;
        sqlx::query(
            "INSERT INTO session_commands (id, org_id, session_id, host_id, kind, payload, status)
             VALUES ($1,$2,$3,$4,$5,$6,'pending')",
        )
        .bind(command_id)
        .bind(org_id)
        .bind(session_id)
        .bind(host_id)
        .bind(kind.name())
        .bind(&payload)
        .execute(db)
        .await?;

        let (otx, orx) = oneshot::channel();
        self.waiters.lock().unwrap().insert(command_id, otx);
        let msg = ControlMessage::Command {
            command: AgentCommand {
                command_id,
                session_id,
                kind,
            },
        };
        let sent = match self.sender(host_id) {
            Some(tx) => tx.send(msg).await.is_ok(),
            None => false,
        };
        if sent {
            sqlx::query("UPDATE session_commands SET status='sent', attempts=attempts+1, updated_at=now() WHERE id=$1 AND status='pending'")
                .bind(command_id)
                .execute(db)
                .await?;
        }
        // If not sent, the command stays 'pending' and is re-delivered when the agent reconnects.
        let res = tokio::time::timeout(timeout, orx).await;
        self.waiters.lock().unwrap().remove(&command_id);
        match res {
            Ok(Ok(outcome)) => Ok(outcome),
            _ => {
                sqlx::query("UPDATE session_commands SET status='timed_out', updated_at=now(), completed_at=now() WHERE id=$1 AND status IN ('pending','sent','acked')")
                    .bind(command_id)
                    .execute(db)
                    .await?;
                Err(ApiError::Unavailable(format!(
                    "host did not complete the command within {}s",
                    timeout.as_secs()
                )))
            }
        }
    }

    pub async fn ack(
        &self,
        db: &PgPool,
        host_id: Uuid,
        command_id: Uuid,
    ) -> Result<(), sqlx::Error> {
        sqlx::query("UPDATE session_commands SET status='acked', updated_at=now() WHERE id=$1 AND host_id=$2 AND status IN ('pending','sent')")
            .bind(command_id)
            .bind(host_id)
            .execute(db)
            .await?;
        Ok(())
    }

    /// Apply a command result. Returns `true` if this was the first result for the command;
    /// duplicates (e.g. re-sent after reconnect) are ignored and return `false`.
    pub async fn complete(
        &self,
        db: &PgPool,
        host_id: Uuid,
        command_id: Uuid,
        outcome: CommandOutcome,
    ) -> Result<bool, sqlx::Error> {
        let status = if outcome.ok { "succeeded" } else { "failed" };
        let result = serde_json::to_value(&outcome.data).unwrap_or(serde_json::Value::Null);
        // Large payloads (UI XML) are not persisted in the command log.
        let stored = if result.to_string().len() > 64 * 1024 {
            serde_json::json!({"truncated": true})
        } else {
            result
        };
        let updated = sqlx::query(
            "UPDATE session_commands SET status=$3, result=$4, error=$5, updated_at=now(), completed_at=now()
             WHERE id=$1 AND host_id=$2 AND status IN ('pending','sent','acked')",
        )
        .bind(command_id)
        .bind(host_id)
        .bind(status)
        .bind(stored)
        .bind(outcome.error.as_deref())
        .execute(db)
        .await?
        .rows_affected()
            == 1;
        if updated {
            if let Some(w) = self.waiters.lock().unwrap().remove(&command_id) {
                let _ = w.send(outcome);
            }
        }
        Ok(updated)
    }

    /// Commands that were issued but not completed, to re-deliver after reconnect. The agent
    /// deduplicates by command_id, so redelivery is safe.
    pub async fn redeliver(&self, db: &PgPool, host_id: Uuid) -> Result<usize, sqlx::Error> {
        let rows: Vec<(Uuid, Uuid, serde_json::Value)> = sqlx::query_as(
            "SELECT id, session_id, payload FROM session_commands
             WHERE host_id=$1 AND status IN ('pending','sent','acked') AND created_at > now() - interval '10 minutes'
             ORDER BY created_at",
        )
        .bind(host_id)
        .fetch_all(db)
        .await?;
        let Some(tx) = self.sender(host_id) else {
            return Ok(0);
        };
        let mut n = 0;
        for (command_id, session_id, payload) in rows {
            if !self.is_awaited(command_id) {
                continue;
            }
            if let Ok(kind) = serde_json::from_value::<CommandKind>(payload) {
                if tx
                    .send(ControlMessage::Command {
                        command: AgentCommand {
                            command_id,
                            session_id,
                            kind,
                        },
                    })
                    .await
                    .is_ok()
                {
                    n += 1;
                }
            }
        }
        Ok(n)
    }
}
