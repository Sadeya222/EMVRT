//! Small in-process token-bucket rate limiter. Good enough for a single control-plane replica;
//! swap for a PostgreSQL- or proxy-backed limiter when running multiple replicas.
use crate::error::ApiError;
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Instant;

#[derive(Default)]
pub struct RateLimiter {
    buckets: Mutex<HashMap<String, (f64, Instant)>>,
}

#[derive(Clone, Copy)]
pub struct Limit {
    pub burst: f64,
    pub per_minute: f64,
}

pub const LOGIN_IP: Limit = Limit {
    burst: 20.0,
    per_minute: 20.0,
};
pub const LOGIN_EMAIL: Limit = Limit {
    burst: 5.0,
    per_minute: 5.0,
};
pub const INVITE: Limit = Limit {
    burst: 10.0,
    per_minute: 2.0,
};
pub const FINALIZE: Limit = Limit {
    burst: 20.0,
    per_minute: 20.0,
};
pub const SESSION_CREATE: Limit = Limit {
    burst: 10.0,
    per_minute: 10.0,
};
pub const ENROLL: Limit = Limit {
    burst: 5.0,
    per_minute: 5.0,
};

impl RateLimiter {
    pub fn check(&self, key: &str, limit: Limit) -> Result<(), ApiError> {
        let mut map = self.buckets.lock().expect("rate limiter poisoned");
        let now = Instant::now();
        if map.len() > 50_000 {
            map.retain(|_, (_, t)| now.duration_since(*t).as_secs() < 600);
        }
        let entry = map.entry(key.to_string()).or_insert((limit.burst, now));
        let elapsed = now.duration_since(entry.1).as_secs_f64();
        entry.0 = (entry.0 + elapsed * limit.per_minute / 60.0).min(limit.burst);
        entry.1 = now;
        if entry.0 >= 1.0 {
            entry.0 -= 1.0;
            Ok(())
        } else {
            Err(ApiError::RateLimited)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn limits_after_burst() {
        let rl = RateLimiter::default();
        let l = Limit {
            burst: 3.0,
            per_minute: 1.0,
        };
        for _ in 0..3 {
            assert!(rl.check("k", l).is_ok());
        }
        assert!(rl.check("k", l).is_err());
        assert!(rl.check("other", l).is_ok());
    }
}
