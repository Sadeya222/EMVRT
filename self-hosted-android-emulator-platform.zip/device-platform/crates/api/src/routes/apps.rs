use crate::audit;
use crate::auth::AuthCtx;
use crate::error::{ApiError, ApiResult};
use crate::ratelimit;
use crate::storage::Audience;
use crate::AppState;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use dp_common::apk::{validate_apk, ApkLimits};
use dp_common::roles::Perm;
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::FromRow;
use time::OffsetDateTime;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Serialize, ToSchema, FromRow)]
pub struct AppSummary {
    pub id: Uuid,
    pub name: String,
    pub package_name: Option<String>,
    pub version_count: i64,
    pub latest_version_name: Option<String>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct AppVersion {
    pub id: Uuid,
    pub app_id: Uuid,
    /// pending_upload | quarantined | validating | approved | rejected | deleted
    pub status: String,
    pub file_name: String,
    pub size_bytes: Option<i64>,
    pub sha256: Option<String>,
    pub package_name: Option<String>,
    pub version_name: Option<String>,
    pub version_code: Option<i64>,
    pub min_sdk: Option<i32>,
    pub rejection_reason: Option<String>,
    pub uploaded_by_email: Option<String>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub validated_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub expires_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[derive(Serialize, ToSchema)]
pub struct AppDetail {
    pub id: Uuid,
    pub name: String,
    pub package_name: Option<String>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
    pub versions: Vec<AppVersion>,
}

const VERSION_COLS: &str = "v.id, v.app_id, v.status, v.file_name, v.size_bytes, v.sha256, v.package_name, v.version_name, v.version_code, v.min_sdk, v.rejection_reason, u.email AS uploaded_by_email, v.validated_at, v.expires_at, v.created_at";

#[utoipa::path(get, path = "/v1/apps", tag = "apps", responses((status = 200, body = [AppSummary])))]
pub async fn list(State(state): State<AppState>, ctx: AuthCtx) -> ApiResult<Json<Vec<AppSummary>>> {
    let org = ctx.require(Perm::ReadApps)?;
    let rows = sqlx::query_as(
        r#"SELECT a.id, a.name, a.package_name, a.created_at,
                  (SELECT count(*) FROM app_versions v WHERE v.app_id=a.id AND v.org_id=a.org_id AND v.status <> 'deleted') AS version_count,
                  (SELECT v.version_name FROM app_versions v WHERE v.app_id=a.id AND v.org_id=a.org_id AND v.status='approved' ORDER BY v.created_at DESC LIMIT 1) AS latest_version_name
           FROM apps a WHERE a.org_id=$1 ORDER BY a.created_at DESC"#,
    )
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateAppRequest {
    pub name: String,
}

#[utoipa::path(post, path = "/v1/apps", request_body = CreateAppRequest, tag = "apps", responses((status = 201, body = AppDetail)))]
pub async fn create(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<CreateAppRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::WriteApps)?;
    let name = req.name.trim();
    if name.is_empty() || name.len() > 100 {
        return Err(ApiError::bad("name must be 1-100 characters"));
    }
    let id = Uuid::now_v7();
    let created_at: OffsetDateTime = sqlx::query_scalar(
        "INSERT INTO apps (id, org_id, name, created_by) VALUES ($1,$2,$3,$4) RETURNING created_at",
    )
    .bind(id)
    .bind(org)
    .bind(name)
    .bind(ctx.user_id)
    .fetch_one(&state.db)
    .await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "app.created",
        Some(("app", id.to_string())),
        json!({ "name": name }),
    )
    .await?;
    Ok((
        StatusCode::CREATED,
        Json(AppDetail {
            id,
            name: name.into(),
            package_name: None,
            created_at,
            versions: vec![],
        }),
    ))
}

#[utoipa::path(get, path = "/v1/apps/{app_id}", tag = "apps", params(("app_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = AppDetail), (status = 404, body = ErrorBody)))]
pub async fn get(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(app_id): Path<Uuid>,
) -> ApiResult<Json<AppDetail>> {
    let org = ctx.require(Perm::ReadApps)?;
    let (id, name, package_name, created_at): (Uuid, String, Option<String>, OffsetDateTime) =
        sqlx::query_as(
            "SELECT id, name, package_name, created_at FROM apps WHERE id=$1 AND org_id=$2",
        )
        .bind(app_id)
        .bind(org)
        .fetch_optional(&state.db)
        .await?
        .ok_or(ApiError::NotFound)?;
    let versions = sqlx::query_as(&format!(
        "SELECT {VERSION_COLS} FROM app_versions v LEFT JOIN users u ON u.id=v.uploaded_by WHERE v.app_id=$1 AND v.org_id=$2 AND v.status <> 'deleted' ORDER BY v.created_at DESC"
    ))
    .bind(app_id)
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(AppDetail {
        id,
        name,
        package_name,
        created_at,
        versions,
    }))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateUploadRequest {
    pub file_name: String,
    pub size_bytes: i64,
}

#[derive(Serialize, ToSchema)]
pub struct CreateUploadResponse {
    pub version_id: Uuid,
    pub upload_id: Uuid,
    /// Presigned PUT URL (expires in 15 minutes). The exact Content-Length is part of the signature.
    pub upload_url: String,
    pub method: String,
    #[serde(with = "time::serde::rfc3339")]
    pub expires_at: OffsetDateTime,
}

fn sanitize_file_name(n: &str) -> Option<String> {
    let base = n.rsplit(['/', '\\']).next()?.trim();
    let clean: String = base
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_'))
        .take(120)
        .collect();
    (clean.to_ascii_lowercase().ends_with(".apk") && clean.len() > 4).then_some(clean)
}

#[utoipa::path(post, path = "/v1/apps/{app_id}/uploads", request_body = CreateUploadRequest, tag = "apps", params(("app_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 201, body = CreateUploadResponse), (status = 413, body = ErrorBody)))]
pub async fn create_upload(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(app_id): Path<Uuid>,
    Json(req): Json<CreateUploadRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::WriteApps)?;
    let file_name =
        sanitize_file_name(&req.file_name).ok_or_else(|| ApiError::bad("file must be an .apk"))?;
    let (org_max,): (i64,) = sqlx::query_as("SELECT max_apk_bytes FROM organizations WHERE id=$1")
        .bind(org)
        .fetch_one(&state.db)
        .await?;
    let max = (org_max as u64).min(state.cfg.max_apk_bytes);
    if req.size_bytes <= 0 || req.size_bytes as u64 > max {
        return Err(ApiError::PayloadTooLarge(format!(
            "APK must be between 1 byte and {max} bytes"
        )));
    }
    let exists: bool =
        sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM apps WHERE id=$1 AND org_id=$2)")
            .bind(app_id)
            .bind(org)
            .fetch_one(&state.db)
            .await?;
    if !exists {
        return Err(ApiError::NotFound);
    }
    let version_id = Uuid::now_v7();
    let upload_id = Uuid::now_v7();
    let key = format!("orgs/{org}/apps/{app_id}/versions/{version_id}.apk");
    let now = OffsetDateTime::now_utc();
    let expires_at = now + time::Duration::minutes(15);
    let url = state.storage.presign(
        Audience::Browser,
        "PUT",
        &key,
        900,
        Some(req.size_bytes as u64),
        now,
    )?;
    let mut tx = state.db.begin().await?;
    sqlx::query(
        "INSERT INTO app_versions (id, org_id, app_id, status, object_key, file_name, declared_size, uploaded_by)
         VALUES ($1,$2,$3,'pending_upload',$4,$5,$6,$7)",
    )
    .bind(version_id)
    .bind(org)
    .bind(app_id)
    .bind(&key)
    .bind(&file_name)
    .bind(req.size_bytes)
    .bind(ctx.user_id)
    .execute(&mut *tx)
    .await?;
    sqlx::query(
        "INSERT INTO uploads (id, org_id, app_version_id, object_key, declared_size, presigned_expires_at, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7)",
    )
    .bind(upload_id)
    .bind(org)
    .bind(version_id)
    .bind(&key)
    .bind(req.size_bytes)
    .bind(expires_at)
    .bind(ctx.user_id)
    .execute(&mut *tx)
    .await?;
    audit::record(
        &mut *tx,
        Some(org),
        Some(&ctx),
        "apk.upload_started",
        Some(("app_version", version_id.to_string())),
        json!({ "size": req.size_bytes }),
    )
    .await?;
    tx.commit().await?;
    Ok((
        StatusCode::CREATED,
        Json(CreateUploadResponse {
            version_id,
            upload_id,
            upload_url: url,
            method: "PUT".into(),
            expires_at,
        }),
    ))
}

#[utoipa::path(post, path = "/v1/apps/{app_id}/versions/{version_id}/finalize", tag = "apps",
    params(("app_id" = Uuid, Path, description = "Resource identifier"), ("version_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = AppVersion), (status = 400, body = ErrorBody)))]
pub async fn finalize(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path((app_id, version_id)): Path<(Uuid, Uuid)>,
) -> ApiResult<Json<AppVersion>> {
    let org = ctx.require(Perm::WriteApps)?;
    state
        .limiter
        .check(&format!("finalize:{org}"), ratelimit::FINALIZE)?;
    // Claim the version: pending_upload -> quarantined (object is never installable in this state).
    let claimed: Option<(String, i64)> = sqlx::query_as(
        "UPDATE app_versions SET status='quarantined', updated_at=now()
         WHERE id=$1 AND app_id=$2 AND org_id=$3 AND status='pending_upload' RETURNING object_key, declared_size",
    )
    .bind(version_id)
    .bind(app_id)
    .bind(org)
    .fetch_optional(&state.db)
    .await?;
    let Some((key, declared)) = claimed else {
        let exists: bool = sqlx::query_scalar(
            "SELECT EXISTS(SELECT 1 FROM app_versions WHERE id=$1 AND app_id=$2 AND org_id=$3)",
        )
        .bind(version_id)
        .bind(app_id)
        .bind(org)
        .fetch_one(&state.db)
        .await?;
        return Err(if exists {
            ApiError::Conflict("version was already finalized".into())
        } else {
            ApiError::NotFound
        });
    };
    sqlx::query("UPDATE uploads SET completed_at=now(), updated_at=now() WHERE app_version_id=$1 AND org_id=$2").bind(version_id).bind(org).execute(&state.db).await?;
    sqlx::query("UPDATE app_versions SET status='validating', updated_at=now() WHERE id=$1")
        .bind(version_id)
        .execute(&state.db)
        .await?;

    let result = validate_object(&state, &key, declared as u64).await;
    let (app_pkg,): (Option<String>,) =
        sqlx::query_as("SELECT package_name FROM apps WHERE id=$1 AND org_id=$2")
            .bind(app_id)
            .bind(org)
            .fetch_one(&state.db)
            .await?;
    let outcome = match result {
        Ok(info) if app_pkg.as_deref().is_some_and(|p| p != info.package_name) => Err(format!(
            "package {} does not match application package {}",
            info.package_name,
            app_pkg.unwrap_or_default()
        )),
        other => other,
    };
    match outcome {
        Ok(info) => {
            let mut tx = state.db.begin().await?;
            sqlx::query(
                r#"UPDATE app_versions SET status='approved', size_bytes=$2, sha256=$3, package_name=$4, version_name=$5, version_code=$6,
                       min_sdk=$7, validated_at=now(), updated_at=now(),
                       expires_at = now() + make_interval(days => (SELECT apk_retention_days FROM organizations WHERE id=$8))
                   WHERE id=$1 AND org_id=$8"#,
            )
            .bind(version_id)
            .bind(info.size_bytes as i64)
            .bind(&info.sha256)
            .bind(&info.package_name)
            .bind(&info.version_name)
            .bind(info.version_code)
            .bind(info.min_sdk)
            .bind(org)
            .execute(&mut *tx)
            .await?;
            sqlx::query("UPDATE apps SET package_name = COALESCE(package_name, $3), updated_at=now() WHERE id=$1 AND org_id=$2")
                .bind(app_id)
                .bind(org)
                .bind(&info.package_name)
                .execute(&mut *tx)
                .await?;
            audit::record(&mut *tx, Some(org), Some(&ctx), "apk.approved", Some(("app_version", version_id.to_string())),
                json!({ "sha256": info.sha256, "package": info.package_name, "version_code": info.version_code })).await?;
            tx.commit().await?;
        }
        Err(reason) => {
            let _ = state.storage.delete(&key).await;
            sqlx::query("UPDATE app_versions SET status='rejected', rejection_reason=$2, validated_at=now(), updated_at=now() WHERE id=$1 AND org_id=$3")
                .bind(version_id)
                .bind(&reason)
                .bind(org)
                .execute(&state.db)
                .await?;
            audit::record(
                &state.db,
                Some(org),
                Some(&ctx),
                "apk.rejected",
                Some(("app_version", version_id.to_string())),
                json!({ "reason": reason }),
            )
            .await?;
        }
    }
    let v = sqlx::query_as(&format!("SELECT {VERSION_COLS} FROM app_versions v LEFT JOIN users u ON u.id=v.uploaded_by WHERE v.id=$1 AND v.org_id=$2"))
        .bind(version_id)
        .bind(org)
        .fetch_one(&state.db)
        .await?;
    Ok(Json(v))
}

async fn validate_object(
    state: &AppState,
    key: &str,
    declared: u64,
) -> Result<dp_common::apk::ApkInfo, String> {
    let size = state
        .storage
        .head(key)
        .await
        .map_err(|e| format!("storage error: {e}"))?
        .ok_or("upload not found in storage")?;
    if size != declared {
        return Err(format!(
            "uploaded size {size} does not match declared size {declared}"
        ));
    }
    let bytes = state
        .storage
        .get_limited(key, state.cfg.max_apk_bytes)
        .await
        .map_err(|e| e.to_string())?;
    let limits = ApkLimits {
        max_file_bytes: state.cfg.max_apk_bytes,
        ..Default::default()
    };
    tokio::task::spawn_blocking(move || validate_apk(&bytes, &limits).map_err(|e| e.to_string()))
        .await
        .map_err(|e| e.to_string())?
}
