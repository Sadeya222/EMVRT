use crate::audit;
use crate::auth::{self, AuthCtx};
use crate::error::{ApiError, ApiResult};
use crate::AppState;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use dp_common::roles::Perm;
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::FromRow;
use time::OffsetDateTime;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Serialize, ToSchema, FromRow)]
pub struct Host {
    pub id: Uuid,
    pub name: String,
    pub hostname: String,
    pub os: String,
    pub docker_version: Option<String>,
    pub adapter: String,
    pub agent_version: Option<String>,
    pub kvm_available: bool,
    pub cpu_count: i32,
    pub ram_mb: i64,
    pub disk_free_mb: i64,
    pub emulator_capacity: i32,
    pub reported_active: i32,
    pub allocated_slots: i32,
    pub status: String,
    pub connected: Option<bool>,
    pub stream_base_url: Option<String>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub last_heartbeat_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

const HOST_COLS: &str = "id, name, hostname, os, docker_version, adapter, agent_version, kvm_available, cpu_count, ram_mb, disk_free_mb, emulator_capacity, reported_active, allocated_slots, status, NULL::bool AS connected, stream_base_url, last_heartbeat_at, created_at";

#[utoipa::path(get, path = "/v1/hosts", tag = "hosts", responses((status = 200, body = [Host])))]
pub async fn list(State(state): State<AppState>, ctx: AuthCtx) -> ApiResult<Json<Vec<Host>>> {
    let org = ctx.require(Perm::ReadHosts)?;
    let mut rows: Vec<Host> = sqlx::query_as(&format!(
        "SELECT {HOST_COLS} FROM hosts WHERE org_id=$1 ORDER BY created_at"
    ))
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    for h in &mut rows {
        h.connected = Some(state.hub.is_connected(h.id));
    }
    Ok(Json(rows))
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct HostSession {
    pub id: Uuid,
    pub state: String,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[derive(Serialize, ToSchema)]
pub struct HostDetail {
    pub host: Host,
    pub recent_sessions: Vec<HostSession>,
}

#[utoipa::path(get, path = "/v1/hosts/{host_id}", tag = "hosts", params(("host_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = HostDetail), (status = 404, body = ErrorBody)))]
pub async fn get(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(host_id): Path<Uuid>,
) -> ApiResult<Json<HostDetail>> {
    let org = ctx.require(Perm::ReadHosts)?;
    let mut host: Host = sqlx::query_as(&format!(
        "SELECT {HOST_COLS} FROM hosts WHERE id=$1 AND org_id=$2"
    ))
    .bind(host_id)
    .bind(org)
    .fetch_optional(&state.db)
    .await?
    .ok_or(ApiError::NotFound)?;
    host.connected = Some(state.hub.is_connected(host.id));
    let recent_sessions = sqlx::query_as("SELECT id, state, created_at FROM sessions WHERE host_id=$1 AND org_id=$2 ORDER BY created_at DESC LIMIT 25")
        .bind(host_id)
        .bind(org)
        .fetch_all(&state.db)
        .await?;
    Ok(Json(HostDetail {
        host,
        recent_sessions,
    }))
}

#[derive(Deserialize, ToSchema)]
pub struct EnrollmentTokenRequest {
    pub name: String,
}

#[derive(Serialize, ToSchema)]
pub struct EnrollmentTokenResponse {
    pub id: Uuid,
    /// One-time token, valid for 1 hour. Only its hash is stored.
    pub enrollment_token: String,
    #[serde(with = "time::serde::rfc3339")]
    pub expires_at: OffsetDateTime,
    pub control_plane_url: String,
}

#[utoipa::path(post, path = "/v1/hosts/enrollment-token", request_body = EnrollmentTokenRequest, tag = "hosts",
    responses((status = 201, body = EnrollmentTokenResponse)))]
pub async fn enrollment_token(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<EnrollmentTokenRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::ManageHosts)?;
    let name = req.name.trim();
    if name.is_empty() || name.len() > 64 {
        return Err(ApiError::bad("name must be 1-64 characters"));
    }
    let token = auth::random_token("dpe_", 32);
    let id = Uuid::now_v7();
    let expires_at: OffsetDateTime = sqlx::query_scalar(
        "INSERT INTO host_agents (id, org_id, name, enrollment_token_hash, enrollment_expires_at, created_by)
         VALUES ($1,$2,$3,$4, now() + interval '1 hour', $5) RETURNING enrollment_expires_at",
    )
    .bind(id)
    .bind(org)
    .bind(name)
    .bind(auth::token_hash(&token))
    .bind(ctx.user_id)
    .fetch_one(&state.db)
    .await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "host.enrollment_token_created",
        Some(("host_agent", id.to_string())),
        json!({ "name": name }),
    )
    .await?;
    Ok((
        StatusCode::CREATED,
        Json(EnrollmentTokenResponse {
            id,
            enrollment_token: token,
            expires_at,
            control_plane_url: state.cfg.public_url.clone(),
        }),
    ))
}
