use super::page_limit;
use crate::audit;
use crate::auth::AuthCtx;
use crate::error::{ApiError, ApiResult};
use crate::orchestrator::{self, cas_transition, event};
use crate::ratelimit;
use crate::storage::Audience;
use crate::stream::{provider_for, StreamAccess, StreamContext, StreamDecision};
use crate::AppState;
use axum::extract::{Path, Query, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use dp_common::protocol::{CommandData, CommandKind, InputAction};
use dp_common::roles::Perm;
use dp_common::SessionState;
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::FromRow;
use std::time::Duration;
use time::OffsetDateTime;
use utoipa::{IntoParams, ToSchema};
use uuid::Uuid;

#[derive(Serialize, ToSchema, FromRow)]
pub struct Session {
    pub id: Uuid,
    #[schema(value_type = SessionState)]
    pub state: SessionStateDto,
    pub app_version_id: Option<Uuid>,
    pub app_name: Option<String>,
    pub version_name: Option<String>,
    pub package_name: Option<String>,
    pub profile_id: Uuid,
    pub profile_name: String,
    pub screen_width: i32,
    pub screen_height: i32,
    pub api_level: i32,
    pub host_id: Option<Uuid>,
    pub host_name: Option<String>,
    pub host_adapter: Option<String>,
    pub timeout_minutes: i32,
    pub stream_kind: Option<String>,
    pub ended_reason: Option<String>,
    pub failure_reason: Option<String>,
    pub requested_by_email: Option<String>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
    #[serde(with = "time::serde::rfc3339::option")]
    pub ready_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub ended_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub expires_at: Option<OffsetDateTime>,
}

/// Session state as stored in the database (validated by the shared state machine).
#[derive(Serialize, sqlx::Type)]
#[sqlx(transparent)]
pub struct SessionStateDto(pub String);

const SESSION_SELECT: &str = r#"SELECT s.id, s.state, s.app_version_id, a.name AS app_name, v.version_name, v.package_name,
    s.profile_id, p.name AS profile_name, p.screen_width, p.screen_height, p.api_level,
    s.host_id, h.name AS host_name, h.adapter AS host_adapter, s.timeout_minutes, s.stream_kind, s.ended_reason, s.failure_reason,
    u.email AS requested_by_email, s.created_at, s.ready_at, s.ended_at, s.expires_at
  FROM sessions s
  JOIN device_profiles p ON p.id = s.profile_id
  LEFT JOIN app_versions v ON v.id = s.app_version_id AND v.org_id = s.org_id
  LEFT JOIN apps a ON a.id = v.app_id AND a.org_id = s.org_id
  LEFT JOIN hosts h ON h.id = s.host_id AND h.org_id = s.org_id
  LEFT JOIN users u ON u.id = s.requested_by"#;

pub async fn load(state: &AppState, org: Uuid, id: Uuid) -> ApiResult<Session> {
    sqlx::query_as(&format!("{SESSION_SELECT} WHERE s.id=$1 AND s.org_id=$2"))
        .bind(id)
        .bind(org)
        .fetch_optional(&state.db)
        .await?
        .ok_or(ApiError::NotFound)
}

fn parse_state(s: &Session) -> ApiResult<SessionState> {
    s.state
        .0
        .parse()
        .map_err(|e: String| ApiError::Internal(anyhow::anyhow!(e)))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateSessionRequest {
    pub profile_id: Uuid,
    pub app_version_id: Option<Uuid>,
    pub timeout_minutes: Option<i32>,
}

#[utoipa::path(post, path = "/v1/sessions", request_body = CreateSessionRequest, tag = "sessions",
    responses((status = 201, body = Session), (status = 429, body = ErrorBody)))]
pub async fn create(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<CreateSessionRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::WriteSessions)?;
    state
        .limiter
        .check(&format!("session:{org}"), ratelimit::SESSION_CREATE)?;
    let profile_ok: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM device_profiles WHERE id=$1 AND (org_id IS NULL OR org_id=$2))")
        .bind(req.profile_id)
        .bind(org)
        .fetch_one(&state.db)
        .await?;
    if !profile_ok {
        return Err(ApiError::NotFound);
    }
    if let Some(v) = req.app_version_id {
        let status: Option<String> =
            sqlx::query_scalar("SELECT status FROM app_versions WHERE id=$1 AND org_id=$2")
                .bind(v)
                .bind(org)
                .fetch_optional(&state.db)
                .await?;
        match status.as_deref() {
            None => return Err(ApiError::NotFound),
            Some("approved") => {}
            Some(s) => {
                return Err(ApiError::Conflict(format!(
                    "app version is {s}; only approved versions can be installed"
                )))
            }
        }
    }
    let (max_min, default_min): (i32, i32) = sqlx::query_as(
        "SELECT max_session_minutes, default_session_minutes FROM organizations WHERE id=$1",
    )
    .bind(org)
    .fetch_one(&state.db)
    .await?;
    let timeout = req.timeout_minutes.unwrap_or(default_min);
    if !(1..=max_min).contains(&timeout) {
        return Err(ApiError::bad(format!(
            "timeout_minutes must be between 1 and {max_min}"
        )));
    }
    let id = Uuid::now_v7();
    let mut tx = state.db.begin().await?;
    sqlx::query(
        "INSERT INTO sessions (id, org_id, app_version_id, profile_id, state, requested_by, requested_by_key, timeout_minutes)
         VALUES ($1,$2,$3,$4,'REQUESTED',$5,$6,$7)",
    )
    .bind(id)
    .bind(org)
    .bind(req.app_version_id)
    .bind(req.profile_id)
    .bind(ctx.user_id)
    .bind(ctx.api_key_id)
    .bind(timeout)
    .execute(&mut *tx)
    .await?;
    event(&mut *tx, org, id, "created", None, ctx.user_id, json!({})).await?;
    cas_transition(
        &mut tx,
        org,
        id,
        SessionState::Requested,
        SessionState::Queued,
        ctx.user_id,
        json!({}),
    )
    .await?;
    audit::record(
        &mut *tx,
        Some(org),
        Some(&ctx),
        "session.created",
        Some(("session", id.to_string())),
        json!({ "profile_id": req.profile_id }),
    )
    .await?;
    tx.commit().await?;
    // Placement happens in its own transaction; quota errors cancel the session.
    match orchestrator::try_assign(&state, org, id).await {
        Ok(_) => {}
        Err(e @ ApiError::QuotaExceeded(_)) => {
            orchestrator::finalize(
                &state,
                org,
                id,
                SessionState::Cancelled,
                "quota_exceeded",
                None,
            )
            .await?;
            return Err(e);
        }
        Err(e) => return Err(e),
    }
    Ok((StatusCode::CREATED, Json(load(&state, org, id).await?)))
}

#[derive(Deserialize, IntoParams)]
pub struct ListQuery {
    pub state: Option<String>,
    pub active: Option<bool>,
    pub limit: Option<i64>,
}

#[utoipa::path(get, path = "/v1/sessions", tag = "sessions", params(ListQuery), responses((status = 200, body = [Session])))]
pub async fn list(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Query(q): Query<ListQuery>,
) -> ApiResult<Json<Vec<Session>>> {
    let org = ctx.require(Perm::ReadSessions)?;
    let active: Vec<String> = SessionState::non_terminal_db_values()
        .into_iter()
        .map(String::from)
        .collect();
    let rows = sqlx::query_as(&format!(
        "{SESSION_SELECT} WHERE s.org_id=$1 AND ($2::text IS NULL OR s.state=$2) AND (NOT $3 OR s.state = ANY($4)) ORDER BY s.created_at DESC LIMIT $5"
    ))
    .bind(org)
    .bind(q.state)
    .bind(q.active.unwrap_or(false))
    .bind(&active)
    .bind(page_limit(q.limit))
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[utoipa::path(get, path = "/v1/sessions/{session_id}", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = Session), (status = 404, body = ErrorBody)))]
pub async fn get(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<Session>> {
    let org = ctx.require(Perm::ReadSessions)?;
    Ok(Json(load(&state, org, id).await?))
}

#[utoipa::path(delete, path = "/v1/sessions/{session_id}", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = Session)))]
pub async fn end(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<Session>> {
    let org = ctx.require(Perm::WriteSessions)?;
    load(&state, org, id).await?;
    orchestrator::end_session(&state, org, id, "user", ctx.user_id).await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "session.end_requested",
        Some(("session", id.to_string())),
        json!({}),
    )
    .await?;
    Ok(Json(load(&state, org, id).await?))
}

#[derive(Serialize, ToSchema)]
pub struct ActionResult {
    pub ok: bool,
    pub error: Option<String>,
}

async fn interactive(
    state: &AppState,
    org: Uuid,
    id: Uuid,
    actor: Option<Uuid>,
) -> ApiResult<(Session, Uuid)> {
    let s = load(state, org, id).await?;
    let st = parse_state(&s)?;
    if !st.is_interactive() {
        return Err(ApiError::Conflict(format!(
            "session is {st}, not interactive"
        )));
    }
    let host = s
        .host_id
        .ok_or_else(|| ApiError::Conflict("session has no host".into()))?;
    if st == SessionState::Ready {
        let mut tx = state.db.begin().await?;
        // A concurrent request may already have activated it; that's fine.
        if cas_transition(
            &mut tx,
            org,
            id,
            SessionState::Ready,
            SessionState::Active,
            actor,
            json!({}),
        )
        .await
        .is_ok()
        {
            tx.commit().await?;
        }
    }
    Ok((s, host))
}

#[utoipa::path(post, path = "/v1/sessions/{session_id}/actions", request_body = InputAction, tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = ActionResult), (status = 409, body = ErrorBody)))]
pub async fn action(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
    Json(input): Json<InputAction>,
) -> ApiResult<Json<ActionResult>> {
    let org = ctx.require(Perm::WriteSessions)?;
    input.validate().map_err(ApiError::BadRequest)?;
    let (_, host) = interactive(&state, org, id, ctx.user_id).await?;
    let payload = serde_json::to_value(&input).unwrap_or_default();
    let out = state
        .hub
        .request(
            &state.db,
            org,
            host,
            id,
            CommandKind::SendInput {
                input: input.clone(),
            },
            Duration::from_secs(20),
        )
        .await?;
    event(
        &state.db,
        org,
        id,
        "action",
        None,
        ctx.user_id,
        json!({ "action": payload, "ok": out.ok, "error": out.error }),
    )
    .await?;
    Ok(Json(ActionResult {
        ok: out.ok,
        error: out.error,
    }))
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct SessionEvent {
    pub id: Uuid,
    pub kind: String,
    pub from_state: Option<String>,
    pub to_state: Option<String>,
    pub actor_email: Option<String>,
    #[schema(value_type = Object)]
    pub payload: serde_json::Value,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[utoipa::path(get, path = "/v1/sessions/{session_id}/events", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = [SessionEvent])))]
pub async fn events(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<Vec<SessionEvent>>> {
    let org = ctx.require(Perm::ReadSessions)?;
    load(&state, org, id).await?;
    let rows = sqlx::query_as(
        "SELECT e.id, e.kind, e.from_state, e.to_state, u.email AS actor_email, e.payload, e.created_at
         FROM session_events e LEFT JOIN users u ON u.id = e.actor_user_id
         WHERE e.session_id=$1 AND e.org_id=$2 ORDER BY e.created_at, e.id LIMIT 1000",
    )
    .bind(id)
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Deserialize, IntoParams)]
pub struct LogsQuery {
    /// Return lines with id greater than this cursor.
    pub after: Option<i64>,
    pub limit: Option<i64>,
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct LogLineDto {
    pub id: i64,
    pub ts: String,
    pub level: String,
    pub tag: String,
    pub message: String,
}

#[utoipa::path(get, path = "/v1/sessions/{session_id}/logs", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier"), LogsQuery),
    responses((status = 200, body = [LogLineDto])))]
pub async fn logs(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
    Query(q): Query<LogsQuery>,
) -> ApiResult<Json<Vec<LogLineDto>>> {
    let org = ctx.require(Perm::ReadSessions)?;
    load(&state, org, id).await?;
    let limit = q.limit.unwrap_or(500).clamp(1, 2000);
    let rows = sqlx::query_as(
        "SELECT id, ts, level, tag, message FROM session_log_lines WHERE session_id=$1 AND org_id=$2 AND id > $3 ORDER BY id LIMIT $4",
    )
    .bind(id)
    .bind(org)
    .bind(q.after.unwrap_or(0))
    .bind(limit)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Serialize, ToSchema)]
pub struct ScreenshotResponse {
    /// Short-lived (5 min) presigned URL.
    pub url: String,
    #[serde(with = "time::serde::rfc3339")]
    pub captured_at: OffsetDateTime,
}

#[utoipa::path(post, path = "/v1/sessions/{session_id}/screenshot", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = ScreenshotResponse)))]
pub async fn screenshot(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<ScreenshotResponse>> {
    let org = ctx.require(Perm::ReadSessions)?;
    let (_, host) = interactive(&state, org, id, ctx.user_id).await?;
    let key = format!(
        "orgs/{org}/sessions/{id}/screenshots/{}.png",
        Uuid::now_v7()
    );
    let now = OffsetDateTime::now_utc();
    let upload_url = state
        .storage
        .presign(Audience::Agent, "PUT", &key, 120, None, now)?;
    let out = state
        .hub
        .request(
            &state.db,
            org,
            host,
            id,
            CommandKind::CaptureScreenshot { upload_url },
            Duration::from_secs(30),
        )
        .await?;
    if !out.ok {
        return Err(ApiError::Unavailable(
            out.error.unwrap_or_else(|| "screenshot failed".into()),
        ));
    }
    event(
        &state.db,
        org,
        id,
        "screenshot",
        None,
        ctx.user_id,
        json!({ "key": key }),
    )
    .await?;
    let url = state
        .storage
        .presign(Audience::Browser, "GET", &key, 300, None, now)?;
    Ok(Json(ScreenshotResponse {
        url,
        captured_at: now,
    }))
}

#[derive(Serialize, ToSchema)]
pub struct UiTreeResponse {
    /// Raw `uiautomator dump` XML (accessibility hierarchy).
    pub xml: String,
}

#[utoipa::path(get, path = "/v1/sessions/{session_id}/ui-tree", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = UiTreeResponse)))]
pub async fn ui_tree(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<UiTreeResponse>> {
    let org = ctx.require(Perm::ReadSessions)?;
    let s = load(&state, org, id).await?;
    if !parse_state(&s)?.is_interactive() {
        return Err(ApiError::Conflict("session is not interactive".into()));
    }
    let host = s.host_id.ok_or(ApiError::NotFound)?;
    let out = state
        .hub
        .request(
            &state.db,
            org,
            host,
            id,
            CommandKind::FetchUiXml {},
            Duration::from_secs(30),
        )
        .await?;
    match out.data {
        Some(CommandData::UiXml { xml }) if out.ok => {
            event(
                &state.db,
                org,
                id,
                "ui_tree",
                None,
                ctx.user_id,
                json!({ "bytes": xml.len() }),
            )
            .await?;
            Ok(Json(UiTreeResponse { xml }))
        }
        _ => Err(ApiError::Unavailable(
            out.error.unwrap_or_else(|| "UI dump failed".into()),
        )),
    }
}

#[utoipa::path(post, path = "/v1/sessions/{session_id}/stream-token", tag = "sessions", params(("session_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = StreamAccess), (status = 503, body = ErrorBody, description = "stream_unavailable with setup instructions")))]
pub async fn stream_token(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(id): Path<Uuid>,
) -> ApiResult<Json<StreamAccess>> {
    let org = ctx.require(Perm::ReadSessions)?;
    let s = load(&state, org, id).await?;
    if !parse_state(&s)?.is_interactive() {
        return Err(ApiError::Conflict("session is not interactive".into()));
    }
    let host_id = s.host_id.ok_or(ApiError::NotFound)?;
    let (adapter, base): (String, Option<String>) =
        sqlx::query_as("SELECT adapter, stream_base_url FROM hosts WHERE id=$1 AND org_id=$2")
            .bind(host_id)
            .bind(org)
            .fetch_one(&state.db)
            .await?;
    let provider = provider_for(&state.cfg, &adapter);
    let ctx2 = StreamContext {
        org_id: org,
        session_id: id,
        host_id,
        host_adapter: &adapter,
        host_stream_base_url: base.as_deref(),
    };
    match provider.issue(&ctx2, OffsetDateTime::now_utc()) {
        StreamDecision::Available(a) => {
            audit::record(
                &state.db,
                Some(org),
                Some(&ctx),
                "stream.token_issued",
                Some(("session", id.to_string())),
                json!({ "provider": a.provider }),
            )
            .await?;
            Ok(Json(a))
        }
        StreamDecision::Unavailable {
            message,
            instructions,
        } => Err(ApiError::StreamUnavailable {
            message,
            instructions,
        }),
    }
}
