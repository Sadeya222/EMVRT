//! Agent enrollment and the outbound agent WebSocket.
use crate::audit;
use crate::auth::{self, client_ip_from_headers};
use crate::error::{ApiError, ApiResult};
use crate::orchestrator;
use crate::ratelimit;
use crate::AppState;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::{ConnectInfo, State};
use axum::http::{header, HeaderMap};
use axum::response::Response;
use axum::Json;
use dp_common::protocol::{AgentMessage, ControlMessage, HostReport, MAX_WS_MESSAGE_BYTES};
use dp_common::SessionState;
use futures::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::net::SocketAddr;
use std::time::Duration;
use tokio::sync::mpsc;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Deserialize, ToSchema)]
pub struct EnrollRequest {
    pub enrollment_token: String,
    pub report: HostReport,
    /// Optional HTTPS node-ingress base URL for browser streaming.
    pub stream_base_url: Option<String>,
}

#[derive(Serialize, ToSchema)]
pub struct EnrollResponse {
    pub host_id: Uuid,
    pub agent_id: Uuid,
    /// Long-lived agent credential. Store it with 0600 permissions; only its hash is kept server-side.
    pub agent_secret: String,
}

#[utoipa::path(post, path = "/v1/agent/enroll", request_body = EnrollRequest, tag = "agent",
    responses((status = 200, body = EnrollResponse), (status = 401, body = ErrorBody)))]
pub async fn enroll(
    State(state): State<AppState>,
    connect: Option<ConnectInfo<SocketAddr>>,
    headers: HeaderMap,
    Json(req): Json<EnrollRequest>,
) -> ApiResult<Json<EnrollResponse>> {
    let ip = client_ip_from_headers(&headers, connect.map(|c| c.0), state.cfg.trust_proxy);
    state.limiter.check(
        &format!("enroll:{}", ip.as_deref().unwrap_or("?")),
        ratelimit::ENROLL,
    )?;
    if let Some(u) = &req.stream_base_url {
        if !(u.starts_with("https://") || (state.cfg.is_dev() && u.starts_with("http://")))
            || u.len() > 200
        {
            return Err(ApiError::bad("stream_base_url must be an https:// URL"));
        }
    }
    let adapter = match req.report.adapter.as_str() {
        "fake" | "android-emulator" => req.report.adapter.clone(),
        _ => return Err(ApiError::bad("unknown adapter")),
    };
    let mut tx = state.db.begin().await?;
    let (agent_id, org_id, name): (Uuid, Uuid, String) = sqlx::query_as(
        "SELECT id, org_id, name FROM host_agents
         WHERE enrollment_token_hash=$1 AND enrolled_at IS NULL AND revoked_at IS NULL AND enrollment_expires_at > now()
         FOR UPDATE",
    )
    .bind(auth::token_hash(&req.enrollment_token))
    .fetch_optional(&mut *tx)
    .await?
    .ok_or(ApiError::Unauthorized)?;
    let host_id = Uuid::now_v7();
    let r = &req.report;
    sqlx::query(
        "INSERT INTO hosts (id, org_id, name, hostname, os, docker_version, adapter, agent_version, kvm_available, cpu_count, ram_mb, disk_free_mb, emulator_capacity, status, stream_base_url)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'offline',$14)",
    )
    .bind(host_id)
    .bind(org_id)
    .bind(&name)
    .bind(trunc(&r.hostname))
    .bind(trunc(&r.os))
    .bind(r.docker_version.as_deref().map(trunc))
    .bind(adapter)
    .bind(trunc(&r.agent_version))
    .bind(r.kvm_available)
    .bind(r.cpu_count as i32)
    .bind(r.ram_mb as i64)
    .bind(r.disk_free_mb as i64)
    .bind(r.emulator_capacity.min(64) as i32)
    .bind(&req.stream_base_url)
    .execute(&mut *tx)
    .await?;
    let secret = auth::random_token("dpa_", 32);
    sqlx::query("UPDATE host_agents SET host_id=$2, enrolled_at=now(), agent_secret_hash=$3, updated_at=now() WHERE id=$1")
        .bind(agent_id)
        .bind(host_id)
        .bind(auth::token_hash(&secret))
        .execute(&mut *tx)
        .await?;
    audit::record(
        &mut *tx,
        Some(org_id),
        None,
        "host.enrolled",
        Some(("host", host_id.to_string())),
        json!({ "hostname": r.hostname, "ip": ip }),
    )
    .await?;
    tx.commit().await?;
    Ok(Json(EnrollResponse {
        host_id,
        agent_id,
        agent_secret: secret,
    }))
}

fn trunc(s: &str) -> String {
    s.chars().take(200).collect()
}

/// Outbound WebSocket from the agent. Auth: `Authorization: Bearer <agent_id>.<agent_secret>`.
#[utoipa::path(get, path = "/v1/agent/connect", tag = "agent", responses((status = 101, description = "WebSocket upgrade"), (status = 401, body = ErrorBody)))]
pub async fn connect(
    State(state): State<AppState>,
    headers: HeaderMap,
    ws: WebSocketUpgrade,
) -> ApiResult<Response> {
    let cred = headers
        .get(header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .ok_or(ApiError::Unauthorized)?;
    let (agent_id, secret) = cred.split_once('.').ok_or(ApiError::Unauthorized)?;
    let agent_id: Uuid = agent_id.parse().map_err(|_| ApiError::Unauthorized)?;
    let row: Option<(Uuid, Uuid, Vec<u8>)> = sqlx::query_as(
        "SELECT host_id, org_id, agent_secret_hash FROM host_agents WHERE id=$1 AND revoked_at IS NULL AND host_id IS NOT NULL AND agent_secret_hash IS NOT NULL",
    )
    .bind(agent_id)
    .fetch_optional(&state.db)
    .await?;
    let (host_id, org_id, hash) = row.ok_or(ApiError::Unauthorized)?;
    if !auth::constant_eq(&auth::token_hash(secret), &hash) {
        return Err(ApiError::Unauthorized);
    }
    sqlx::query("UPDATE host_agents SET last_connected_at=now() WHERE id=$1")
        .bind(agent_id)
        .execute(&state.db)
        .await?;
    Ok(ws
        .max_message_size(MAX_WS_MESSAGE_BYTES)
        .max_frame_size(MAX_WS_MESSAGE_BYTES)
        .on_upgrade(move |socket| run_socket(state, socket, host_id, org_id)))
}

async fn run_socket(state: AppState, socket: WebSocket, host_id: Uuid, org_id: Uuid) {
    let conn_id = Uuid::now_v7();
    let (mut sink, mut stream) = socket.split();
    let (tx, mut rx) = mpsc::channel::<ControlMessage>(64);
    state.hub.register(host_id, conn_id, tx.clone());
    tracing::info!(%host_id, "agent connected");
    let writer = tokio::spawn(async move {
        let mut ping = tokio::time::interval(Duration::from_secs(20));
        loop {
            tokio::select! {
                msg = rx.recv() => {
                    let Some(msg) = msg else { break };
                    let Ok(text) = serde_json::to_string(&msg) else { continue };
                    if sink.send(Message::Text(text)).await.is_err() { break; }
                }
                _ = ping.tick() => {
                    if sink.send(Message::Ping(vec![])).await.is_err() { break; }
                }
            }
        }
    });
    let _ = tx
        .send(ControlMessage::Welcome {
            host_id,
            heartbeat_interval_secs: 15,
        })
        .await;

    while let Some(Ok(msg)) = stream.next().await {
        let text = match msg {
            Message::Text(t) => t,
            Message::Close(_) => break,
            _ => continue,
        };
        let parsed: AgentMessage = match serde_json::from_str(&text) {
            Ok(m) => m,
            Err(e) => {
                tracing::warn!(%host_id, error = %e, "invalid agent message");
                continue;
            }
        };
        if let Err(e) = handle_message(&state, host_id, org_id, parsed).await {
            tracing::warn!(%host_id, error = %e, "agent message handling failed");
        }
    }
    writer.abort();
    if state.hub.unregister(host_id, conn_id) {
        let _ = sqlx::query(
            "UPDATE hosts SET status='offline', updated_at=now() WHERE id=$1 AND status='online'",
        )
        .bind(host_id)
        .execute(&state.db)
        .await;
    }
    tracing::info!(%host_id, "agent disconnected");
}

async fn update_report(state: &AppState, host_id: Uuid, r: &HostReport) -> Result<(), sqlx::Error> {
    sqlx::query(
        "UPDATE hosts SET hostname=$2, os=$3, docker_version=$4, agent_version=$5, kvm_available=$6, cpu_count=$7, ram_mb=$8,
             disk_free_mb=$9, emulator_capacity=$10, reported_active=$11, last_heartbeat_at=now(), updated_at=now(),
             status = CASE WHEN status IN ('draining','disabled') THEN status ELSE 'online' END
         WHERE id=$1",
    )
    .bind(host_id)
    .bind(trunc(&r.hostname))
    .bind(trunc(&r.os))
    .bind(r.docker_version.as_deref().map(trunc))
    .bind(trunc(&r.agent_version))
    .bind(r.kvm_available)
    .bind(r.cpu_count as i32)
    .bind(r.ram_mb as i64)
    .bind(r.disk_free_mb as i64)
    .bind(r.emulator_capacity.min(64) as i32)
    .bind(r.active_sessions as i32)
    .execute(&state.db)
    .await?;
    Ok(())
}

pub async fn handle_message(
    state: &AppState,
    host_id: Uuid,
    org_id: Uuid,
    msg: AgentMessage,
) -> anyhow::Result<()> {
    match msg {
        AgentMessage::Hello { report, .. } => {
            update_report(state, host_id, &report).await?;
            let n = state.hub.redeliver(&state.db, host_id).await?;
            if n > 0 {
                tracing::info!(%host_id, redelivered = n, "redelivered in-flight commands");
            }
        }
        AgentMessage::Heartbeat { report } => update_report(state, host_id, &report).await?,
        AgentMessage::CommandAck { command_id } => {
            state.hub.ack(&state.db, host_id, command_id).await?
        }
        AgentMessage::CommandResult {
            command_id,
            outcome,
        } => {
            if !state
                .hub
                .complete(&state.db, host_id, command_id, outcome)
                .await?
            {
                tracing::debug!(%command_id, "duplicate command result ignored");
            }
        }
        AgentMessage::LogLines { session_id, lines } => {
            // Only accept logs for sessions that this host actually runs, in its org.
            let owns: bool = sqlx::query_scalar(
                "SELECT EXISTS(SELECT 1 FROM sessions WHERE id=$1 AND host_id=$2 AND org_id=$3)",
            )
            .bind(session_id)
            .bind(host_id)
            .bind(org_id)
            .fetch_one(&state.db)
            .await?;
            if !owns {
                return Ok(());
            }
            let lines: Vec<_> = lines.into_iter().take(500).collect();
            let ts: Vec<String> = lines
                .iter()
                .map(|l| l.ts.chars().take(40).collect())
                .collect();
            let lv: Vec<String> = lines
                .iter()
                .map(|l| l.level.chars().take(2).collect())
                .collect();
            let tag: Vec<String> = lines
                .iter()
                .map(|l| l.tag.chars().take(128).collect())
                .collect();
            let m: Vec<String> = lines
                .iter()
                .map(|l| l.message.chars().take(4000).collect())
                .collect();
            sqlx::query(
                "INSERT INTO session_log_lines (org_id, session_id, ts, level, tag, message)
                 SELECT $1, $2, * FROM UNNEST($3::text[], $4::text[], $5::text[], $6::text[])",
            )
            .bind(org_id)
            .bind(session_id)
            .bind(&ts)
            .bind(&lv)
            .bind(&tag)
            .bind(&m)
            .execute(&state.db)
            .await?;
            // Keep a bounded buffer per session.
            sqlx::query(
                "DELETE FROM session_log_lines WHERE session_id=$1 AND id < (
                    SELECT id FROM session_log_lines WHERE session_id=$1 ORDER BY id DESC OFFSET 5000 LIMIT 1)",
            )
            .bind(session_id)
            .execute(&state.db)
            .await?;
        }
        AgentMessage::SessionLost { session_id, reason } => {
            let owns: bool = sqlx::query_scalar(
                "SELECT EXISTS(SELECT 1 FROM sessions WHERE id=$1 AND host_id=$2 AND org_id=$3)",
            )
            .bind(session_id)
            .bind(host_id)
            .bind(org_id)
            .fetch_one(&state.db)
            .await?;
            if owns {
                let reason = format!(
                    "device_lost: {}",
                    reason.chars().take(200).collect::<String>()
                );
                orchestrator::finalize(
                    state,
                    org_id,
                    session_id,
                    SessionState::Failed,
                    &reason,
                    None,
                )
                .await?;
            }
        }
    }
    Ok(())
}
