use super::page_limit;
use crate::audit;
use crate::auth::{self, AuthCtx};
use crate::error::{ApiError, ApiResult};
use crate::stream::verify_token;
use crate::AppState;
use axum::extract::{Path, Query, State};
use axum::http::{HeaderMap, HeaderValue, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::Json;
use dp_common::roles::{Perm, API_KEY_SCOPES};
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::FromRow;
use time::OffsetDateTime;
use utoipa::{IntoParams, ToSchema};
use uuid::Uuid;

#[derive(Serialize, ToSchema)]
pub struct Health {
    pub status: String,
    pub database: bool,
    pub version: String,
}

#[utoipa::path(get, path = "/v1/health", tag = "system", responses((status = 200, body = Health), (status = 503, body = Health)))]
pub async fn health(State(state): State<AppState>) -> Response {
    let db = sqlx::query_scalar::<_, i32>("SELECT 1")
        .fetch_one(&state.db)
        .await
        .is_ok();
    let body = Health {
        status: if db { "ok" } else { "degraded" }.into(),
        database: db,
        version: env!("CARGO_PKG_VERSION").into(),
    };
    let code = if db {
        StatusCode::OK
    } else {
        StatusCode::SERVICE_UNAVAILABLE
    };
    (code, Json(body)).into_response()
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct DeviceProfile {
    pub id: Uuid,
    pub slug: String,
    pub name: String,
    pub api_level: i32,
    pub abi: String,
    pub screen_width: i32,
    pub screen_height: i32,
    pub density: i32,
    pub cpu_cores: i32,
    pub ram_mb: i32,
}

#[utoipa::path(get, path = "/v1/device-profiles", tag = "devices", responses((status = 200, body = [DeviceProfile])))]
pub async fn device_profiles(
    State(state): State<AppState>,
    ctx: AuthCtx,
) -> ApiResult<Json<Vec<DeviceProfile>>> {
    let org = ctx.require(Perm::ReadSessions)?;
    let rows = sqlx::query_as(
        "SELECT id, slug, name, api_level, abi, screen_width, screen_height, density, cpu_cores, ram_mb FROM device_profiles WHERE org_id IS NULL OR org_id=$1 ORDER BY api_level DESC",
    )
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct ApiKey {
    pub id: Uuid,
    pub name: String,
    pub prefix: String,
    pub scopes: Vec<String>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub last_used_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub expires_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339::option")]
    pub revoked_at: Option<OffsetDateTime>,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[utoipa::path(get, path = "/v1/api-keys", tag = "api-keys", responses((status = 200, body = [ApiKey])))]
pub async fn list_api_keys(
    State(state): State<AppState>,
    ctx: AuthCtx,
) -> ApiResult<Json<Vec<ApiKey>>> {
    let org = ctx.require(Perm::ManageApiKeys)?;
    let rows = sqlx::query_as("SELECT id, name, prefix, scopes, last_used_at, expires_at, revoked_at, created_at FROM api_keys WHERE org_id=$1 ORDER BY created_at DESC")
        .bind(org)
        .fetch_all(&state.db)
        .await?;
    Ok(Json(rows))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateApiKeyRequest {
    pub name: String,
    pub scopes: Vec<String>,
    pub expires_in_days: Option<i32>,
}

#[derive(Serialize, ToSchema)]
pub struct CreateApiKeyResponse {
    pub key: ApiKey,
    /// The full secret. Shown exactly once; only a SHA-256 hash is stored.
    pub secret: String,
}

#[utoipa::path(post, path = "/v1/api-keys", request_body = CreateApiKeyRequest, tag = "api-keys", responses((status = 201, body = CreateApiKeyResponse)))]
pub async fn create_api_key(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<CreateApiKeyRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::ManageApiKeys)?;
    let name = req.name.trim();
    if name.is_empty() || name.len() > 64 {
        return Err(ApiError::bad("name must be 1-64 characters"));
    }
    if req.scopes.is_empty()
        || req
            .scopes
            .iter()
            .any(|s| !API_KEY_SCOPES.contains(&s.as_str()))
    {
        return Err(ApiError::bad(format!(
            "scopes must be a non-empty subset of {API_KEY_SCOPES:?}"
        )));
    }
    if let Some(d) = req.expires_in_days {
        if !(1..=365).contains(&d) {
            return Err(ApiError::bad("expires_in_days must be 1-365"));
        }
    }
    let secret = auth::random_token(auth::API_KEY_PREFIX, 32);
    let prefix: String = secret.chars().take(12).collect();
    let key: ApiKey = sqlx::query_as(
        "INSERT INTO api_keys (id, org_id, created_by, name, prefix, key_hash, scopes, expires_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7, CASE WHEN $8::int IS NULL THEN NULL ELSE now() + make_interval(days => $8) END)
         RETURNING id, name, prefix, scopes, last_used_at, expires_at, revoked_at, created_at",
    )
    .bind(Uuid::now_v7())
    .bind(org)
    .bind(ctx.user_id)
    .bind(name)
    .bind(&prefix)
    .bind(auth::token_hash(&secret))
    .bind(&req.scopes)
    .bind(req.expires_in_days)
    .fetch_one(&state.db)
    .await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "api_key.created",
        Some(("api_key", key.id.to_string())),
        json!({ "name": name, "scopes": req.scopes }),
    )
    .await?;
    Ok((
        StatusCode::CREATED,
        Json(CreateApiKeyResponse { key, secret }),
    ))
}

#[utoipa::path(delete, path = "/v1/api-keys/{key_id}", tag = "api-keys", params(("key_id" = Uuid, Path, description = "Resource identifier")), responses((status = 204)))]
pub async fn revoke_api_key(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(key_id): Path<Uuid>,
) -> ApiResult<StatusCode> {
    let org = ctx.require(Perm::ManageApiKeys)?;
    let n = sqlx::query("UPDATE api_keys SET revoked_at=now(), updated_at=now() WHERE id=$1 AND org_id=$2 AND revoked_at IS NULL")
        .bind(key_id)
        .bind(org)
        .execute(&state.db)
        .await?
        .rows_affected();
    if n == 0 {
        return Err(ApiError::NotFound);
    }
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "api_key.revoked",
        Some(("api_key", key_id.to_string())),
        json!({}),
    )
    .await?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct UsageDay {
    pub day: String,
    pub sessions: i64,
    pub minutes: i64,
}

#[derive(Serialize, ToSchema)]
pub struct Usage {
    pub active_sessions: i64,
    pub max_concurrent_sessions: i32,
    pub sessions_30d: i64,
    pub session_minutes_30d: i64,
    pub apps: i64,
    pub hosts_online: i64,
    pub by_day: Vec<UsageDay>,
}

#[utoipa::path(get, path = "/v1/usage", tag = "usage", responses((status = 200, body = Usage)))]
pub async fn usage(State(state): State<AppState>, ctx: AuthCtx) -> ApiResult<Json<Usage>> {
    let org = ctx.require(Perm::ReadUsage)?;
    let holding: Vec<String> = dp_common::SessionState::ALL
        .iter()
        .filter(|s| s.holds_capacity())
        .map(|s| s.as_str().to_string())
        .collect();
    let (active, max, s30, m30, apps, hosts): (i64, i32, i64, i64, i64, i64) = sqlx::query_as(
        r#"SELECT
            (SELECT count(*) FROM sessions WHERE org_id=$1 AND state = ANY($2)),
            (SELECT max_concurrent_sessions FROM organizations WHERE id=$1),
            (SELECT count(*) FROM sessions WHERE org_id=$1 AND created_at > now() - interval '30 days'),
            (SELECT COALESCE(sum(quantity),0)::bigint FROM usage_events WHERE org_id=$1 AND kind='session_minutes' AND created_at > now() - interval '30 days'),
            (SELECT count(*) FROM apps WHERE org_id=$1),
            (SELECT count(*) FROM hosts WHERE org_id=$1 AND status='online')"#,
    )
    .bind(org)
    .bind(&holding)
    .fetch_one(&state.db)
    .await?;
    let by_day = sqlx::query_as(
        r#"SELECT to_char(d, 'YYYY-MM-DD') AS day,
              (SELECT count(*) FROM sessions s WHERE s.org_id=$1 AND s.created_at::date = d::date) AS sessions,
              (SELECT COALESCE(sum(quantity),0)::bigint FROM usage_events u WHERE u.org_id=$1 AND u.kind='session_minutes' AND u.created_at::date = d::date) AS minutes
           FROM generate_series(current_date - 13, current_date, interval '1 day') d ORDER BY d"#,
    )
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    Ok(Json(Usage {
        active_sessions: active,
        max_concurrent_sessions: max,
        sessions_30d: s30,
        session_minutes_30d: m30,
        apps,
        hosts_online: hosts,
        by_day,
    }))
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct AuditLog {
    pub id: Uuid,
    pub action: String,
    pub actor_email: Option<String>,
    pub actor_api_key_id: Option<Uuid>,
    pub target_type: Option<String>,
    pub target_id: Option<String>,
    pub ip: Option<String>,
    #[schema(value_type = Object)]
    pub metadata: serde_json::Value,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[derive(Deserialize, IntoParams)]
pub struct AuditQuery {
    pub limit: Option<i64>,
    pub action: Option<String>,
}

#[utoipa::path(get, path = "/v1/audit-logs", tag = "audit", params(AuditQuery), responses((status = 200, body = [AuditLog])))]
pub async fn audit_logs(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Query(q): Query<AuditQuery>,
) -> ApiResult<Json<Vec<AuditLog>>> {
    let org = ctx.require(Perm::ReadAudit)?;
    let rows = sqlx::query_as(
        "SELECT a.id, a.action, u.email AS actor_email, a.actor_api_key_id, a.target_type, a.target_id, a.ip, a.metadata, a.created_at
         FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id
         WHERE a.org_id=$1 AND ($2::text IS NULL OR a.action LIKE $2 || '%') ORDER BY a.created_at DESC LIMIT $3",
    )
    .bind(org)
    .bind(q.action)
    .bind(page_limit(q.limit))
    .fetch_all(&state.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Deserialize, IntoParams)]
pub struct VerifyQuery {
    pub dp_token: Option<String>,
}

/// Caddy `forward_auth` target for node ingresses. Validates a short-lived stream token and that
/// the session is still interactive; on success returns `X-Dp-Upstream` with the host-local
/// emulator endpoint so the ingress can route to the right container.
#[utoipa::path(get, path = "/v1/stream/verify", tag = "stream", params(VerifyQuery), responses((status = 200), (status = 401)))]
pub async fn stream_verify(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(q): Query<VerifyQuery>,
) -> Response {
    let from_uri = headers
        .get("x-forwarded-uri")
        .and_then(|v| v.to_str().ok())
        .and_then(|u| url::Url::parse(&format!("http://x{u}")).ok())
        .and_then(|u| {
            u.query_pairs()
                .find(|(k, _)| k == "dp_token")
                .map(|(_, v)| v.into_owned())
        });
    let token = q
        .dp_token
        .or(from_uri)
        .or_else(|| auth::get_cookie(&headers, "dp_stream"));
    let Some(claims) = token.and_then(|t| {
        verify_token(
            &state.cfg.stream_token_secret,
            &t,
            OffsetDateTime::now_utc(),
        )
    }) else {
        return StatusCode::UNAUTHORIZED.into_response();
    };
    let row: Option<(String, Option<String>)> = sqlx::query_as(
        "SELECT state, stream_endpoint FROM sessions WHERE id=$1 AND org_id=$2 AND host_id=$3",
    )
    .bind(claims.sid)
    .bind(claims.oid)
    .bind(claims.hid)
    .fetch_optional(&state.db)
    .await
    .ok()
    .flatten();
    match row {
        Some((st, Some(endpoint))) if st == "READY" || st == "ACTIVE" => {
            let mut res = StatusCode::OK.into_response();
            if let Ok(v) = HeaderValue::from_str(&endpoint) {
                res.headers_mut().insert("x-dp-upstream", v);
            }
            res
        }
        _ => StatusCode::UNAUTHORIZED.into_response(),
    }
}
