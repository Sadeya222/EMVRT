use crate::audit;
use crate::auth::AuthCtx;
use crate::error::{ApiError, ApiResult};
use crate::routes::auth::MeResponse;
use crate::AppState;
use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use dp_common::roles::Perm;
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::{FromRow, Postgres, Transaction};
use time::OffsetDateTime;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Serialize, ToSchema, FromRow)]
pub struct Organization {
    pub id: Uuid,
    pub name: String,
    pub slug: String,
    pub max_concurrent_sessions: i32,
    pub max_session_minutes: i32,
    pub default_session_minutes: i32,
    pub apk_retention_days: i32,
    pub max_apk_bytes: i64,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

const ORG_COLS: &str = "id, name, slug, max_concurrent_sessions, max_session_minutes, default_session_minutes, apk_retention_days, max_apk_bytes, created_at";

pub fn slugify(name: &str) -> String {
    let s: String = name
        .to_lowercase()
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() { c } else { '-' })
        .collect();
    let s = s
        .split('-')
        .filter(|p| !p.is_empty())
        .collect::<Vec<_>>()
        .join("-");
    let s: String = s.chars().take(40).collect();
    if s.is_empty() {
        "org".into()
    } else {
        s
    }
}

pub async fn insert_org(tx: &mut Transaction<'_, Postgres>, name: &str) -> ApiResult<Uuid> {
    let name = name.trim();
    if name.is_empty() || name.len() > 100 {
        return Err(ApiError::bad("organization name must be 1-100 characters"));
    }
    let id = Uuid::now_v7();
    let slug = format!("{}-{}", slugify(name), &id.simple().to_string()[24..]);
    sqlx::query("INSERT INTO organizations (id, name, slug) VALUES ($1,$2,$3)")
        .bind(id)
        .bind(name)
        .bind(slug)
        .execute(&mut **tx)
        .await?;
    Ok(id)
}

#[utoipa::path(get, path = "/v1/organizations", tag = "organizations", responses((status = 200, body = [Organization])))]
pub async fn list(
    State(state): State<AppState>,
    ctx: AuthCtx,
) -> ApiResult<Json<Vec<Organization>>> {
    let rows = if let Some(uid) = ctx.user_id {
        sqlx::query_as(&format!(
            "SELECT {ORG_COLS} FROM organizations WHERE id IN (SELECT org_id FROM memberships WHERE user_id=$1) ORDER BY name"
        ))
        .bind(uid)
        .fetch_all(&state.db)
        .await?
    } else {
        sqlx::query_as(&format!("SELECT {ORG_COLS} FROM organizations WHERE id=$1"))
            .bind(ctx.org_id)
            .fetch_all(&state.db)
            .await?
    };
    Ok(Json(rows))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateOrgRequest {
    pub name: String,
}

#[utoipa::path(post, path = "/v1/organizations", request_body = CreateOrgRequest, tag = "organizations", responses((status = 201, body = Organization)))]
pub async fn create(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<CreateOrgRequest>,
) -> ApiResult<impl IntoResponse> {
    let user = ctx.user()?;
    let mut tx = state.db.begin().await?;
    let id = insert_org(&mut tx, &req.name).await?;
    sqlx::query("INSERT INTO memberships (id, org_id, user_id, role) VALUES ($1,$2,$3,'owner')")
        .bind(Uuid::now_v7())
        .bind(id)
        .bind(user)
        .execute(&mut *tx)
        .await?;
    audit::record(
        &mut *tx,
        Some(id),
        Some(&ctx),
        "org.created",
        Some(("organization", id.to_string())),
        json!({}),
    )
    .await?;
    let org: Organization =
        sqlx::query_as(&format!("SELECT {ORG_COLS} FROM organizations WHERE id=$1"))
            .bind(id)
            .fetch_one(&mut *tx)
            .await?;
    tx.commit().await?;
    Ok((StatusCode::CREATED, Json(org)))
}

async fn member_org(state: &AppState, ctx: &AuthCtx, org_id: Uuid) -> ApiResult<Organization> {
    // API keys may only see their own org; users only orgs they belong to.
    let row: Option<Organization> = if let Some(uid) = ctx.user_id {
        sqlx::query_as(&format!(
            "SELECT {ORG_COLS} FROM organizations o WHERE o.id=$1 AND EXISTS (SELECT 1 FROM memberships m WHERE m.org_id=o.id AND m.user_id=$2)"
        ))
        .bind(org_id)
        .bind(uid)
        .fetch_optional(&state.db)
        .await?
    } else if ctx.org_id == Some(org_id) {
        sqlx::query_as(&format!("SELECT {ORG_COLS} FROM organizations WHERE id=$1"))
            .bind(org_id)
            .fetch_optional(&state.db)
            .await?
    } else {
        None
    };
    row.ok_or(ApiError::NotFound)
}

#[utoipa::path(get, path = "/v1/organizations/{org_id}", tag = "organizations", params(("org_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = Organization), (status = 404, body = ErrorBody)))]
pub async fn get(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(org_id): Path<Uuid>,
) -> ApiResult<Json<Organization>> {
    Ok(Json(member_org(&state, &ctx, org_id).await?))
}

#[utoipa::path(post, path = "/v1/organizations/{org_id}/activate", tag = "organizations", params(("org_id" = Uuid, Path, description = "Resource identifier")),
    responses((status = 200, body = MeResponse)))]
pub async fn activate(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Path(org_id): Path<Uuid>,
) -> ApiResult<Json<MeResponse>> {
    let user = ctx.user()?;
    member_org(&state, &ctx, org_id).await?;
    sqlx::query("UPDATE auth_sessions SET active_org_id=$2 WHERE id=$1")
        .bind(ctx.auth_session_id)
        .bind(org_id)
        .execute(&state.db)
        .await?;
    Ok(Json(
        crate::routes::auth::load_me(&state, user, Some(org_id)).await?,
    ))
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct Member {
    pub user_id: Uuid,
    pub email: String,
    pub display_name: String,
    pub role: String,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct PendingInvite {
    pub id: Uuid,
    pub email: String,
    pub role: String,
    #[serde(with = "time::serde::rfc3339")]
    pub expires_at: OffsetDateTime,
}

#[derive(Serialize, ToSchema)]
pub struct MembersResponse {
    pub members: Vec<Member>,
    pub pending_invites: Vec<PendingInvite>,
}

#[utoipa::path(get, path = "/v1/organizations/current/members", tag = "organizations", responses((status = 200, body = MembersResponse)))]
pub async fn members(
    State(state): State<AppState>,
    ctx: AuthCtx,
) -> ApiResult<Json<MembersResponse>> {
    let org = ctx.require(Perm::ReadApps)?;
    let members = sqlx::query_as(
        "SELECT u.id AS user_id, u.email, u.display_name, m.role, m.created_at FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.org_id=$1 ORDER BY m.created_at",
    )
    .bind(org)
    .fetch_all(&state.db)
    .await?;
    let pending_invites = if ctx.require(Perm::ManageMembers).is_ok() {
        sqlx::query_as("SELECT id, email, role, expires_at FROM invites WHERE org_id=$1 AND accepted_at IS NULL AND expires_at > now() ORDER BY created_at DESC")
            .bind(org)
            .fetch_all(&state.db)
            .await?
    } else {
        vec![]
    };
    Ok(Json(MembersResponse {
        members,
        pending_invites,
    }))
}

#[derive(Deserialize, ToSchema)]
pub struct UpdateSettingsRequest {
    pub name: Option<String>,
    pub max_concurrent_sessions: Option<i32>,
    pub max_session_minutes: Option<i32>,
    pub default_session_minutes: Option<i32>,
    pub apk_retention_days: Option<i32>,
}

#[utoipa::path(patch, path = "/v1/organizations/current/settings", request_body = UpdateSettingsRequest, tag = "organizations",
    responses((status = 200, body = Organization)))]
pub async fn update_settings(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<UpdateSettingsRequest>,
) -> ApiResult<Json<Organization>> {
    let org = ctx.require(Perm::ManageSettings)?;
    let check = |v: Option<i32>, lo: i32, hi: i32, f: &str| -> ApiResult<()> {
        match v {
            Some(x) if x < lo || x > hi => {
                Err(ApiError::bad(format!("{f} must be between {lo} and {hi}")))
            }
            _ => Ok(()),
        }
    };
    check(
        req.max_concurrent_sessions,
        0,
        1000,
        "max_concurrent_sessions",
    )?;
    check(req.max_session_minutes, 1, 720, "max_session_minutes")?;
    check(
        req.default_session_minutes,
        1,
        720,
        "default_session_minutes",
    )?;
    check(req.apk_retention_days, 1, 3650, "apk_retention_days")?;
    let updated: Organization = sqlx::query_as(&format!(
        "UPDATE organizations SET
            name = COALESCE($2, name),
            max_concurrent_sessions = COALESCE($3, max_concurrent_sessions),
            max_session_minutes = COALESCE($4, max_session_minutes),
            default_session_minutes = LEAST(COALESCE($5, default_session_minutes), COALESCE($4, max_session_minutes)),
            apk_retention_days = COALESCE($6, apk_retention_days),
            updated_at = now()
         WHERE id=$1 RETURNING {ORG_COLS}"
    ))
    .bind(org)
    .bind(req.name.as_deref().map(str::trim).filter(|s| !s.is_empty()))
    .bind(req.max_concurrent_sessions)
    .bind(req.max_session_minutes)
    .bind(req.default_session_minutes)
    .bind(req.apk_retention_days)
    .fetch_one(&state.db)
    .await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "org.settings_updated",
        Some(("organization", org.to_string())),
        json!({}),
    )
    .await?;
    Ok(Json(updated))
}
