use super::set_cookies;
use crate::audit;
use crate::auth::{self, client_ip_from_headers, AuthCtx};
use crate::error::{ApiError, ApiResult};
use crate::ratelimit;
use crate::AppState;
use axum::extract::{ConnectInfo, Query, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::IntoResponse;
use axum::Json;
use dp_common::roles::{Perm, Role};
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::FromRow;
use std::net::SocketAddr;
use std::str::FromStr;
use time::OffsetDateTime;
use utoipa::{IntoParams, ToSchema};
use uuid::Uuid;

#[derive(Deserialize, ToSchema)]
pub struct LoginRequest {
    pub email: String,
    pub password: String,
}

#[derive(Serialize, ToSchema, FromRow)]
pub struct OrgMembership {
    pub id: Uuid,
    pub name: String,
    pub slug: String,
    pub role: String,
}

#[derive(Serialize, ToSchema)]
pub struct MeResponse {
    pub user_id: Uuid,
    pub email: String,
    pub display_name: String,
    pub active_org_id: Option<Uuid>,
    pub role: Option<String>,
    pub organizations: Vec<OrgMembership>,
}

pub async fn load_me(
    state: &AppState,
    user_id: Uuid,
    active_org: Option<Uuid>,
) -> ApiResult<MeResponse> {
    let (email, display_name): (String, String) =
        sqlx::query_as("SELECT email, display_name FROM users WHERE id=$1")
            .bind(user_id)
            .fetch_one(&state.db)
            .await?;
    let organizations: Vec<OrgMembership> = sqlx::query_as(
        "SELECT o.id, o.name, o.slug, m.role FROM memberships m JOIN organizations o ON o.id = m.org_id WHERE m.user_id=$1 ORDER BY o.name",
    )
    .bind(user_id)
    .fetch_all(&state.db)
    .await?;
    let role = active_org.and_then(|o| {
        organizations
            .iter()
            .find(|m| m.id == o)
            .map(|m| m.role.clone())
    });
    Ok(MeResponse {
        user_id,
        email,
        display_name,
        active_org_id: role.as_ref().and(active_org),
        role,
        organizations,
    })
}

/// Create a cookie session; returns Set-Cookie headers.
async fn start_session(
    state: &AppState,
    user_id: Uuid,
    ip: Option<String>,
    ua: Option<String>,
) -> ApiResult<(HeaderMap, Option<Uuid>)> {
    let token = auth::random_token("", 32);
    let csrf = auth::random_token("", 32);
    let org: Option<Uuid> = sqlx::query_scalar(
        "SELECT org_id FROM memberships WHERE user_id=$1 ORDER BY created_at LIMIT 1",
    )
    .bind(user_id)
    .fetch_optional(&state.db)
    .await?;
    let hours = state.cfg.auth_session_hours;
    sqlx::query(
        "INSERT INTO auth_sessions (id, user_id, token_hash, csrf_hash, active_org_id, ip, user_agent, expires_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7, now() + make_interval(hours => $8))",
    )
    .bind(Uuid::now_v7())
    .bind(user_id)
    .bind(auth::token_hash(&token))
    .bind(auth::token_hash(&csrf))
    .bind(org)
    .bind(ip)
    .bind(ua.map(|u| u.chars().take(256).collect::<String>()))
    .bind(hours as i32)
    .execute(&state.db)
    .await?;
    let mut h = HeaderMap::new();
    set_cookies(
        &mut h,
        &auth::session_cookies(&token, &csrf, state.cfg.cookie_secure, hours * 3600),
    );
    Ok((h, org))
}

fn ua(headers: &HeaderMap) -> Option<String> {
    headers
        .get(axum::http::header::USER_AGENT)
        .and_then(|v| v.to_str().ok())
        .map(String::from)
}

#[utoipa::path(post, path = "/v1/auth/login", request_body = LoginRequest, tag = "auth",
    responses((status = 200, body = MeResponse), (status = 401, body = ErrorBody), (status = 429, body = ErrorBody)))]
pub async fn login(
    State(state): State<AppState>,
    connect: Option<ConnectInfo<SocketAddr>>,
    headers: HeaderMap,
    Json(req): Json<LoginRequest>,
) -> ApiResult<impl IntoResponse> {
    let ip = client_ip_from_headers(&headers, connect.map(|c| c.0), state.cfg.trust_proxy);
    let email = req.email.trim().to_lowercase();
    state.limiter.check(
        &format!("login-ip:{}", ip.as_deref().unwrap_or("?")),
        ratelimit::LOGIN_IP,
    )?;
    state
        .limiter
        .check(&format!("login-email:{email}"), ratelimit::LOGIN_EMAIL)?;
    let user: Option<(Uuid, String)> = sqlx::query_as(
        "SELECT id, password_hash FROM users WHERE email=$1 AND disabled_at IS NULL",
    )
    .bind(&email)
    .fetch_optional(&state.db)
    .await?;
    let pw = req.password;
    let (user_id, ok) = match user {
        Some((id, hash)) => {
            let ok = tokio::task::spawn_blocking(move || auth::verify_password(&pw, &hash))
                .await
                .unwrap_or(false);
            (Some(id), ok)
        }
        None => {
            let _ =
                tokio::task::spawn_blocking(move || auth::verify_password(&pw, auth::dummy_hash()))
                    .await;
            (None, false)
        }
    };
    let Some(user_id) = user_id.filter(|_| ok) else {
        audit::record(
            &state.db,
            None,
            None,
            "auth.login_failed",
            None,
            json!({ "ip": ip }),
        )
        .await?;
        return Err(ApiError::Unauthorized);
    };
    let (cookies, org) = start_session(&state, user_id, ip.clone(), ua(&headers)).await?;
    audit::record(
        &state.db,
        org,
        None,
        "auth.login",
        Some(("user", user_id.to_string())),
        json!({ "ip": ip }),
    )
    .await?;
    let me = load_me(&state, user_id, org).await?;
    Ok((cookies, Json(me)))
}

#[utoipa::path(post, path = "/v1/auth/logout", tag = "auth", responses((status = 204)))]
pub async fn logout(State(state): State<AppState>, ctx: AuthCtx) -> ApiResult<impl IntoResponse> {
    if let Some(sid) = ctx.auth_session_id {
        sqlx::query("UPDATE auth_sessions SET revoked_at = now() WHERE id=$1")
            .bind(sid)
            .execute(&state.db)
            .await?;
        audit::record(
            &state.db,
            ctx.org_id,
            Some(&ctx),
            "auth.logout",
            None,
            json!({}),
        )
        .await?;
    }
    let mut h = HeaderMap::new();
    set_cookies(&mut h, &auth::clear_cookies(state.cfg.cookie_secure));
    Ok((StatusCode::NO_CONTENT, h))
}

#[utoipa::path(get, path = "/v1/auth/me", tag = "auth", responses((status = 200, body = MeResponse), (status = 401, body = ErrorBody)))]
pub async fn me(State(state): State<AppState>, ctx: AuthCtx) -> ApiResult<Json<MeResponse>> {
    Ok(Json(load_me(&state, ctx.user()?, ctx.org_id).await?))
}

#[derive(Deserialize, ToSchema)]
pub struct CreateInviteRequest {
    pub email: String,
    pub role: Role,
}

#[derive(Serialize, ToSchema)]
pub struct CreateInviteResponse {
    pub id: Uuid,
    /// Shown exactly once. Only a hash of the token is stored.
    pub invite_url: String,
    #[serde(with = "time::serde::rfc3339")]
    pub expires_at: OffsetDateTime,
}

#[utoipa::path(post, path = "/v1/auth/invites", request_body = CreateInviteRequest, tag = "auth",
    responses((status = 201, body = CreateInviteResponse), (status = 403, body = ErrorBody)))]
pub async fn create_invite(
    State(state): State<AppState>,
    ctx: AuthCtx,
    Json(req): Json<CreateInviteRequest>,
) -> ApiResult<impl IntoResponse> {
    let org = ctx.require(Perm::ManageMembers)?;
    let user = ctx.user()?;
    state
        .limiter
        .check(&format!("invite:{user}"), ratelimit::INVITE)?;
    let email = req.email.trim().to_lowercase();
    if !email.contains('@') || email.len() > 254 {
        return Err(ApiError::bad("invalid email"));
    }
    if req.role == Role::Owner && ctx.role != Some(Role::Owner) {
        return Err(ApiError::Forbidden("only owners can invite owners".into()));
    }
    let token = auth::random_token("dpi_", 32);
    let id = Uuid::now_v7();
    let expires_at: OffsetDateTime = sqlx::query_scalar(
        "INSERT INTO invites (id, org_id, email, role, token_hash, invited_by, expires_at)
         VALUES ($1,$2,$3,$4,$5,$6, now() + interval '7 days') RETURNING expires_at",
    )
    .bind(id)
    .bind(org)
    .bind(&email)
    .bind(req.role.as_str())
    .bind(auth::token_hash(&token))
    .bind(user)
    .fetch_one(&state.db)
    .await?;
    audit::record(
        &state.db,
        Some(org),
        Some(&ctx),
        "invite.created",
        Some(("invite", id.to_string())),
        json!({ "email": email, "role": req.role.as_str() }),
    )
    .await?;
    let invite_url = format!("{}/accept-invite?token={}", state.cfg.public_url, token);
    Ok((
        StatusCode::CREATED,
        Json(CreateInviteResponse {
            id,
            invite_url,
            expires_at,
        }),
    ))
}

#[derive(Deserialize, IntoParams)]
pub struct InviteInfoQuery {
    pub token: String,
}

#[derive(Serialize, ToSchema)]
pub struct InviteInfo {
    pub email: String,
    pub role: String,
    pub organization_name: String,
    pub existing_user: bool,
}

#[utoipa::path(get, path = "/v1/auth/invite-info", params(InviteInfoQuery), tag = "auth",
    responses((status = 200, body = InviteInfo), (status = 404, body = ErrorBody)))]
pub async fn invite_info(
    State(state): State<AppState>,
    Query(q): Query<InviteInfoQuery>,
) -> ApiResult<Json<InviteInfo>> {
    let (email, role, org_name, existing): (String, String, String, bool) = sqlx::query_as(
        r#"SELECT i.email, i.role, COALESCE(o.name, i.bootstrap_org_name, ''), EXISTS(SELECT 1 FROM users u WHERE u.email = i.email)
           FROM invites i LEFT JOIN organizations o ON o.id = i.org_id
           WHERE i.token_hash=$1 AND i.accepted_at IS NULL AND i.expires_at > now()"#,
    )
    .bind(auth::token_hash(&q.token))
    .fetch_optional(&state.db)
    .await?
    .ok_or(ApiError::NotFound)?;
    Ok(Json(InviteInfo {
        email,
        role,
        organization_name: org_name,
        existing_user: existing,
    }))
}

#[derive(Deserialize, ToSchema)]
pub struct AcceptInviteRequest {
    pub token: String,
    pub password: String,
    pub display_name: Option<String>,
}

#[utoipa::path(post, path = "/v1/auth/accept-invite", request_body = AcceptInviteRequest, tag = "auth",
    responses((status = 200, body = MeResponse), (status = 400, body = ErrorBody), (status = 404, body = ErrorBody)))]
pub async fn accept_invite(
    State(state): State<AppState>,
    connect: Option<ConnectInfo<SocketAddr>>,
    headers: HeaderMap,
    Json(req): Json<AcceptInviteRequest>,
) -> ApiResult<impl IntoResponse> {
    let ip = client_ip_from_headers(&headers, connect.map(|c| c.0), state.cfg.trust_proxy);
    state.limiter.check(
        &format!("accept-ip:{}", ip.as_deref().unwrap_or("?")),
        ratelimit::LOGIN_IP,
    )?;
    let mut tx = state.db.begin().await?;
    let (invite_id, org_id, email, role, bootstrap_org): (
        Uuid,
        Option<Uuid>,
        String,
        String,
        Option<String>,
    ) = sqlx::query_as(
        "SELECT id, org_id, email, role, bootstrap_org_name FROM invites
         WHERE token_hash=$1 AND accepted_at IS NULL AND expires_at > now() FOR UPDATE",
    )
    .bind(auth::token_hash(&req.token))
    .fetch_optional(&mut *tx)
    .await?
    .ok_or(ApiError::NotFound)?;
    let role = Role::from_str(&role).map_err(|e| ApiError::Internal(anyhow::anyhow!(e)))?;

    let existing: Option<(Uuid, String)> =
        sqlx::query_as("SELECT id, password_hash FROM users WHERE email=$1")
            .bind(&email)
            .fetch_optional(&mut *tx)
            .await?;
    let user_id = match existing {
        // Existing users must prove they own the account; invites never reset passwords.
        Some((id, hash)) => {
            let pw = req.password.clone();
            if !tokio::task::spawn_blocking(move || auth::verify_password(&pw, &hash))
                .await
                .unwrap_or(false)
            {
                return Err(ApiError::Unauthorized);
            }
            id
        }
        None => {
            auth::validate_password(&req.password)?;
            let pw = req.password.clone();
            let hash = tokio::task::spawn_blocking(move || auth::hash_password(&pw))
                .await
                .map_err(|e| ApiError::Internal(e.into()))??;
            let id = Uuid::now_v7();
            let name = req
                .display_name
                .unwrap_or_default()
                .trim()
                .chars()
                .take(100)
                .collect::<String>();
            sqlx::query(
                "INSERT INTO users (id, email, display_name, password_hash) VALUES ($1,$2,$3,$4)",
            )
            .bind(id)
            .bind(&email)
            .bind(name)
            .bind(hash)
            .execute(&mut *tx)
            .await?;
            id
        }
    };
    let org_id = match (org_id, bootstrap_org) {
        (Some(o), _) => o,
        (None, Some(name)) => crate::routes::orgs::insert_org(&mut tx, &name).await?,
        (None, None) => {
            return Err(ApiError::Internal(anyhow::anyhow!(
                "invite without organization"
            )))
        }
    };
    sqlx::query(
        "INSERT INTO memberships (id, org_id, user_id, role) VALUES ($1,$2,$3,$4)
         ON CONFLICT (org_id, user_id) DO NOTHING",
    )
    .bind(Uuid::now_v7())
    .bind(org_id)
    .bind(user_id)
    .bind(role.as_str())
    .execute(&mut *tx)
    .await?;
    sqlx::query("UPDATE invites SET accepted_at = now() WHERE id=$1")
        .bind(invite_id)
        .execute(&mut *tx)
        .await?;
    audit::record(
        &mut *tx,
        Some(org_id),
        None,
        "invite.accepted",
        Some(("user", user_id.to_string())),
        json!({ "role": role.as_str() }),
    )
    .await?;
    tx.commit().await?;
    let (cookies, _) = start_session(&state, user_id, ip, ua(&headers)).await?;
    sqlx::query("UPDATE auth_sessions SET active_org_id=$2 WHERE user_id=$1 AND revoked_at IS NULL AND created_at > now() - interval '1 minute'")
        .bind(user_id)
        .bind(org_id)
        .execute(&state.db)
        .await?;
    let me = load_me(&state, user_id, Some(org_id)).await?;
    Ok((cookies, Json(me)))
}
