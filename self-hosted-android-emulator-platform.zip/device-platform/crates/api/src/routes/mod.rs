pub mod agent;
pub mod apps;
pub mod auth;
pub mod hosts;
pub mod misc;
pub mod orgs;
pub mod sessions;

use axum::http::HeaderMap;

pub fn page_limit(limit: Option<i64>) -> i64 {
    limit.unwrap_or(50).clamp(1, 200)
}

pub fn set_cookies(headers: &mut HeaderMap, cookies: &[String]) {
    for c in cookies {
        if let Ok(v) = c.parse() {
            headers.append(axum::http::header::SET_COOKIE, v);
        }
    }
}
