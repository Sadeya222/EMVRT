//! Authentication: Argon2id passwords, opaque session cookies (+ double-submit CSRF), scoped API keys.
use crate::error::ApiError;
use crate::AppState;
use argon2::password_hash::{
    rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString,
};
use argon2::Argon2;
use axum::extract::{ConnectInfo, FromRequestParts};
use axum::http::request::Parts;
use axum::http::{header, HeaderMap, Method};
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use dp_common::roles::{Perm, Role};
use rand::RngCore;
use sha2::{Digest, Sha256};
use sqlx::Row;
use std::net::SocketAddr;
use std::str::FromStr;
use uuid::Uuid;

pub const SESSION_COOKIE: &str = "dp_session";
pub const CSRF_COOKIE: &str = "dp_csrf";
pub const CSRF_HEADER: &str = "x-csrf-token";
pub const API_KEY_PREFIX: &str = "dpk_";
pub const MIN_PASSWORD_LEN: usize = 12;

pub fn hash_password(password: &str) -> anyhow::Result<String> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default() // Argon2id v19
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| anyhow::anyhow!("hash failed: {e}"))
}

pub fn verify_password(password: &str, hash: &str) -> bool {
    PasswordHash::new(hash)
        .map(|h| {
            Argon2::default()
                .verify_password(password.as_bytes(), &h)
                .is_ok()
        })
        .unwrap_or(false)
}

/// A hash of a random password used to equalise timing when the user does not exist.
pub fn dummy_hash() -> &'static str {
    static H: std::sync::OnceLock<String> = std::sync::OnceLock::new();
    H.get_or_init(|| hash_password("dummy-password-for-timing").unwrap())
}

pub fn random_token(prefix: &str, bytes: usize) -> String {
    let mut b = vec![0u8; bytes];
    rand::rngs::OsRng.fill_bytes(&mut b);
    format!("{prefix}{}", URL_SAFE_NO_PAD.encode(b))
}

pub fn token_hash(token: &str) -> Vec<u8> {
    Sha256::digest(token.as_bytes()).to_vec()
}

pub fn constant_eq(a: &[u8], b: &[u8]) -> bool {
    a.len() == b.len() && a.iter().zip(b).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

pub fn validate_password(pw: &str) -> Result<(), ApiError> {
    if pw.chars().count() < MIN_PASSWORD_LEN || pw.len() > 256 {
        return Err(ApiError::bad(format!(
            "password must be {MIN_PASSWORD_LEN}-256 characters"
        )));
    }
    Ok(())
}

pub fn get_cookie(headers: &HeaderMap, name: &str) -> Option<String> {
    headers
        .get_all(header::COOKIE)
        .iter()
        .filter_map(|v| v.to_str().ok())
        .find_map(|v| {
            v.split(';').find_map(|kv| {
                let (k, val) = kv.trim().split_once('=')?;
                (k == name).then(|| val.to_string())
            })
        })
}

pub fn session_cookies(token: &str, csrf: &str, secure: bool, max_age_secs: i64) -> [String; 2] {
    let sec = if secure { "; Secure" } else { "" };
    [
        format!(
            "{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age_secs}{sec}"
        ),
        format!("{CSRF_COOKIE}={csrf}; Path=/; SameSite=Strict; Max-Age={max_age_secs}{sec}"),
    ]
}

pub fn clear_cookies(secure: bool) -> [String; 2] {
    session_cookies("", "", secure, 0)
}

pub fn client_ip(parts: &Parts, trust_proxy: bool) -> Option<String> {
    if trust_proxy {
        if let Some(xff) = parts
            .headers
            .get("x-forwarded-for")
            .and_then(|v| v.to_str().ok())
        {
            if let Some(first) = xff.split(',').next() {
                return Some(first.trim().to_string());
            }
        }
    }
    parts
        .extensions
        .get::<ConnectInfo<SocketAddr>>()
        .map(|c| c.0.ip().to_string())
}

/// The authenticated principal for a request. Handlers obtain the organization ONLY via
/// [`AuthCtx::require`], which guarantees tenancy and permission checks happen together.
#[derive(Debug, Clone)]
pub struct AuthCtx {
    pub user_id: Option<Uuid>,
    pub api_key_id: Option<Uuid>,
    pub auth_session_id: Option<Uuid>,
    pub org_id: Option<Uuid>,
    pub role: Option<Role>,
    pub scopes: Vec<String>,
    pub ip: Option<String>,
}

impl AuthCtx {
    pub fn require(&self, perm: Perm) -> Result<Uuid, ApiError> {
        let org = self
            .org_id
            .ok_or_else(|| ApiError::Forbidden("no active organization".into()))?;
        let allowed = if self.api_key_id.is_some() {
            perm.scope()
                .is_some_and(|s| self.scopes.iter().any(|x| x == s))
        } else {
            self.role.is_some_and(|r| r.allows(perm))
        };
        if allowed {
            Ok(org)
        } else {
            Err(ApiError::Forbidden("insufficient permissions".into()))
        }
    }
    pub fn user(&self) -> Result<Uuid, ApiError> {
        self.user_id
            .ok_or_else(|| ApiError::Forbidden("this endpoint requires a user session".into()))
    }
}

fn origin_allowed(state: &AppState, headers: &HeaderMap) -> bool {
    match headers.get(header::ORIGIN).and_then(|v| v.to_str().ok()) {
        None => true, // non-browser clients; CSRF token still required for cookie auth
        Some(o) => {
            let o = o.trim_end_matches('/');
            o == state.cfg.public_url || state.cfg.cors_origins.iter().any(|a| a == o)
        }
    }
}

#[axum::async_trait]
impl FromRequestParts<AppState> for AuthCtx {
    type Rejection = ApiError;

    async fn from_request_parts(
        parts: &mut Parts,
        state: &AppState,
    ) -> Result<Self, Self::Rejection> {
        let ip = client_ip(parts, state.cfg.trust_proxy);
        // 1) API key
        if let Some(authz) = parts
            .headers
            .get(header::AUTHORIZATION)
            .and_then(|v| v.to_str().ok())
        {
            let key = authz
                .strip_prefix("Bearer ")
                .ok_or(ApiError::Unauthorized)?
                .trim();
            if !key.starts_with(API_KEY_PREFIX) {
                return Err(ApiError::Unauthorized);
            }
            let row = sqlx::query(
                "UPDATE api_keys SET last_used_at = now()
                 WHERE key_hash = $1 AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > now())
                 RETURNING id, org_id, scopes",
            )
            .bind(token_hash(key))
            .fetch_optional(&state.db)
            .await?
            .ok_or(ApiError::Unauthorized)?;
            return Ok(AuthCtx {
                user_id: None,
                api_key_id: Some(row.get("id")),
                auth_session_id: None,
                org_id: Some(row.get("org_id")),
                role: None,
                scopes: row.get("scopes"),
                ip,
            });
        }
        // 2) Session cookie
        let token = get_cookie(&parts.headers, SESSION_COOKIE)
            .filter(|t| !t.is_empty())
            .ok_or(ApiError::Unauthorized)?;
        let row = sqlx::query(
            r#"SELECT s.id, s.user_id, s.csrf_hash, s.active_org_id, m.role
               FROM auth_sessions s
               JOIN users u ON u.id = s.user_id AND u.disabled_at IS NULL
               LEFT JOIN memberships m ON m.user_id = s.user_id AND m.org_id = s.active_org_id
               WHERE s.token_hash = $1 AND s.revoked_at IS NULL AND s.expires_at > now()"#,
        )
        .bind(token_hash(&token))
        .fetch_optional(&state.db)
        .await?
        .ok_or(ApiError::Unauthorized)?;

        let mutating = !matches!(parts.method, Method::GET | Method::HEAD | Method::OPTIONS);
        if mutating {
            if !origin_allowed(state, &parts.headers) {
                return Err(ApiError::Forbidden("origin not allowed".into()));
            }
            let header_token = parts
                .headers
                .get(CSRF_HEADER)
                .and_then(|v| v.to_str().ok())
                .unwrap_or("");
            let expected: Vec<u8> = row.get("csrf_hash");
            if header_token.is_empty() || !constant_eq(&token_hash(header_token), &expected) {
                return Err(ApiError::Forbidden("missing or invalid CSRF token".into()));
            }
        }
        let role: Option<String> = row.get("role");
        let role = role.and_then(|r| Role::from_str(&r).ok());
        Ok(AuthCtx {
            user_id: Some(row.get("user_id")),
            api_key_id: None,
            auth_session_id: Some(row.get("id")),
            // Only expose the org if the membership still exists.
            org_id: role.and(row.get::<Option<Uuid>, _>("active_org_id")),
            role,
            scopes: vec![],
            ip,
        })
    }
}

/// Like [`client_ip`] but for handlers that consume the request body.
pub fn client_ip_from_headers(
    headers: &HeaderMap,
    peer: Option<SocketAddr>,
    trust_proxy: bool,
) -> Option<String> {
    if trust_proxy {
        if let Some(first) = headers
            .get("x-forwarded-for")
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.split(',').next())
        {
            return Some(first.trim().to_string());
        }
    }
    peer.map(|p| p.ip().to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn password_hash_roundtrip() {
        let h = hash_password("correct horse battery").unwrap();
        assert!(h.starts_with("$argon2id$"));
        assert!(verify_password("correct horse battery", &h));
        assert!(!verify_password("wrong", &h));
    }
    #[test]
    fn cookie_parsing() {
        let mut h = HeaderMap::new();
        h.insert(
            header::COOKIE,
            "a=1; dp_session=abc; dp_csrf=xyz".parse().unwrap(),
        );
        assert_eq!(get_cookie(&h, SESSION_COOKIE).as_deref(), Some("abc"));
        assert_eq!(get_cookie(&h, "missing"), None);
    }
    #[test]
    fn scoped_keys() {
        let ctx = AuthCtx {
            user_id: None,
            api_key_id: Some(Uuid::nil()),
            auth_session_id: None,
            org_id: Some(Uuid::nil()),
            role: None,
            scopes: vec!["apps:read".into()],
            ip: None,
        };
        assert!(ctx.require(Perm::ReadApps).is_ok());
        assert!(ctx.require(Perm::WriteApps).is_err());
        assert!(ctx.require(Perm::ManageApiKeys).is_err());
    }
}
