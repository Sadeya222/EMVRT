//! Scheduler integration tests. Require DATABASE_URL pointing at a PostgreSQL server where the
//! test user may create databases (sqlx::test creates an isolated database per test).
use dp_scheduler::{PgScheduler, PlacementRequest, ScheduleError, Scheduler};
use sqlx::PgPool;
use uuid::Uuid;

const PROFILE: &str = "01900000-0000-7000-8000-000000000001";

async fn org(pool: &PgPool, quota: i32) -> Uuid {
    let id = Uuid::now_v7();
    sqlx::query("INSERT INTO organizations (id, name, slug, max_concurrent_sessions) VALUES ($1, 'o', $2, $3)")
        .bind(id)
        .bind(id.to_string())
        .bind(quota)
        .execute(pool)
        .await
        .unwrap();
    id
}

async fn host(pool: &PgPool, org: Uuid, capacity: i32, kvm: bool, online: bool) -> Uuid {
    let id = Uuid::now_v7();
    sqlx::query(
        "INSERT INTO hosts (id, org_id, name, adapter, kvm_available, emulator_capacity, status, last_heartbeat_at)
         VALUES ($1, $2, 'h', 'android-emulator', $3, $4, $5, now())",
    )
    .bind(id)
    .bind(org)
    .bind(kvm)
    .bind(capacity)
    .bind(if online { "online" } else { "offline" })
    .execute(pool)
    .await
    .unwrap();
    id
}

async fn session(pool: &PgPool, org: Uuid) -> Uuid {
    let id = Uuid::now_v7();
    sqlx::query("INSERT INTO sessions (id, org_id, profile_id, state, timeout_minutes) VALUES ($1, $2, $3, 'REQUESTED', 10)")
        .bind(id)
        .bind(org)
        .bind(Uuid::parse_str(PROFILE).unwrap())
        .execute(pool)
        .await
        .unwrap();
    id
}

async fn try_place(pool: &PgPool, org: Uuid, sid: Uuid) -> Result<Uuid, String> {
    let mut tx = pool.begin().await.unwrap();
    let req = PlacementRequest {
        org_id: org,
        session_id: sid,
        profile_id: Uuid::parse_str(PROFILE).unwrap(),
        profile_slug: "pixel-6-api-34".into(),
    };
    match PgScheduler.place(&mut tx, &req).await {
        Ok(p) => {
            sqlx::query("UPDATE sessions SET state = 'ASSIGNED', host_id = $2 WHERE id = $1")
                .bind(sid)
                .bind(p.host_id)
                .execute(&mut *tx)
                .await
                .unwrap();
            tx.commit().await.unwrap();
            Ok(p.host_id)
        }
        Err(e) => {
            tx.rollback().await.unwrap();
            Err(match e {
                ScheduleError::QuotaExceeded { .. } => "quota".into(),
                ScheduleError::NoCapacity(_) => "capacity".into(),
                other => other.to_string(),
            })
        }
    }
}

#[sqlx::test(migrations = "../../migrations")]
async fn concurrent_allocations_never_exceed_capacity(pool: PgPool) {
    let o = org(&pool, 100).await;
    let h = host(&pool, o, 3, true, true).await;
    let mut sids = Vec::new();
    for _ in 0..12 {
        sids.push(session(&pool, o).await);
    }
    let results = futures::future::join_all(sids.iter().map(|s| {
        let pool = pool.clone();
        let s = *s;
        tokio::spawn(async move { try_place(&pool, o, s).await })
    }))
    .await;
    let ok = results.iter().filter(|r| matches!(r, Ok(Ok(_)))).count();
    assert_eq!(
        ok, 3,
        "exactly capacity sessions must be placed: {results:?}"
    );
    let allocated: i32 = sqlx::query_scalar("SELECT allocated_slots FROM hosts WHERE id = $1")
        .bind(h)
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(allocated, 3);
}

#[sqlx::test(migrations = "../../migrations")]
async fn concurrent_allocations_respect_org_quota(pool: PgPool) {
    let o = org(&pool, 2).await;
    host(&pool, o, 10, true, true).await;
    let mut sids = Vec::new();
    for _ in 0..8 {
        sids.push(session(&pool, o).await);
    }
    let results = futures::future::join_all(sids.iter().map(|s| {
        let pool = pool.clone();
        let s = *s;
        tokio::spawn(async move { try_place(&pool, o, s).await })
    }))
    .await;
    let ok = results.iter().filter(|r| matches!(r, Ok(Ok(_)))).count();
    let quota = results
        .iter()
        .filter(|r| matches!(r, Ok(Err(e)) if e == "quota"))
        .count();
    assert_eq!(ok, 2);
    assert_eq!(quota, 6);
}

#[sqlx::test(migrations = "../../migrations")]
async fn skips_unhealthy_and_non_kvm_hosts(pool: PgPool) {
    let o = org(&pool, 10).await;
    host(&pool, o, 5, false, true).await; // no KVM
    host(&pool, o, 5, true, false).await; // offline
    let s = session(&pool, o).await;
    assert_eq!(try_place(&pool, o, s).await, Err("capacity".into()));
    let good = host(&pool, o, 1, true, true).await;
    assert_eq!(try_place(&pool, o, s).await, Ok(good));
}

#[sqlx::test(migrations = "../../migrations")]
async fn never_places_on_other_orgs_hosts(pool: PgPool) {
    let a = org(&pool, 10).await;
    let b = org(&pool, 10).await;
    host(&pool, b, 5, true, true).await;
    let s = session(&pool, a).await;
    assert_eq!(try_place(&pool, a, s).await, Err("capacity".into()));
}

#[sqlx::test(migrations = "../../migrations")]
async fn prefers_warm_devices(pool: PgPool) {
    let o = org(&pool, 10).await;
    let h1 = host(&pool, o, 5, true, true).await;
    let h2 = host(&pool, o, 1, true, true).await;
    sqlx::query("INSERT INTO devices (id, org_id, host_id, profile_id, status) VALUES ($1, $2, $3, $4, 'ready')")
        .bind(Uuid::now_v7())
        .bind(o)
        .bind(h2)
        .bind(Uuid::parse_str(PROFILE).unwrap())
        .execute(&pool)
        .await
        .unwrap();
    let s = session(&pool, o).await;
    assert_eq!(try_place(&pool, o, s).await, Ok(h2));
    let _ = h1;
}
