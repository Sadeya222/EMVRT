//! Session placement.
//!
//! [`PgScheduler`] is a deliberately simple PostgreSQL-backed scheduler. It runs inside the
//! caller's transaction and relies on row-level locks:
//!
//! 1. `organizations … FOR UPDATE` serialises quota checks per organization.
//! 2. A warm `devices` row is claimed with `FOR UPDATE SKIP LOCKED` if one matches the profile.
//! 3. Otherwise a healthy host with free capacity is claimed with `FOR UPDATE SKIP LOCKED` and its
//!    `allocated_slots` counter is incremented in the same transaction.
//!
//! A more advanced scheduler (bin packing, affinity, pre-warming) can implement [`Scheduler`].
use async_trait::async_trait;
use dp_common::SessionState;
use sqlx::{Postgres, Row, Transaction};
use uuid::Uuid;

/// Seconds after which a host without heartbeat is considered unhealthy.
pub const HEARTBEAT_STALE_SECS: i64 = 60;

#[derive(Debug, Clone)]
pub struct PlacementRequest {
    pub org_id: Uuid,
    pub session_id: Uuid,
    pub profile_id: Uuid,
    pub profile_slug: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Placement {
    pub host_id: Uuid,
    /// Set when a pre-warmed device was claimed.
    pub device_id: Option<Uuid>,
}

#[derive(Debug, thiserror::Error)]
pub enum ScheduleError {
    #[error("organization quota exceeded ({active}/{limit} concurrent sessions)")]
    QuotaExceeded { active: i64, limit: i32 },
    #[error("no healthy host with free capacity for profile {0}")]
    NoCapacity(String),
    #[error("organization not found")]
    OrgNotFound,
    #[error(transparent)]
    Db(#[from] sqlx::Error),
}

#[async_trait]
pub trait Scheduler: Send + Sync {
    /// Place a session. Must be called inside a transaction; the placement only becomes
    /// visible (and the capacity claimed) when the caller commits.
    async fn place(
        &self,
        tx: &mut Transaction<'_, Postgres>,
        req: &PlacementRequest,
    ) -> Result<Placement, ScheduleError>;

    /// Return capacity to the pool for a finished session.
    async fn release(
        &self,
        tx: &mut Transaction<'_, Postgres>,
        host_id: Uuid,
        device_id: Option<Uuid>,
    ) -> Result<(), ScheduleError>;
}

#[derive(Debug, Default, Clone)]
pub struct PgScheduler;

#[async_trait]
impl Scheduler for PgScheduler {
    async fn place(
        &self,
        tx: &mut Transaction<'_, Postgres>,
        req: &PlacementRequest,
    ) -> Result<Placement, ScheduleError> {
        let org = sqlx::query(
            "SELECT max_concurrent_sessions FROM organizations WHERE id = $1 FOR UPDATE",
        )
        .bind(req.org_id)
        .fetch_optional(&mut **tx)
        .await?
        .ok_or(ScheduleError::OrgNotFound)?;
        let limit: i32 = org.get(0);
        let holding: Vec<String> = dp_common::SessionState::ALL
            .iter()
            .filter(|s| s.holds_capacity())
            .map(|s| s.as_str().to_string())
            .collect();
        let active: i64 = sqlx::query_scalar(
            "SELECT count(*) FROM sessions WHERE org_id = $1 AND state = ANY($2) AND id <> $3",
        )
        .bind(req.org_id)
        .bind(&holding)
        .bind(req.session_id)
        .fetch_one(&mut **tx)
        .await?;
        if active >= limit as i64 {
            return Err(ScheduleError::QuotaExceeded { active, limit });
        }

        // 1) Prefer a warm, ready device on a healthy host.
        let warm = sqlx::query(
            r#"SELECT d.id, d.host_id FROM devices d
               JOIN hosts h ON h.id = d.host_id AND h.org_id = d.org_id
               WHERE d.org_id = $1 AND d.profile_id = $2 AND d.status = 'ready'
                 AND h.status = 'online' AND (h.kvm_available OR h.adapter = 'fake')
                 AND h.last_heartbeat_at > now() - make_interval(secs => $3)
               ORDER BY d.created_at
               LIMIT 1
               FOR UPDATE OF d SKIP LOCKED"#,
        )
        .bind(req.org_id)
        .bind(req.profile_id)
        .bind(HEARTBEAT_STALE_SECS as f64)
        .fetch_optional(&mut **tx)
        .await?;
        if let Some(row) = warm {
            let device_id: Uuid = row.get(0);
            let host_id: Uuid = row.get(1);
            sqlx::query("UPDATE devices SET status = 'in_use', session_id = $2, updated_at = now() WHERE id = $1")
                .bind(device_id)
                .bind(req.session_id)
                .execute(&mut **tx)
                .await?;
            tracing::info!(%device_id, %host_id, session_id = %req.session_id, "placed on warm device");
            return Ok(Placement {
                host_id,
                device_id: Some(device_id),
            });
        }

        // 2) Otherwise claim a slot on the healthy host with the most free capacity.
        //    Profile compatibility: a host may restrict profiles via labels {"profiles": [...]}.
        let host = sqlx::query(
            r#"SELECT id FROM hosts
               WHERE org_id = $1 AND status = 'online'
                 AND (kvm_available OR adapter = 'fake')
                 AND last_heartbeat_at > now() - make_interval(secs => $2)
                 AND allocated_slots < emulator_capacity
                 AND (NOT (labels ? 'profiles') OR (labels -> 'profiles') ? $3)
               ORDER BY (emulator_capacity - allocated_slots) DESC, id
               LIMIT 1
               FOR UPDATE SKIP LOCKED"#,
        )
        .bind(req.org_id)
        .bind(HEARTBEAT_STALE_SECS as f64)
        .bind(&req.profile_slug)
        .fetch_optional(&mut **tx)
        .await?;
        let Some(row) = host else {
            return Err(ScheduleError::NoCapacity(req.profile_slug.clone()));
        };
        let host_id: Uuid = row.get(0);
        sqlx::query("UPDATE hosts SET allocated_slots = allocated_slots + 1, updated_at = now() WHERE id = $1")
            .bind(host_id)
            .execute(&mut **tx)
            .await?;
        tracing::info!(%host_id, session_id = %req.session_id, "placed on host");
        Ok(Placement {
            host_id,
            device_id: None,
        })
    }

    async fn release(
        &self,
        tx: &mut Transaction<'_, Postgres>,
        host_id: Uuid,
        device_id: Option<Uuid>,
    ) -> Result<(), ScheduleError> {
        if let Some(d) = device_id {
            // Devices are never reused across sessions: they are wiped and destroyed.
            sqlx::query("UPDATE devices SET status = 'wiping', session_id = NULL, updated_at = now() WHERE id = $1")
                .bind(d)
                .execute(&mut **tx)
                .await?;
        } else {
            sqlx::query("UPDATE hosts SET allocated_slots = GREATEST(allocated_slots - 1, 0), updated_at = now() WHERE id = $1")
                .bind(host_id)
                .execute(&mut **tx)
                .await?;
        }
        Ok(())
    }
}

/// Helper used by callers to decide whether a session still holds a slot.
pub fn holds_slot(state: SessionState) -> bool {
    state.holds_capacity()
}
