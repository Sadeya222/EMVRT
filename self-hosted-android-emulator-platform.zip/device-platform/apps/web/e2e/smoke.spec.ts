import { expect, test, type Page } from "@playwright/test";

// The API is mocked via route interception so the smoke test runs without the Rust backend.
const me = { user_id: "u1", email: "dev@example.com", display_name: "Dev", active_org_id: "o1", role: "owner", organizations: [{ id: "o1", name: "Acme", slug: "acme", role: "owner" }] };
const profile = { id: "p1", slug: "pixel-6-api-34", name: "Pixel 6 · Android 14", api_level: 34, abi: "x86_64", screen_width: 1080, screen_height: 2400, density: 420, cpu_cores: 4, ram_mb: 4096 };
const app = { id: "a1", name: "Demo", package_name: "com.example.demo", created_at: new Date().toISOString(), versions: [] as unknown[] };
const session = { id: "01900000-0000-7000-8000-00000000abcd", state: "BOOTING", profile_id: "p1", profile_name: profile.name, screen_width: 1080, screen_height: 2400, api_level: 34, host_id: "h1", host_name: "fake-1", host_adapter: "fake", timeout_minutes: 15, created_at: new Date().toISOString() };

async function mockApi(page: Page) {
  let loggedIn = false;
  await page.route("**/v1/**", async (route) => {
    const url = new URL(route.request().url());
    const m = route.request().method();
    const json = (body: unknown, status = 200) => route.fulfill({ status, contentType: "application/json", body: JSON.stringify(body) });
    const p = url.pathname;
    if (p === "/v1/auth/me") return loggedIn ? json(me) : json({ error: { code: "unauthorized", message: "authentication required" } }, 401);
    if (p === "/v1/auth/login" && m === "POST") { loggedIn = true; return json(me); }
    if (p === "/v1/apps" && m === "GET") return json([{ id: "a1", name: "Demo", package_name: "com.example.demo", version_count: 0, latest_version_name: null, created_at: app.created_at }]);
    if (p === "/v1/apps/a1") return json(app);
    if (p === "/v1/apps/a1/uploads") return json({ version_id: "v1", upload_id: "u1", upload_url: "http://localhost:4173/fake-s3/upload", method: "PUT", expires_at: new Date().toISOString() }, 201);
    if (p === "/v1/apps/a1/versions/v1/finalize") return json({ id: "v1", app_id: "a1", status: "approved", file_name: "demo.apk", package_name: "com.example.demo", version_name: "1.0", version_code: 1, sha256: "ab".repeat(32), size_bytes: 10, created_at: new Date().toISOString() });
    if (p === "/v1/device-profiles") return json([profile]);
    if (p === "/v1/sessions" && m === "POST") return json(session, 201);
    if (p.startsWith("/v1/sessions/") && p.endsWith("/events")) return json([]);
    if (p.startsWith("/v1/sessions/") && p.endsWith("/logs")) return json([]);
    if (p.startsWith("/v1/sessions/")) return json(session);
    if (p === "/v1/sessions") return json([]);
    if (p === "/v1/usage") return json({ active_sessions: 0, max_concurrent_sessions: 2, sessions_30d: 0, session_minutes_30d: 0, apps: 1, hosts_online: 1, by_day: [] });
    if (p === "/v1/hosts") return json([]);
    return json({ error: { code: "not_found", message: "not mocked" } }, 404);
  });
  await page.route("**/fake-s3/**", (route) => route.fulfill({ status: 200, body: "" }));
}

test("login, upload an APK and create a session", async ({ page }) => {
  await mockApi(page);
  await page.goto("/dashboard");
  await expect(page).toHaveURL(/\/login/);
  await page.getByLabel("Email").fill("dev@example.com");
  await page.getByLabel("Password").fill("a-very-long-password");
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("heading", { name: "Overview" })).toBeVisible();

  await page.getByRole("link", { name: "Applications" }).first().click();
  await page.getByRole("link", { name: "Demo" }).click();
  await page.getByRole("button", { name: /upload apk/i }).click();
  await page.getByLabel(/choose or drop/i).setInputFiles({ name: "demo.apk", mimeType: "application/vnd.android.package-archive", buffer: Buffer.from("PK\u0003\u0004demo") });
  await page.getByRole("button", { name: /upload & validate/i }).click();
  await expect(page.getByText("APK approved")).toBeVisible();
  await page.keyboard.press("Escape");

  await page.getByRole("link", { name: "Sessions" }).first().click();
  await page.getByRole("button", { name: /new session/i }).click();
  await expect(page.getByLabel("Device profile")).toHaveValue("p1");
  await page.getByRole("button", { name: /start session/i }).click();
  await expect(page).toHaveURL(/\/sessions\/01900000/);
  await expect(page.getByLabel("Session state: BOOTING")).toBeVisible();
});
