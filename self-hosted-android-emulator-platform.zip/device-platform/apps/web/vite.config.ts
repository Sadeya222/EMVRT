import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  server: {
    port: 5173,
    // Same-origin proxy in development so cookies stay first-party.
    proxy: { "/v1": "http://localhost:8081", "/openapi.json": "http://localhost:8081", "/docs/api": "http://localhost:8081" },
  },
});
