import { useState } from "react";
import { Link, useNavigate, useRouter, useSearch } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, Cpu, Eye, FileCode2, Lock, Server, ShieldCheck, Smartphone, Terminal, Upload } from "lucide-react";
import { api, errorMessage, meQuery } from "@/lib/api";
import { Logo } from "@/components/AppShell";
import { Alert, Button, Card, Field, Input, Spinner } from "@/components/ui";

function PublicHeader() {
  return (
    <header className="border-b border-slate-800/80">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <Link to="/"><Logo /></Link>
        <nav aria-label="Public" className="flex items-center gap-2 text-sm">
          <Link to="/documentation" className="rounded px-3 py-2 text-slate-300 hover:text-white">Docs</Link>
          <a href="/docs" className="hidden rounded px-3 py-2 text-slate-300 hover:text-white sm:inline">API reference</a>
          <Button asChild size="sm"><Link to="/login" search={{ redirect: undefined }}>Sign in</Link></Button>
        </nav>
      </div>
    </header>
  );
}

const FEATURES = [
  { icon: Upload, title: "Private APK pipeline", body: "Direct-to-MinIO presigned uploads, SHA-256, manifest parsing, zip-bomb checks and quarantine before anything is installable." },
  { icon: Server, title: "Bring your own KVM hosts", body: "A Rust agent dials out over WebSocket. No inbound ports, no Docker socket in emulator containers, allow-listed images only." },
  { icon: Smartphone, title: "Live device sessions", body: "Strict session state machine, PostgreSQL row-lock scheduler, timeouts, quotas, and automatic wipe on teardown." },
  { icon: Terminal, title: "Developer tooling", body: "Logcat streaming, screenshots, accessibility tree, tap/swipe/text/deep links, rotation and exportable action history." },
  { icon: ShieldCheck, title: "Secure by default", body: "Argon2id, HttpOnly cookies + CSRF, scoped hashed API keys, audit logs, org isolation in every query." },
  { icon: Eye, title: "Honest streaming", body: "Uses the official emulator WebRTC stack via short-lived tokens — or tells you exactly what is missing." },
];

export function LandingPage() {
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.15),transparent_55%)]">
      <PublicHeader />
      <main>
        <section className="mx-auto max-w-6xl px-4 pb-16 pt-20 text-center sm:px-6">
          <p className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-emerald-800 bg-emerald-950/50 px-3 py-1 text-xs text-emerald-300">
            <Cpu className="h-3.5 w-3.5" aria-hidden /> Self-hosted · Android-only · Runs on your Linux/KVM hosts
          </p>
          <h1 className="mx-auto max-w-3xl text-4xl font-semibold tracking-tight text-white sm:text-6xl">Android emulators in the browser, on infrastructure you own.</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400">Upload APKs, spin up isolated emulator sessions, and debug with logcat, screenshots and the accessibility tree — without paying for a cloud device farm.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg"><Link to="/login" search={{ redirect: undefined }}>Open dashboard <ArrowRight className="h-4 w-4" aria-hidden /></Link></Button>
            <Button asChild size="lg" variant="secondary"><Link to="/documentation">Read the docs</Link></Button>
          </div>
        </section>
        <section aria-labelledby="features" className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
          <h2 id="features" className="sr-only">Features</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <Card key={f.title} className="p-6">
                <f.icon className="h-6 w-6 text-emerald-400" aria-hidden />
                <h3 className="mt-4 font-semibold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.body}</p>
              </Card>
            ))}
          </div>
        </section>
        <section className="mx-auto max-w-6xl px-4 pb-24 sm:px-6">
          <Card className="grid gap-6 p-8 md:grid-cols-3">
            <div className="md:col-span-1">
              <h2 className="text-xl font-semibold text-white">What it is not</h2>
              <p className="mt-2 text-sm text-slate-400">Clear constraints, so nobody is surprised.</p>
            </div>
            <ul className="grid gap-3 text-sm text-slate-300 sm:grid-cols-2 md:col-span-2">
              <li>• No iOS support.</li>
              <li>• Not a free public emulator farm — you run the hosts.</li>
              <li>• Emulator workloads need Linux with KVM.</li>
              <li>• No raw ADB shell or arbitrary commands for users.</li>
              <li>• Review Android image & Google Play Services licensing before commercial use.</li>
              <li>• Public streaming needs TLS, DNS, firewall and TURN planning.</li>
            </ul>
          </Card>
        </section>
      </main>
      <footer className="border-t border-slate-800 py-8 text-center text-xs text-slate-500">Device Platform · Apache-2.0 · Self-hosted</footer>
    </div>
  );
}

const DOC_SECTIONS: { id: string; title: string; body: React.ReactNode }[] = [
  { id: "quick-start", title: "Quick start", body: (<ol className="list-decimal space-y-2 pl-5"><li><code>scripts/dev-setup.sh</code> — generates <code>.env</code> with random secrets.</li><li><code>docker compose up --build</code> — Postgres, MinIO, API, web and Caddy on <code>http://localhost:8080</code>.</li><li><code>scripts/bootstrap.sh you@example.com "Acme"</code> — prints a one-time owner invite link.</li><li>Open the link, set a password, then go to <strong>Hosts → Enroll host</strong>.</li><li>Run the fake agent with the token (command shown in the dialog), then create a session.</li></ol>) },
  { id: "hosts", title: "Emulator hosts", body: (<p>Real emulators require a Linux machine with Docker and <code>/dev/kvm</code>. Install the <code>device-agent</code> binary as a systemd service, configure the image allow-list (<code>image_key → image</code>) and enroll it with a one-time token. The agent connects outbound over WSS; no inbound port is needed for control traffic. See <code>docs/agent-installation.md</code>.</p>) },
  { id: "apks", title: "Uploading APKs", body: (<p>Uploads go directly from the browser to MinIO using a presigned PUT whose signature binds the exact file size. On finalize, the API validates the archive (size, entry count, compression ratios, paths), parses the binary <code>AndroidManifest.xml</code>, computes SHA-256 and approves or rejects the version. Only approved versions can be installed; agents verify the checksum before <code>adb install</code>.</p>) },
  { id: "sessions", title: "Sessions", body: (<p>States: REQUESTED → QUEUED → ASSIGNED → BOOTING → INSTALLING → READY → ACTIVE → ENDING → WIPED (or FAILED / CANCELLED). Sessions end on user action, timeout, host loss or admin action, and the agent destroys the container and its ephemeral volume.</p>) },
  { id: "streaming", title: "Streaming", body: (<p>Browser media is never relayed through the control plane. With <code>STREAM_MODE=gateway</code> the API issues 5-minute HMAC tokens for the host's HTTPS node ingress, which validates them via <code>/v1/stream/verify</code>. If streaming isn't configured the viewer shows <code>stream_unavailable</code> with setup steps. FakeEmulatorAdapter hosts render a simulated display from real screenshots.</p>) },
  { id: "api", title: "API & automation", body: (<p>The REST API lives under <code>/v1</code>; OpenAPI is served at <a className="text-emerald-400 underline" href="/openapi.json">/openapi.json</a> with an explorer at <a className="text-emerald-400 underline" href="/docs">/docs</a>. Create scoped API keys (e.g. <code>sessions:write</code>) for CI and send <code>Authorization: Bearer dpk_…</code>.</p>) },
  { id: "security", title: "Security model", body: (<ul className="list-disc space-y-1 pl-5"><li>Argon2id passwords, invite-only registration.</li><li>HttpOnly session cookie + double-submit CSRF token; no tokens in localStorage.</li><li>Roles: owner, admin, developer, viewer. Scoped API keys stored as hashes.</li><li>Typed agent commands only — no shell, no raw ADB, no arbitrary images.</li><li>Audit log for logins, invites, keys, enrollments, uploads and sessions.</li></ul>) },
];

export function DocsPage() {
  return (
    <div className="min-h-screen">
      <PublicHeader />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[200px_1fr]">
        <nav aria-label="Documentation sections" className="lg:sticky lg:top-6 lg:self-start">
          <ul className="flex flex-wrap gap-2 text-sm lg:flex-col lg:gap-1">
            {DOC_SECTIONS.map((s) => <li key={s.id}><a href={`#${s.id}`} className="block rounded px-2 py-1 text-slate-400 hover:bg-slate-800 hover:text-white">{s.title}</a></li>)}
          </ul>
        </nav>
        <article className="space-y-10">
          <header>
            <h1 className="text-3xl font-semibold text-white">Documentation</h1>
            <p className="mt-2 text-slate-400">The full guides live in the repository's <code>docs/</code> folder. This page summarises the essentials.</p>
          </header>
          {DOC_SECTIONS.map((s) => (
            <section key={s.id} id={s.id} aria-labelledby={`${s.id}-h`} className="scroll-mt-6">
              <h2 id={`${s.id}-h`} className="mb-3 flex items-center gap-2 text-xl font-semibold text-white"><FileCode2 className="h-5 w-5 text-emerald-400" aria-hidden />{s.title}</h2>
              <div className="space-y-3 text-sm leading-relaxed text-slate-300 [&_code]:rounded [&_code]:bg-slate-800 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:text-emerald-200">{s.body}</div>
            </section>
          ))}
        </article>
      </div>
    </div>
  );
}

function safeRedirect(r?: string): string | null {
  if (!r) return null;
  try {
    const u = new URL(r, window.location.origin);
    return u.origin === window.location.origin ? u.pathname + u.search : null;
  } catch {
    return null;
  }
}

export function LoginPage() {
  const search = useSearch({ strict: false }) as { redirect?: string };
  const router = useRouter();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const login = useMutation({
    mutationFn: () => api.auth.login({ email, password }),
    onSuccess: (me) => {
      qc.setQueryData(meQuery.queryKey, me);
      const to = safeRedirect(search.redirect);
      if (to && to !== "/login") router.history.push(to);
      else navigate({ to: "/dashboard" });
    },
  });
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <Card className="w-full max-w-sm p-8">
        <Link to="/" className="mb-6 inline-block"><Logo /></Link>
        <h1 className="text-xl font-semibold text-white">Sign in</h1>
        <p className="mt-1 text-sm text-slate-400">Registration is invite-only.</p>
        <form className="mt-6 space-y-4" onSubmit={(e) => { e.preventDefault(); login.mutate(); }}>
          <Field label="Email" htmlFor="email"><Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field label="Password" htmlFor="password"><Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
          {login.isError && <Alert tone="error">{errorMessage(login.error)}</Alert>}
          <Button type="submit" className="w-full" loading={login.isPending}>Sign in</Button>
        </form>
        <p className="mt-6 flex items-center gap-1.5 text-xs text-slate-500"><Lock className="h-3 w-3" aria-hidden /> Secured with HttpOnly cookies. No tokens are stored in your browser storage.</p>
      </Card>
    </div>
  );
}

export function AcceptInvitePage() {
  const { token } = useSearch({ strict: false }) as { token?: string };
  const navigate = useNavigate();
  const qc = useQueryClient();
  const info = useQuery({ queryKey: ["invite", token], queryFn: () => api.auth.inviteInfo(token!), enabled: !!token, retry: false });
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const accept = useMutation({
    mutationFn: () => api.auth.acceptInvite({ token: token!, password, display_name: name || null }),
    onSuccess: (me) => {
      qc.setQueryData(meQuery.queryKey, me);
      navigate({ to: "/dashboard" });
    },
  });
  const existing = info.data?.existing_user;
  const mismatch = !existing && confirm.length > 0 && password !== confirm;
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <Card className="w-full max-w-md p-8">
        <Link to="/" className="mb-6 inline-block"><Logo /></Link>
        <h1 className="text-xl font-semibold text-white">Accept invitation</h1>
        {!token && <Alert tone="error">This link is missing its invitation token.</Alert>}
        {info.isLoading && <Spinner label="Checking invitation" />}
        {info.isError && <div className="mt-4"><Alert tone="error">This invitation is invalid, expired or already used.</Alert></div>}
        {info.data && (
          <form className="mt-6 space-y-4" onSubmit={(e) => { e.preventDefault(); if (!mismatch) accept.mutate(); }}>
            <p className="text-sm text-slate-300">Join <strong className="text-white">{info.data.organization_name}</strong> as <strong className="text-white">{info.data.role}</strong> with <span className="text-emerald-300">{info.data.email}</span>.</p>
            {existing ? (
              <Field label="Your existing password" htmlFor="pw" hint="You already have an account; confirm it to join."><Input id="pw" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
            ) : (
              <>
                <Field label="Display name" htmlFor="name"><Input id="name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></Field>
                <Field label="Password" htmlFor="pw" hint="At least 12 characters."><Input id="pw" type="password" autoComplete="new-password" minLength={12} required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
                <Field label="Confirm password" htmlFor="pw2"><Input id="pw2" type="password" autoComplete="new-password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} aria-invalid={mismatch} /></Field>
                {mismatch && <p className="text-sm text-red-300">Passwords do not match.</p>}
              </>
            )}
            {accept.isError && <Alert tone="error">{errorMessage(accept.error)}</Alert>}
            <Button type="submit" className="w-full" loading={accept.isPending} disabled={mismatch}>Join organization</Button>
          </form>
        )}
      </Card>
    </div>
  );
}

export function NotFound() {
  return (
    <div className="grid min-h-[60vh] place-items-center px-4 text-center">
      <div>
        <p className="text-sm text-emerald-400">404</p>
        <h1 className="mt-2 text-2xl font-semibold text-white">Page not found</h1>
        <Button asChild className="mt-6" variant="secondary"><Link to="/">Go home</Link></Button>
      </div>
    </div>
  );
}
