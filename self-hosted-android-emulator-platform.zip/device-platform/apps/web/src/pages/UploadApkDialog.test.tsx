import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, expect, it } from "vitest";
import { UploadApkDialog } from "./apps";

function renderDialog() {
  const qc = new QueryClient();
  return render(<QueryClientProvider client={qc}><UploadApkDialog appId="a1" /></QueryClientProvider>);
}

describe("UploadApkDialog", () => {
  it("rejects non-APK files before uploading", async () => {
    const user = userEvent.setup({ applyAccept: false });
    renderDialog();
    await user.click(screen.getByRole("button", { name: /upload apk/i }));
    const input = screen.getByLabelText(/choose or drop/i);
    await user.upload(input, new File(["hello"], "notes.txt", { type: "text/plain" }));
    expect(await screen.findByText(/choose an \.apk file/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /upload & validate/i })).toBeDisabled();
  });
  it("accepts an APK and enables upload", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByRole("button", { name: /upload apk/i }));
    await user.upload(screen.getByLabelText(/choose or drop/i), new File(["PK"], "app.apk", { type: "application/vnd.android.package-archive" }));
    expect(screen.getByRole("button", { name: /upload & validate/i })).toBeEnabled();
  });
});
