import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Play, Smartphone } from "lucide-react";
import { api, errorMessage, meQuery, qk } from "@/lib/api";
import { relativeTime, shortId } from "@/lib/utils";
import { Alert, Button, Card, CardBody, Dialog, DialogContent, DialogTrigger, EmptyState, ErrorState, Field, Input, PageHeader, Select, Spinner, Table, Td, Th } from "@/components/ui";
import { StateBadge } from "@/components/StateBadge";

export function CreateSessionDialog({ defaultAppId }: { defaultAppId?: string }) {
  const [open, setOpen] = useState(false);
  const [profileId, setProfileId] = useState("");
  const [appId, setAppId] = useState(defaultAppId ?? "");
  const [versionId, setVersionId] = useState("");
  const [timeout, setTimeoutMin] = useState(15);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const profiles = useQuery({ queryKey: qk.profiles, queryFn: api.deviceProfiles, enabled: open });
  const apps = useQuery({ queryKey: qk.apps, queryFn: api.apps.list, enabled: open });
  const app = useQuery({ queryKey: qk.app(appId), queryFn: () => api.apps.get(appId), enabled: open && !!appId });
  const approved = app.data?.versions.filter((v) => v.status === "approved") ?? [];
  const create = useMutation({
    mutationFn: () => api.sessions.create({ profile_id: profileId || profiles.data![0].id, app_version_id: versionId || null, timeout_minutes: timeout }),
    onSuccess: (s) => {
      qc.invalidateQueries({ queryKey: ["sessions"] });
      setOpen(false);
      navigate({ to: "/sessions/$sessionId", params: { sessionId: s.id } });
    },
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Play className="h-4 w-4" aria-hidden /> New session</Button></DialogTrigger>
      <DialogContent title="Create session" description="The scheduler picks a healthy host with free capacity in your organization.">
        {profiles.isLoading ? <Spinner /> : profiles.isError ? <ErrorState error={profiles.error} /> : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); create.mutate(); }}>
            <Field label="Device profile" htmlFor="profile">
              <Select id="profile" value={profileId || profiles.data![0]?.id} onChange={(e) => setProfileId(e.target.value)}>
                {profiles.data!.map((p) => <option key={p.id} value={p.id}>{p.name} — {p.screen_width}×{p.screen_height}, API {p.api_level}</option>)}
              </Select>
            </Field>
            <Field label="Application" htmlFor="app" hint="Optional. Leave empty for a blank device.">
              <Select id="app" value={appId} onChange={(e) => { setAppId(e.target.value); setVersionId(""); }}>
                <option value="">No app (blank device)</option>
                {apps.data?.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </Select>
            </Field>
            {appId && (
              <Field label="Version" htmlFor="version" hint={approved.length === 0 && !app.isLoading ? "This app has no approved versions yet." : undefined}>
                <Select id="version" required value={versionId} onChange={(e) => setVersionId(e.target.value)} disabled={approved.length === 0}>
                  <option value="" disabled>Select an approved version</option>
                  {approved.map((v) => <option key={v.id} value={v.id}>{v.version_name} ({v.version_code})</option>)}
                </Select>
              </Field>
            )}
            <Field label="Timeout (minutes)" htmlFor="timeout" hint="The session is wiped automatically when it expires.">
              <Input id="timeout" type="number" min={1} max={720} value={timeout} onChange={(e) => setTimeoutMin(Number(e.target.value))} />
            </Field>
            {create.isError && <Alert tone="error">{errorMessage(create.error)}</Alert>}
            <div className="flex justify-end"><Button type="submit" loading={create.isPending} disabled={!!appId && !versionId}>Start session</Button></div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function SessionsPage() {
  const { data: me } = useQuery(meQuery);
  const [activeOnly, setActiveOnly] = useState(false);
  const sessions = useQuery({ queryKey: qk.sessions(activeOnly), queryFn: () => api.sessions.list({ active: activeOnly, limit: 100 }), refetchInterval: 5_000 });
  return (
    <>
      <PageHeader title="Sessions" description="Session history for your organization." actions={me?.role !== "viewer" && <CreateSessionDialog />} />
      <div className="mb-4 flex items-center gap-2 text-sm">
        <input id="active-only" type="checkbox" className="h-4 w-4 accent-emerald-500" checked={activeOnly} onChange={(e) => setActiveOnly(e.target.checked)} />
        <label htmlFor="active-only" className="text-slate-300">Only live sessions</label>
      </div>
      <Card>
        {sessions.isLoading ? <Spinner /> : sessions.isError ? <CardBody><ErrorState error={sessions.error} retry={sessions.refetch} /></CardBody> : sessions.data!.length === 0 ? (
          <CardBody><EmptyState icon={<Smartphone className="h-8 w-8" />} title="No sessions" description="Sessions you create will appear here." /></CardBody>
        ) : (
          <Table label="Sessions">
            <thead><tr><Th>Session</Th><Th>State</Th><Th>App</Th><Th>Device</Th><Th>Host</Th><Th>Requested</Th><Th>Ended</Th></tr></thead>
            <tbody>
              {sessions.data!.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/30">
                  <Td><Link to="/sessions/$sessionId" params={{ sessionId: s.id }} className="font-mono text-xs text-emerald-300 hover:underline">{shortId(s.id)}</Link></Td>
                  <Td><StateBadge state={s.state} /></Td>
                  <Td>{s.app_name ? `${s.app_name} ${s.version_name ?? ""}` : <span className="text-slate-500">blank</span>}</Td>
                  <Td>{s.profile_name}</Td>
                  <Td>{s.host_name ?? "—"}</Td>
                  <Td>{relativeTime(s.created_at)}<span className="block text-xs text-slate-500">{s.requested_by_email ?? "API key"}</span></Td>
                  <Td>{s.ended_at ? relativeTime(s.ended_at) : "—"}{(s.failure_reason || s.ended_reason) && <span className="block text-xs text-slate-500">{s.failure_reason ?? s.ended_reason}</span>}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
