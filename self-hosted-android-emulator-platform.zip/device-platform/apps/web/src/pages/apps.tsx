import { useRef, useState } from "react";
import { Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AppWindow, ChevronLeft, FileUp, Plus } from "lucide-react";
import { uploadToPresignedUrl, type AppVersion } from "@dp/api-client";
import { api, errorMessage, meQuery, qk } from "@/lib/api";
import { formatBytes, formatDate, relativeTime } from "@/lib/utils";
import { Alert, Badge, Button, Card, CardBody, CardHeader, Dialog, DialogContent, DialogTrigger, EmptyState, ErrorState, Field, Input, PageHeader, Spinner, Table, Td, Th } from "@/components/ui";
import { VersionStatusBadge } from "@/components/StateBadge";

export const MAX_APK_BYTES = 200 * 1024 * 1024;

function CreateAppDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const qc = useQueryClient();
  const create = useMutation({
    mutationFn: () => api.apps.create({ name }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.apps });
      setOpen(false);
      setName("");
    },
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" aria-hidden /> New application</Button></DialogTrigger>
      <DialogContent title="New application" description="An application groups the APK versions you upload.">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); create.mutate(); }}>
          <Field label="Name" htmlFor="app-name"><Input id="app-name" required maxLength={100} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          {create.isError && <Alert tone="error">{errorMessage(create.error)}</Alert>}
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Create</Button></div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function AppsPage() {
  const { data: me } = useQuery(meQuery);
  const apps = useQuery({ queryKey: qk.apps, queryFn: api.apps.list });
  return (
    <>
      <PageHeader title="Applications" description="APKs are private to your organization." actions={me?.role !== "viewer" && <CreateAppDialog />} />
      <Card>
        {apps.isLoading ? <Spinner /> : apps.isError ? <CardBody><ErrorState error={apps.error} retry={apps.refetch} /></CardBody> : apps.data!.length === 0 ? (
          <CardBody><EmptyState icon={<AppWindow className="h-8 w-8" />} title="No applications yet" description="Create an application, then upload an APK version." /></CardBody>
        ) : (
          <Table label="Applications">
            <thead><tr><Th>Name</Th><Th>Package</Th><Th>Versions</Th><Th>Latest approved</Th><Th>Created</Th></tr></thead>
            <tbody>
              {apps.data!.map((a) => (
                <tr key={a.id} className="hover:bg-slate-800/30">
                  <Td><Link to="/apps/$appId" params={{ appId: a.id }} className="font-medium text-white hover:text-emerald-300">{a.name}</Link></Td>
                  <Td><code className="text-xs">{a.package_name ?? "—"}</code></Td>
                  <Td>{a.version_count}</Td>
                  <Td>{a.latest_version_name ?? "—"}</Td>
                  <Td>{relativeTime(a.created_at)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}

type UploadPhase = "idle" | "uploading" | "validating" | "done" | "error";

export function UploadApkDialog({ appId }: { appId: string }) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [phase, setPhase] = useState<UploadPhase>("idle");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AppVersion | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();

  const reset = () => { setFile(null); setPhase("idle"); setProgress(0); setError(null); setResult(null); };
  const choose = (f: File | null) => {
    setError(null);
    if (!f) return setFile(null);
    if (!f.name.toLowerCase().endsWith(".apk")) return setError("Please choose an .apk file.");
    if (f.size > MAX_APK_BYTES) return setError(`File is larger than ${formatBytes(MAX_APK_BYTES)}.`);
    setFile(f);
  };
  const start = async () => {
    if (!file) return;
    try {
      setPhase("uploading");
      const up = await api.apps.createUpload(appId, { file_name: file.name, size_bytes: file.size });
      await uploadToPresignedUrl(up.upload_url, file, setProgress);
      setPhase("validating");
      const v = await api.apps.finalize(appId, up.version_id);
      setResult(v);
      setPhase("done");
      qc.invalidateQueries({ queryKey: qk.app(appId) });
      qc.invalidateQueries({ queryKey: qk.apps });
    } catch (e) {
      setError(errorMessage(e));
      setPhase("error");
    }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogTrigger asChild><Button><FileUp className="h-4 w-4" aria-hidden /> Upload APK</Button></DialogTrigger>
      <DialogContent title="Upload APK" description="The file goes straight to object storage, then is validated and quarantined until approved.">
        {phase === "done" && result ? (
          result.status === "approved" ? (
            <Alert tone="success" title="APK approved">
              <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-xs">
                <dt className="text-emerald-300/70">Package</dt><dd className="font-mono">{result.package_name}</dd>
                <dt className="text-emerald-300/70">Version</dt><dd>{result.version_name} ({result.version_code})</dd>
                <dt className="text-emerald-300/70">SHA-256</dt><dd className="break-all font-mono">{result.sha256}</dd>
              </dl>
            </Alert>
          ) : (
            <Alert tone="error" title="APK rejected">{result.rejection_reason}</Alert>
          )
        ) : (
          <div className="space-y-4">
            <label htmlFor="apk-file" className="flex cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-slate-600 px-6 py-8 text-center hover:border-emerald-500"
              onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); choose(e.dataTransfer.files[0] ?? null); }}>
              <FileUp className="mb-2 h-6 w-6 text-slate-400" aria-hidden />
              <span className="text-sm text-slate-200">{file ? file.name : "Choose or drop an .apk file"}</span>
              <span className="mt-1 text-xs text-slate-500">{file ? formatBytes(file.size) : `Max ${formatBytes(MAX_APK_BYTES)}`}</span>
              <input ref={inputRef} id="apk-file" type="file" accept=".apk,application/vnd.android.package-archive" className="sr-only" onChange={(e) => choose(e.target.files?.[0] ?? null)} disabled={phase === "uploading" || phase === "validating"} />
            </label>
            {phase === "uploading" && (
              <div>
                <div className="mb-1 flex justify-between text-xs text-slate-400"><span>Uploading</span><span>{Math.round(progress * 100)}%</span></div>
                <div className="h-2 overflow-hidden rounded bg-slate-800" role="progressbar" aria-valuenow={Math.round(progress * 100)} aria-valuemin={0} aria-valuemax={100} aria-label="Upload progress">
                  <div className="h-full bg-emerald-500 transition-all" style={{ width: `${progress * 100}%` }} />
                </div>
              </div>
            )}
            {phase === "validating" && <Spinner label="Validating APK (checksum, manifest, zip-bomb checks)" />}
            {error && <Alert tone="error">{error}</Alert>}
            <div className="flex justify-end gap-2">
              <Button onClick={start} disabled={!file} loading={phase === "uploading" || phase === "validating"}>Upload & validate</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function AppDetailPage() {
  const { appId } = useParams({ strict: false }) as { appId: string };
  const { data: me } = useQuery(meQuery);
  const app = useQuery({ queryKey: qk.app(appId), queryFn: () => api.apps.get(appId) });
  if (app.isLoading) return <Spinner />;
  if (app.isError) return <ErrorState error={app.error} retry={app.refetch} />;
  const a = app.data!;
  return (
    <>
      <Link to="/apps" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"><ChevronLeft className="h-4 w-4" aria-hidden /> Applications</Link>
      <PageHeader title={a.name} description={a.package_name ? <code>{a.package_name}</code> : "Package name is set by the first approved upload."} actions={me?.role !== "viewer" && <UploadApkDialog appId={a.id} />} />
      <Card>
        <CardHeader title="Versions" description="Only approved versions can be installed on devices. Expired versions are deleted by the retention policy." />
        {a.versions.length === 0 ? (
          <CardBody><EmptyState title="No versions" description="Upload your first APK to this application." /></CardBody>
        ) : (
          <Table label="Versions">
            <thead><tr><Th>Version</Th><Th>Status</Th><Th>Size</Th><Th>SHA-256</Th><Th>Uploaded</Th><Th>Expires</Th></tr></thead>
            <tbody>
              {a.versions.map((v) => (
                <tr key={v.id}>
                  <Td><span className="font-medium text-white">{v.version_name ?? v.file_name}</span>{v.version_code != null && <span className="ml-1 text-xs text-slate-500">({v.version_code})</span>}{v.min_sdk != null && <Badge className="ml-2">minSdk {v.min_sdk}</Badge>}</Td>
                  <Td><VersionStatusBadge status={v.status} />{v.rejection_reason && <p className="mt-1 max-w-xs text-xs text-red-300">{v.rejection_reason}</p>}</Td>
                  <Td>{formatBytes(v.size_bytes)}</Td>
                  <Td><code className="text-xs" title={v.sha256 ?? undefined}>{v.sha256 ? `${v.sha256.slice(0, 12)}…` : "—"}</code></Td>
                  <Td><span title={formatDate(v.created_at)}>{relativeTime(v.created_at)}</span><span className="block text-xs text-slate-500">{v.uploaded_by_email}</span></Td>
                  <Td>{formatDate(v.expires_at)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
