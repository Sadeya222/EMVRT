import { useState } from "react";
import { Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, Plus, Server } from "lucide-react";
import type { EnrollmentTokenResponse, SessionState } from "@dp/api-client";
import { api, errorMessage, meQuery, qk } from "@/lib/api";
import { formatDate, relativeTime, shortId } from "@/lib/utils";
import { Alert, Badge, Button, Card, CardBody, CardHeader, CopyField, Dialog, DialogContent, DialogTrigger, EmptyState, ErrorState, Field, Input, PageHeader, Spinner, Table, Td, Th } from "@/components/ui";
import { HostStatusBadge, StateBadge } from "@/components/StateBadge";

function EnrollHostDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [token, setToken] = useState<EnrollmentTokenResponse | null>(null);
  const qc = useQueryClient();
  const create = useMutation({ mutationFn: () => api.hosts.enrollmentToken(name), onSuccess: setToken });
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setToken(null); setName(""); qc.invalidateQueries({ queryKey: qk.hosts }); } }}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" aria-hidden /> Enroll host</Button></DialogTrigger>
      <DialogContent title="Enroll a host" description="Creates a one-time token valid for 1 hour. It is shown only once." className="max-w-2xl">
        {!token ? (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); create.mutate(); }}>
            <Field label="Host name" htmlFor="host-name"><Input id="host-name" required maxLength={64} placeholder="kvm-01" value={name} onChange={(e) => setName(e.target.value)} /></Field>
            {create.isError && <Alert tone="error">{errorMessage(create.error)}</Alert>}
            <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Generate token</Button></div>
          </form>
        ) : (
          <div className="space-y-5 text-sm">
            <Alert tone="warn">Copy this token now — it cannot be shown again. It is consumed on first use.</Alert>
            <CopyField label="Enrollment token" value={token.enrollment_token} secret />
            <div>
              <p className="mb-2 font-medium text-white">Local demo (FakeEmulatorAdapter)</p>
              <CopyField label="Fake agent command" value={`AGENT_ENROLLMENT_TOKEN=${token.enrollment_token} docker compose --profile fake-agent up -d fake-agent`} />
            </div>
            <div>
              <p className="mb-2 font-medium text-white">Real Linux/KVM host</p>
              <p className="mb-2 text-slate-400">Install <code>device-agent</code> (see docs/agent-installation.md), put the token in <code>/etc/device-agent/agent.env</code> and start the service:</p>
              <CopyField label="Agent environment" value={`CONTROL_PLANE_URL=${token.control_plane_url} AGENT_ENROLLMENT_TOKEN=${token.enrollment_token}`} />
            </div>
            <p className="text-xs text-slate-500">Expires {formatDate(token.expires_at)}.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function HostsPage() {
  const { data: me } = useQuery(meQuery);
  const hosts = useQuery({ queryKey: qk.hosts, queryFn: api.hosts.list, refetchInterval: 5_000 });
  const isAdmin = me?.role === "owner" || me?.role === "admin";
  return (
    <>
      <PageHeader title="Hosts" description="Customer-owned Linux/KVM machines running device-agent." actions={isAdmin && <EnrollHostDialog />} />
      <Card>
        {hosts.isLoading ? <Spinner /> : hosts.isError ? <CardBody><ErrorState error={hosts.error} retry={hosts.refetch} /></CardBody> : hosts.data!.length === 0 ? (
          <CardBody><EmptyState icon={<Server className="h-8 w-8" />} title="No hosts enrolled" description={isAdmin ? "Enroll a host to start running emulator sessions." : "Ask an admin to enroll a host."} /></CardBody>
        ) : (
          <Table label="Hosts">
            <thead><tr><Th>Name</Th><Th>Status</Th><Th>Adapter</Th><Th>KVM</Th><Th>Capacity</Th><Th>Resources</Th><Th>Last heartbeat</Th></tr></thead>
            <tbody>
              {hosts.data!.map((h) => (
                <tr key={h.id} className="hover:bg-slate-800/30">
                  <Td><Link to="/hosts/$hostId" params={{ hostId: h.id }} className="font-medium text-white hover:text-emerald-300">{h.name}</Link><span className="block text-xs text-slate-500">{h.hostname}</span></Td>
                  <Td><HostStatusBadge status={h.status} connected={h.connected} /></Td>
                  <Td><Badge color={h.adapter === "fake" ? "yellow" : "blue"}>{h.adapter}</Badge></Td>
                  <Td>{h.kvm_available ? <Badge color="green">yes</Badge> : <Badge color={h.adapter === "fake" ? "gray" : "red"}>no</Badge>}</Td>
                  <Td>{h.allocated_slots} / {h.emulator_capacity}</Td>
                  <Td className="text-xs">{h.cpu_count} CPU · {Math.round(h.ram_mb / 1024)} GB RAM · {Math.round(h.disk_free_mb / 1024)} GB free</Td>
                  <Td>{relativeTime(h.last_heartbeat_at)}</Td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}

export function HostDetailPage() {
  const { hostId } = useParams({ strict: false }) as { hostId: string };
  const q = useQuery({ queryKey: qk.host(hostId), queryFn: () => api.hosts.get(hostId), refetchInterval: 5_000 });
  if (q.isLoading) return <Spinner />;
  if (q.isError) return <ErrorState error={q.error} retry={q.refetch} />;
  const { host: h, recent_sessions } = q.data!;
  const rows: [string, React.ReactNode][] = [
    ["Hostname", h.hostname || "—"], ["Operating system", h.os || "—"], ["Docker", h.docker_version ?? "—"], ["Agent version", h.agent_version ?? "—"],
    ["KVM available", h.kvm_available ? "yes" : "no"], ["CPUs", h.cpu_count], ["RAM", `${Math.round(h.ram_mb / 1024)} GB`], ["Disk free", `${Math.round(h.disk_free_mb / 1024)} GB`],
    ["Emulator capacity", h.emulator_capacity], ["Allocated slots", h.allocated_slots], ["Reported active", h.reported_active],
    ["Stream ingress", h.stream_base_url ?? "not configured"], ["Enrolled", formatDate(h.created_at)], ["Last heartbeat", relativeTime(h.last_heartbeat_at)],
  ];
  return (
    <>
      <Link to="/hosts" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"><ChevronLeft className="h-4 w-4" aria-hidden /> Hosts</Link>
      <PageHeader title={h.name} description={<span className="flex items-center gap-2"><HostStatusBadge status={h.status} connected={h.connected} /><Badge color={h.adapter === "fake" ? "yellow" : "blue"}>{h.adapter}</Badge></span>} />
      {h.adapter === "fake" && <div className="mb-6"><Alert tone="warn">This host uses the FakeEmulatorAdapter. It simulates devices for demos and tests; no real Android emulator runs.</Alert></div>}
      {h.adapter !== "fake" && !h.kvm_available && <div className="mb-6"><Alert tone="error">KVM is not available on this host, so the scheduler will not place sessions here.</Alert></div>}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Host report" />
          <CardBody>
            <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-sm">
              {rows.map(([k, v]) => (<div key={k} className="contents"><dt className="text-slate-500">{k}</dt><dd className="text-slate-200">{v}</dd></div>))}
            </dl>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Recent sessions" />
          <CardBody>
            {recent_sessions.length === 0 ? <EmptyState title="No sessions yet" /> : (
              <Table label="Recent sessions">
                <thead><tr><Th>Session</Th><Th>State</Th><Th>Created</Th></tr></thead>
                <tbody>{recent_sessions.map((s) => (
                  <tr key={s.id}><Td><Link to="/sessions/$sessionId" params={{ sessionId: s.id }} className="font-mono text-xs text-emerald-300 hover:underline">{shortId(s.id)}</Link></Td><Td><StateBadge state={s.state as SessionState} /></Td><Td>{relativeTime(s.created_at)}</Td></tr>
                ))}</tbody>
              </Table>
            )}
          </CardBody>
        </Card>
      </div>
    </>
  );
}
