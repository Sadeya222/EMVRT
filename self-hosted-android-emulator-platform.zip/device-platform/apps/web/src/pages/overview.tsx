import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Server, Smartphone, Upload } from "lucide-react";
import { api, meQuery, qk } from "@/lib/api";
import { relativeTime } from "@/lib/utils";
import { Button, Card, CardBody, CardHeader, EmptyState, ErrorState, PageHeader, Spinner, Stat } from "@/components/ui";
import { HostStatusBadge, StateBadge } from "@/components/StateBadge";
import { CreateSessionDialog } from "./sessions";

export function OverviewPage() {
  const { data: me } = useQuery(meQuery);
  const usage = useQuery({ queryKey: qk.usage, queryFn: api.usage, refetchInterval: 10_000 });
  const sessions = useQuery({ queryKey: qk.sessions(true), queryFn: () => api.sessions.list({ active: true }), refetchInterval: 3_000 });
  const hosts = useQuery({ queryKey: qk.hosts, queryFn: api.hosts.list, refetchInterval: 10_000 });
  const org = me?.organizations.find((o) => o.id === me.active_org_id);
  const canWrite = me?.role !== "viewer";
  return (
    <>
      <PageHeader title="Overview" description={org ? `Organization: ${org.name}` : undefined} actions={canWrite && <CreateSessionDialog />} />
      {usage.isError ? <ErrorState error={usage.error} retry={usage.refetch} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Active sessions" value={usage.data ? `${usage.data.active_sessions} / ${usage.data.max_concurrent_sessions}` : "—"} hint="Concurrent quota" />
          <Stat label="Hosts online" value={usage.data?.hosts_online ?? "—"} />
          <Stat label="Applications" value={usage.data?.apps ?? "—"} />
          <Stat label="Session minutes (30d)" value={usage.data?.session_minutes_30d ?? "—"} hint={`${usage.data?.sessions_30d ?? 0} sessions`} />
        </div>
      )}
      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader title="Live sessions" actions={<Button asChild size="sm" variant="secondary"><Link to="/sessions">All sessions</Link></Button>} />
          <CardBody>
            {sessions.isLoading ? <Spinner /> : sessions.isError ? <ErrorState error={sessions.error} /> : sessions.data!.length === 0 ? (
              <EmptyState icon={<Smartphone className="h-8 w-8" />} title="No live sessions" description="Create a session to boot an emulator on one of your hosts." />
            ) : (
              <ul className="divide-y divide-slate-800">
                {sessions.data!.map((s) => (
                  <li key={s.id}>
                    <Link to="/sessions/$sessionId" params={{ sessionId: s.id }} className="flex items-center justify-between gap-3 rounded px-2 py-3 hover:bg-slate-800/50">
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium text-white">{s.app_name ? `${s.app_name} ${s.version_name ?? ""}` : "Blank device"}</span>
                        <span className="block text-xs text-slate-500">{s.profile_name} · {s.host_name ?? "unassigned"} · {relativeTime(s.created_at)}</span>
                      </span>
                      <StateBadge state={s.state} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title="Hosts" actions={<Button asChild size="sm" variant="secondary"><Link to="/hosts">Manage</Link></Button>} />
          <CardBody>
            {hosts.isLoading ? <Spinner /> : hosts.data?.length === 0 ? (
              <EmptyState icon={<Server className="h-8 w-8" />} title="No hosts enrolled" description="Enroll a Linux/KVM host — or the fake agent for a local demo." action={<Button asChild size="sm"><Link to="/hosts">Enroll a host</Link></Button>} />
            ) : (
              <ul className="space-y-3">
                {hosts.data?.map((h) => (
                  <li key={h.id} className="flex items-center justify-between gap-2 text-sm">
                    <Link to="/hosts/$hostId" params={{ hostId: h.id }} className="truncate text-slate-200 hover:text-white">{h.name} <span className="text-xs text-slate-500">({h.adapter})</span></Link>
                    <span className="flex items-center gap-2 text-xs text-slate-500">{h.allocated_slots}/{h.emulator_capacity}<HostStatusBadge status={h.status} connected={h.connected} /></span>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
      <Card className="mt-6">
        <CardHeader title="Getting started" />
        <CardBody>
          <ol className="grid gap-4 text-sm sm:grid-cols-3">
            <li className="rounded-lg border border-slate-800 p-4"><Server className="mb-2 h-5 w-5 text-emerald-400" aria-hidden /><strong className="text-white">1. Enroll a host</strong><p className="mt-1 text-slate-400">Generate a one-time token and start <code>device-agent</code>.</p></li>
            <li className="rounded-lg border border-slate-800 p-4"><Upload className="mb-2 h-5 w-5 text-emerald-400" aria-hidden /><strong className="text-white">2. Upload an APK</strong><p className="mt-1 text-slate-400">It is validated and quarantined until approved.</p></li>
            <li className="rounded-lg border border-slate-800 p-4"><Smartphone className="mb-2 h-5 w-5 text-emerald-400" aria-hidden /><strong className="text-white">3. Start a session</strong><p className="mt-1 text-slate-400">Pick a device profile and debug in the browser.</p></li>
          </ol>
        </CardBody>
      </Card>
    </>
  );
}
