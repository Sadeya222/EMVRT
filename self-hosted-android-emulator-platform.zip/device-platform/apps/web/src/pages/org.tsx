import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { FileClock, KeyRound, Plus, UserPlus } from "lucide-react";
import type { CreateApiKeyResponse, CreateInviteResponse, Role } from "@dp/api-client";
import { api, errorMessage, meQuery, qk } from "@/lib/api";
import { formatDate, relativeTime } from "@/lib/utils";
import { Alert, Badge, Button, Card, CardBody, CardHeader, CopyField, Dialog, DialogContent, DialogTrigger, EmptyState, ErrorState, Field, Input, PageHeader, Select, Spinner, Stat, Table, Td, Th } from "@/components/ui";

function useIsAdmin() {
  const { data: me } = useQuery(meQuery);
  return { me, isAdmin: me?.role === "owner" || me?.role === "admin" };
}

function InviteDialog() {
  const { me } = useIsAdmin();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("developer");
  const [result, setResult] = useState<CreateInviteResponse | null>(null);
  const qc = useQueryClient();
  const invite = useMutation({ mutationFn: () => api.auth.invite({ email, role }), onSuccess: (r) => { setResult(r); qc.invalidateQueries({ queryKey: qk.members }); } });
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setResult(null); setEmail(""); } }}>
      <DialogTrigger asChild><Button><UserPlus className="h-4 w-4" aria-hidden /> Invite member</Button></DialogTrigger>
      <DialogContent title="Invite member" description="Registration is invite-only. Share the link through a trusted channel.">
        {result ? (
          <div className="space-y-3">
            <Alert tone="warn">This link is shown once and expires {formatDate(result.expires_at)}.</Alert>
            <CopyField label="Invite link" value={result.invite_url} secret />
          </div>
        ) : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); invite.mutate(); }}>
            <Field label="Email" htmlFor="inv-email"><Input id="inv-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
            <Field label="Role" htmlFor="inv-role">
              <Select id="inv-role" value={role} onChange={(e) => setRole(e.target.value as Role)}>
                <option value="viewer">Viewer — read-only</option>
                <option value="developer">Developer — apps & sessions</option>
                <option value="admin">Admin — hosts, keys, members</option>
                {me?.role === "owner" && <option value="owner">Owner</option>}
              </Select>
            </Field>
            {invite.isError && <Alert tone="error">{errorMessage(invite.error)}</Alert>}
            <div className="flex justify-end"><Button type="submit" loading={invite.isPending}>Create invite</Button></div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function MembersPage() {
  const { isAdmin } = useIsAdmin();
  const q = useQuery({ queryKey: qk.members, queryFn: api.orgs.members });
  return (
    <>
      <PageHeader title="Members" description="People with access to this organization." actions={isAdmin && <InviteDialog />} />
      {q.isLoading ? <Spinner /> : q.isError ? <ErrorState error={q.error} retry={q.refetch} /> : (
        <div className="space-y-6">
          <Card>
            <Table label="Members">
              <thead><tr><Th>Member</Th><Th>Role</Th><Th>Joined</Th></tr></thead>
              <tbody>{q.data!.members.map((m) => (
                <tr key={m.user_id}><Td><span className="text-white">{m.display_name || m.email}</span><span className="block text-xs text-slate-500">{m.email}</span></Td><Td><Badge color={m.role === "owner" ? "purple" : m.role === "admin" ? "blue" : "gray"}>{m.role}</Badge></Td><Td>{formatDate(m.created_at)}</Td></tr>
              ))}</tbody>
            </Table>
          </Card>
          {isAdmin && (
            <Card>
              <CardHeader title="Pending invitations" />
              {q.data!.pending_invites.length === 0 ? <CardBody><EmptyState title="No pending invitations" /></CardBody> : (
                <Table label="Pending invitations">
                  <thead><tr><Th>Email</Th><Th>Role</Th><Th>Expires</Th></tr></thead>
                  <tbody>{q.data!.pending_invites.map((i) => <tr key={i.id}><Td>{i.email}</Td><Td>{i.role}</Td><Td>{relativeTime(i.expires_at)}</Td></tr>)}</tbody>
                </Table>
              )}
            </Card>
          )}
        </div>
      )}
    </>
  );
}

const SCOPES = ["apps:read", "apps:write", "sessions:read", "sessions:write", "hosts:read", "usage:read"];

function CreateKeyDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [scopes, setScopes] = useState<string[]>(["sessions:read", "sessions:write"]);
  const [days, setDays] = useState<string>("90");
  const [created, setCreated] = useState<CreateApiKeyResponse | null>(null);
  const qc = useQueryClient();
  const create = useMutation({
    mutationFn: () => api.apiKeys.create({ name, scopes, expires_in_days: days ? Number(days) : null }),
    onSuccess: (r) => { setCreated(r); qc.invalidateQueries({ queryKey: qk.apiKeys }); },
  });
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setCreated(null); setName(""); } }}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" aria-hidden /> Create key</Button></DialogTrigger>
      <DialogContent title="Create API key" description="Keys are bound to this organization and limited to the selected scopes.">
        {created ? (
          <div className="space-y-3">
            <Alert tone="warn" title="Copy your key now">It is stored only as a hash and will never be shown again.</Alert>
            <CopyField label="API key" value={created.secret} secret />
          </div>
        ) : (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); create.mutate(); }}>
            <Field label="Name" htmlFor="key-name"><Input id="key-name" required maxLength={64} placeholder="ci-pipeline" value={name} onChange={(e) => setName(e.target.value)} /></Field>
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-slate-300">Scopes</legend>
              <div className="grid grid-cols-2 gap-2">
                {SCOPES.map((s) => (
                  <label key={s} className="flex items-center gap-2 text-sm text-slate-300">
                    <input type="checkbox" className="h-4 w-4 accent-emerald-500" checked={scopes.includes(s)} onChange={(e) => setScopes(e.target.checked ? [...scopes, s] : scopes.filter((x) => x !== s))} />
                    <code className="text-xs">{s}</code>
                  </label>
                ))}
              </div>
            </fieldset>
            <Field label="Expires in (days)" htmlFor="key-days" hint="1–365. Leave empty for no expiry (not recommended)."><Input id="key-days" type="number" min={1} max={365} value={days} onChange={(e) => setDays(e.target.value)} /></Field>
            {create.isError && <Alert tone="error">{errorMessage(create.error)}</Alert>}
            <div className="flex justify-end"><Button type="submit" loading={create.isPending} disabled={scopes.length === 0}>Create key</Button></div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function ApiKeysPage() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: qk.apiKeys, queryFn: api.apiKeys.list });
  const revoke = useMutation({ mutationFn: (id: string) => api.apiKeys.revoke(id), onSuccess: () => qc.invalidateQueries({ queryKey: qk.apiKeys }) });
  return (
    <>
      <PageHeader title="API keys" description="Scoped keys for CI and automation. Use Authorization: Bearer dpk_…" actions={<CreateKeyDialog />} />
      <Card>
        {q.isLoading ? <Spinner /> : q.isError ? <CardBody><ErrorState error={q.error} retry={q.refetch} /></CardBody> : q.data!.length === 0 ? (
          <CardBody><EmptyState icon={<KeyRound className="h-8 w-8" />} title="No API keys" description="Create a key to call the API from scripts or CI." /></CardBody>
        ) : (
          <Table label="API keys">
            <thead><tr><Th>Name</Th><Th>Prefix</Th><Th>Scopes</Th><Th>Last used</Th><Th>Expires</Th><Th><span className="sr-only">Actions</span></Th></tr></thead>
            <tbody>{q.data!.map((k) => (
              <tr key={k.id}>
                <Td className="text-white">{k.name}{k.revoked_at && <Badge color="red" className="ml-2">revoked</Badge>}</Td>
                <Td><code className="text-xs">{k.prefix}…</code></Td>
                <Td><div className="flex flex-wrap gap-1">{k.scopes.map((s) => <Badge key={s}>{s}</Badge>)}</div></Td>
                <Td>{relativeTime(k.last_used_at)}</Td>
                <Td>{k.expires_at ? formatDate(k.expires_at) : "never"}</Td>
                <Td>{!k.revoked_at && <Button size="sm" variant="danger" onClick={() => { if (confirm(`Revoke key "${k.name}"? This cannot be undone.`)) revoke.mutate(k.id); }}>Revoke</Button>}</Td>
              </tr>
            ))}</tbody>
          </Table>
        )}
      </Card>
    </>
  );
}

export function UsagePage() {
  const q = useQuery({ queryKey: qk.usage, queryFn: api.usage, refetchInterval: 15_000 });
  if (q.isLoading) return <Spinner />;
  if (q.isError) return <ErrorState error={q.error} retry={q.refetch} />;
  const u = q.data!;
  const max = Math.max(1, ...u.by_day.map((d) => d.minutes));
  return (
    <>
      <PageHeader title="Usage" description="Metered from session lifecycle events. Self-hosted: no billing, just visibility." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Active sessions" value={`${u.active_sessions} / ${u.max_concurrent_sessions}`} />
        <Stat label="Sessions (30d)" value={u.sessions_30d} />
        <Stat label="Session minutes (30d)" value={u.session_minutes_30d} />
        <Stat label="Hosts online" value={u.hosts_online} />
      </div>
      <Card className="mt-6">
        <CardHeader title="Session minutes — last 14 days" />
        <CardBody>
          <div className="flex h-48 items-end gap-2" role="img" aria-label="Bar chart of session minutes per day">
            {u.by_day.map((d) => (
              <div key={d.day} className="flex flex-1 flex-col items-center gap-1">
                <div className="w-full rounded-t bg-emerald-500/80" style={{ height: `${(d.minutes / max) * 100}%`, minHeight: d.minutes ? 4 : 1 }} title={`${d.day}: ${d.minutes} min, ${d.sessions} sessions`} />
                <span className="text-[10px] text-slate-500">{d.day.slice(5)}</span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </>
  );
}

export function SettingsPage() {
  const { me } = useIsAdmin();
  const qc = useQueryClient();
  const orgId = me?.active_org_id ?? "";
  const org = useQuery({ queryKey: qk.org(orgId), queryFn: () => api.orgs.get(orgId), enabled: !!orgId });
  const [form, setForm] = useState<Record<string, string>>({});
  const save = useMutation({
    mutationFn: () => api.orgs.updateSettings({
      name: form.name ?? null,
      max_concurrent_sessions: form.max_concurrent_sessions ? Number(form.max_concurrent_sessions) : null,
      max_session_minutes: form.max_session_minutes ? Number(form.max_session_minutes) : null,
      default_session_minutes: form.default_session_minutes ? Number(form.default_session_minutes) : null,
      apk_retention_days: form.apk_retention_days ? Number(form.apk_retention_days) : null,
    }),
    onSuccess: () => { setForm({}); qc.invalidateQueries({ queryKey: qk.org(orgId) }); qc.invalidateQueries({ queryKey: meQuery.queryKey }); },
  });
  if (org.isLoading) return <Spinner />;
  if (org.isError) return <ErrorState error={org.error} retry={org.refetch} />;
  const o = org.data!;
  const val = (k: keyof typeof o) => form[k as string] ?? String(o[k]);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });
  return (
    <>
      <PageHeader title="Settings" description="Organization policies: quotas, session timeouts and APK retention." />
      <Card className="max-w-2xl">
        <CardBody>
          <form className="grid gap-5 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); save.mutate(); }}>
            <div className="sm:col-span-2"><Field label="Organization name" htmlFor="s-name"><Input id="s-name" value={val("name")} onChange={set("name")} /></Field></div>
            <Field label="Max concurrent sessions" htmlFor="s-conc"><Input id="s-conc" type="number" min={0} max={1000} value={val("max_concurrent_sessions")} onChange={set("max_concurrent_sessions")} /></Field>
            <Field label="APK retention (days)" htmlFor="s-ret" hint="Approved APKs are deleted after this period."><Input id="s-ret" type="number" min={1} max={3650} value={val("apk_retention_days")} onChange={set("apk_retention_days")} /></Field>
            <Field label="Default session timeout (min)" htmlFor="s-def"><Input id="s-def" type="number" min={1} max={720} value={val("default_session_minutes")} onChange={set("default_session_minutes")} /></Field>
            <Field label="Maximum session timeout (min)" htmlFor="s-max"><Input id="s-max" type="number" min={1} max={720} value={val("max_session_minutes")} onChange={set("max_session_minutes")} /></Field>
            <div className="sm:col-span-2">
              {save.isError && <Alert tone="error">{errorMessage(save.error)}</Alert>}
              {save.isSuccess && <Alert tone="success">Settings saved.</Alert>}
            </div>
            <div className="sm:col-span-2 flex justify-end"><Button type="submit" loading={save.isPending} disabled={Object.keys(form).length === 0}>Save changes</Button></div>
          </form>
        </CardBody>
      </Card>
    </>
  );
}

export function AuditLogPage() {
  const [action, setAction] = useState("");
  const q = useQuery({ queryKey: qk.audit(action || undefined), queryFn: () => api.auditLogs({ limit: 200, action: action || undefined }) });
  return (
    <>
      <PageHeader title="Audit log" description="Security-sensitive actions in this organization." />
      <div className="mb-4 max-w-xs"><Select aria-label="Filter by action" value={action} onChange={(e) => setAction(e.target.value)}>
        <option value="">All actions</option>
        {["auth", "invite", "api_key", "host", "apk", "app", "session", "stream", "org"].map((a) => <option key={a} value={a}>{a}.*</option>)}
      </Select></div>
      <Card>
        {q.isLoading ? <Spinner /> : q.isError ? <CardBody><ErrorState error={q.error} retry={q.refetch} /></CardBody> : q.data!.length === 0 ? (
          <CardBody><EmptyState icon={<FileClock className="h-8 w-8" />} title="No audit events" /></CardBody>
        ) : (
          <Table label="Audit log">
            <thead><tr><Th>When</Th><Th>Action</Th><Th>Actor</Th><Th>Target</Th><Th>IP</Th></tr></thead>
            <tbody>{q.data!.map((l) => (
              <tr key={l.id}>
                <Td className="whitespace-nowrap">{formatDate(l.created_at)}</Td>
                <Td><code className="text-xs text-emerald-200">{l.action}</code></Td>
                <Td>{l.actor_email ?? (l.actor_api_key_id ? "API key" : "system")}</Td>
                <Td className="text-xs">{l.target_type ? `${l.target_type}:${l.target_id?.slice(-8)}` : "—"}</Td>
                <Td className="text-xs">{l.ip ?? "—"}</Td>
              </tr>
            ))}</tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
