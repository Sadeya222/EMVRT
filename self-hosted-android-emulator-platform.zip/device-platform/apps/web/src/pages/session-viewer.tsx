import { useState } from "react";
import { Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ChevronLeft, Circle, Home, Link2, RotateCcw, RotateCw, Square, Type } from "lucide-react";
import type { InputAction } from "@dp/api-client";
import { api, errorMessage, meQuery, qk } from "@/lib/api";
import { useUi } from "@/lib/store";
import { formatDate, relativeTime, shortId } from "@/lib/utils";
import { Alert, Badge, Button, Card, CardBody, ErrorState, Input, Spinner, Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui";
import { isInteractive, isTerminal, StateBadge } from "@/components/StateBadge";
import { DeviceDisplay } from "@/components/session/DeviceDisplay";
import { ActionHistoryPanel, LogcatPanel, ScreenshotPanel, UiTreePanel } from "@/components/session/Panels";

export function SessionViewerPage() {
  const { sessionId } = useParams({ strict: false }) as { sessionId: string };
  const { data: me } = useQuery(meQuery);
  const qc = useQueryClient();
  const { sessionPanel, setSessionPanel } = useUi();
  const [refreshKey, setRefreshKey] = useState(0);
  const [text, setText] = useState("");
  const [link, setLink] = useState("");
  const session = useQuery({
    queryKey: qk.session(sessionId),
    queryFn: () => api.sessions.get(sessionId),
    refetchInterval: (q) => (q.state.data && isTerminal(q.state.data.state) ? false : 2000),
  });
  const action = useMutation({
    mutationFn: (a: InputAction) => api.sessions.action(sessionId, a),
    onSettled: () => {
      setRefreshKey((k) => k + 1);
      qc.invalidateQueries({ queryKey: ["session", sessionId, "events"] });
    },
  });
  const end = useMutation({ mutationFn: () => api.sessions.end(sessionId), onSuccess: (s) => qc.setQueryData(qk.session(sessionId), s) });

  if (session.isLoading) return <Spinner label="Loading session" />;
  if (session.isError) return <ErrorState error={session.error} retry={session.refetch} />;
  const s = session.data!;
  const live = isInteractive(s.state);
  const canControl = live && me?.role !== "viewer";
  const send = (a: InputAction) => canControl && action.mutate(a);

  return (
    <>
      <Link to="/sessions" className="mb-4 inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"><ChevronLeft className="h-4 w-4" aria-hidden /> Sessions</Link>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex flex-wrap items-center gap-3 text-2xl font-semibold text-white">
            Session <span className="font-mono text-lg text-slate-400">{shortId(s.id)}</span> <StateBadge state={s.state} />
            {s.host_adapter === "fake" && <Badge color="yellow">fake adapter</Badge>}
          </h1>
          <p className="mt-1 text-sm text-slate-400">{s.app_name ? `${s.app_name} ${s.version_name ?? ""}` : "Blank device"} · {s.profile_name}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {!isTerminal(s.state) && s.state !== "ENDING" && me?.role !== "viewer" && (
            <Button variant="danger" onClick={() => end.mutate()} loading={end.isPending}><Square className="h-4 w-4" aria-hidden /> Stop session</Button>
          )}
          {isTerminal(s.state) && me?.role !== "viewer" && <Button asChild variant="secondary"><Link to="/sessions">Start another</Link></Button>}
        </div>
      </div>
      {s.failure_reason && <div className="mb-4"><Alert tone="error" title="Session failed">{s.failure_reason}</Alert></div>}
      {action.isError && <div className="mb-4"><Alert tone="error">{errorMessage(action.error)}</Alert></div>}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <div className="space-y-4">
          <DeviceDisplay session={s} onAction={send} refreshKey={refreshKey} />
          <Card>
            <CardBody className="space-y-4">
              <div className="flex flex-wrap items-center gap-2" role="toolbar" aria-label="Device controls">
                <Button size="sm" variant="secondary" disabled={!canControl} onClick={() => send({ type: "key", key: "back" })}><ArrowLeft className="h-4 w-4" aria-hidden /> Back</Button>
                <Button size="sm" variant="secondary" disabled={!canControl} onClick={() => send({ type: "key", key: "home" })}><Home className="h-4 w-4" aria-hidden /> Home</Button>
                <Button size="sm" variant="secondary" disabled={!canControl} onClick={() => send({ type: "key", key: "app_switch" })}><Circle className="h-4 w-4" aria-hidden /> Recents</Button>
                <span className="mx-1 h-6 w-px bg-slate-800" aria-hidden />
                <Button size="sm" variant="secondary" disabled={!canControl} onClick={() => send({ type: "rotate", orientation: "portrait" })} aria-label="Rotate to portrait"><RotateCcw className="h-4 w-4" aria-hidden /> Portrait</Button>
                <Button size="sm" variant="secondary" disabled={!canControl} onClick={() => send({ type: "rotate", orientation: "landscape" })} aria-label="Rotate to landscape"><RotateCw className="h-4 w-4" aria-hidden /> Landscape</Button>
              </div>
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (text) { send({ type: "text", text }); setText(""); } }}>
                <Input aria-label="Text to type on device" placeholder="Type text into the focused field" value={text} maxLength={500} onChange={(e) => setText(e.target.value)} disabled={!canControl} />
                <Button type="submit" variant="secondary" disabled={!canControl || !text}><Type className="h-4 w-4" aria-hidden /> Send</Button>
              </form>
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (link) send({ type: "deep_link", uri: link }); }}>
                <Input aria-label="Deep link URI" placeholder="myapp://path or https://…" value={link} maxLength={2048} onChange={(e) => setLink(e.target.value)} disabled={!canControl} />
                <Button type="submit" variant="secondary" disabled={!canControl || !link}><Link2 className="h-4 w-4" aria-hidden /> Open</Button>
              </form>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-2 border-t border-slate-800 pt-4 text-sm sm:grid-cols-3">
                <div><dt className="text-xs text-slate-500">Device</dt><dd className="text-slate-200">{s.profile_name}</dd></div>
                <div><dt className="text-xs text-slate-500">Screen</dt><dd className="text-slate-200">{s.screen_width}×{s.screen_height} · API {s.api_level}</dd></div>
                <div><dt className="text-xs text-slate-500">Host</dt><dd className="text-slate-200">{s.host_name ?? "—"}</dd></div>
                <div><dt className="text-xs text-slate-500">Package</dt><dd className="truncate font-mono text-xs text-slate-200">{s.package_name ?? "—"}</dd></div>
                <div><dt className="text-xs text-slate-500">Timeout</dt><dd className="text-slate-200">{s.timeout_minutes} min</dd></div>
                <div><dt className="text-xs text-slate-500">{live ? "Expires" : "Ended"}</dt><dd className="text-slate-200" title={formatDate(s.expires_at ?? s.ended_at)}>{live ? relativeTime(s.expires_at) : formatDate(s.ended_at)}</dd></div>
              </dl>
            </CardBody>
          </Card>
        </div>
        <Card className="flex min-h-[32rem] flex-col overflow-hidden">
          <Tabs value={sessionPanel} onValueChange={(v) => setSessionPanel(v as typeof sessionPanel)} className="flex flex-1 flex-col">
            <TabsList aria-label="Session tools">
              <TabsTrigger value="logcat">Logcat</TabsTrigger>
              <TabsTrigger value="tree">Accessibility tree</TabsTrigger>
              <TabsTrigger value="screenshots">Screenshots</TabsTrigger>
              <TabsTrigger value="history">Action history</TabsTrigger>
            </TabsList>
            <TabsContent value="logcat" className="flex flex-1 flex-col"><LogcatPanel sessionId={s.id} live={!isTerminal(s.state)} /></TabsContent>
            <TabsContent value="tree"><UiTreePanel session={s} onAction={send} live={live} /></TabsContent>
            <TabsContent value="screenshots"><ScreenshotPanel sessionId={s.id} live={live} /></TabsContent>
            <TabsContent value="history"><ActionHistoryPanel session={s} live={!isTerminal(s.state)} /></TabsContent>
          </Tabs>
        </Card>
      </div>
    </>
  );
}
