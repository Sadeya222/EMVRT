import { createRootRouteWithContext, createRoute, createRouter, Outlet, redirect } from "@tanstack/react-router";
import type { QueryClient } from "@tanstack/react-query";
import { meQuery, queryClient } from "@/lib/api";
import { AppShell } from "@/components/AppShell";
import { LandingPage, DocsPage, LoginPage, AcceptInvitePage, NotFound } from "@/pages/public";
import { OverviewPage } from "@/pages/overview";
import { AppsPage, AppDetailPage } from "@/pages/apps";
import { SessionsPage } from "@/pages/sessions";
import { SessionViewerPage } from "@/pages/session-viewer";
import { HostsPage, HostDetailPage } from "@/pages/hosts";
import { MembersPage, ApiKeysPage, UsagePage, SettingsPage, AuditLogPage } from "@/pages/org";

const rootRoute = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  component: () => <Outlet />,
  notFoundComponent: NotFound,
});

const landing = createRoute({ getParentRoute: () => rootRoute, path: "/", component: LandingPage });
const docs = createRoute({ getParentRoute: () => rootRoute, path: "/documentation", component: DocsPage });
const login = createRoute({
  getParentRoute: () => rootRoute,
  path: "/login",
  validateSearch: (s: Record<string, unknown>): { redirect?: string } => ({ redirect: typeof s.redirect === "string" ? s.redirect : undefined }),
  component: LoginPage,
});
const acceptInvite = createRoute({
  getParentRoute: () => rootRoute,
  path: "/accept-invite",
  validateSearch: (s: Record<string, unknown>): { token?: string } => ({ token: typeof s.token === "string" ? s.token : undefined }),
  component: AcceptInvitePage,
});

const authed = createRoute({
  getParentRoute: () => rootRoute,
  id: "authed",
  beforeLoad: async ({ context, location }) => {
    try {
      await context.queryClient.ensureQueryData(meQuery);
    } catch {
      throw redirect({ to: "/login", search: { redirect: location.href } });
    }
  },
  component: AppShell,
});

const dashboardRoute = createRoute({ getParentRoute: () => authed, path: "/dashboard", component: OverviewPage });
const appsRoute = createRoute({ getParentRoute: () => authed, path: "/apps", component: AppsPage });
const appDetailRoute = createRoute({ getParentRoute: () => authed, path: "/apps/$appId", component: AppDetailPage });
const sessionsRoute = createRoute({ getParentRoute: () => authed, path: "/sessions", component: SessionsPage });
const sessionViewerRoute = createRoute({ getParentRoute: () => authed, path: "/sessions/$sessionId", component: SessionViewerPage });
const hostsRoute = createRoute({ getParentRoute: () => authed, path: "/hosts", component: HostsPage });
const hostDetailRoute = createRoute({ getParentRoute: () => authed, path: "/hosts/$hostId", component: HostDetailPage });
const membersRoute = createRoute({ getParentRoute: () => authed, path: "/members", component: MembersPage });
const apiKeysRoute = createRoute({ getParentRoute: () => authed, path: "/api-keys", component: ApiKeysPage });
const usageRoute = createRoute({ getParentRoute: () => authed, path: "/usage", component: UsagePage });
const settingsRoute = createRoute({ getParentRoute: () => authed, path: "/settings", component: SettingsPage });
const auditRoute = createRoute({ getParentRoute: () => authed, path: "/audit-log", component: AuditLogPage });

const routeTree = rootRoute.addChildren([
  landing,
  docs,
  login,
  acceptInvite,
  authed.addChildren([dashboardRoute, appsRoute, appDetailRoute, sessionsRoute, sessionViewerRoute, hostsRoute, hostDetailRoute, membersRoute, apiKeysRoute, usageRoute, settingsRoute, auditRoute]),
]);

export const router = createRouter({ routeTree, context: { queryClient }, defaultPreload: "intent" });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}
