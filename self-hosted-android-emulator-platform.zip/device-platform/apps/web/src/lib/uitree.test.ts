import { describe, expect, it } from "vitest";
import { boundsCenter, countNodes, nodeLabel, parseBounds, parseUiXml } from "./uitree";

const XML = `<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><hierarchy rotation="0"><node class="android.widget.FrameLayout" text="" bounds="[0,0][1080,2400]"><node class="android.widget.Button" text="Continue" resource-id="com.x:id/go" clickable="true" bounds="[40,460][1040,580]" /></node></hierarchy>`;

describe("uitree", () => {
  it("parses uiautomator XML", () => {
    const nodes = parseUiXml(XML);
    expect(countNodes(nodes)).toBe(2);
    const btn = nodes[0].children[0];
    expect(btn.clickable).toBe(true);
    expect(nodeLabel(btn)).toBe("Button · Continue");
    expect(boundsCenter(btn.bounds!)).toEqual({ x: 540, y: 520 });
  });
  it("rejects invalid documents", () => {
    expect(() => parseUiXml("<nope")).toThrow();
    expect(() => parseUiXml("<root/>")).toThrow(/hierarchy/);
  });
  it("parses bounds", () => {
    expect(parseBounds("[1,2][3,4]")).toEqual({ x1: 1, y1: 2, x2: 3, y2: 4 });
    expect(parseBounds("bogus")).toBeNull();
  });
});
