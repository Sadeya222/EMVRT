/** Parse Android `uiautomator dump` XML into a typed tree. */
export interface UiNode {
  id: string;
  className: string;
  text: string;
  resourceId: string;
  contentDesc: string;
  packageName: string;
  clickable: boolean;
  enabled: boolean;
  focusable: boolean;
  bounds: { x1: number; y1: number; x2: number; y2: number } | null;
  children: UiNode[];
}

export function parseBounds(b: string | null): UiNode["bounds"] {
  const m = b?.match(/^\[(\d+),(\d+)\]\[(\d+),(\d+)\]$/);
  if (!m) return null;
  const [x1, y1, x2, y2] = m.slice(1).map(Number);
  return { x1, y1, x2, y2 };
}

export function boundsCenter(b: NonNullable<UiNode["bounds"]>): { x: number; y: number } {
  return { x: Math.round((b.x1 + b.x2) / 2), y: Math.round((b.y1 + b.y2) / 2) };
}

export function parseUiXml(xml: string): UiNode[] {
  const doc = new DOMParser().parseFromString(xml, "application/xml");
  if (doc.getElementsByTagName("parsererror").length) throw new Error("Invalid UI hierarchy XML");
  const root = doc.getElementsByTagName("hierarchy")[0];
  if (!root) throw new Error("No <hierarchy> element");
  let counter = 0;
  const walk = (el: Element): UiNode => ({
    id: `n${counter++}`,
    className: el.getAttribute("class") ?? "",
    text: el.getAttribute("text") ?? "",
    resourceId: el.getAttribute("resource-id") ?? "",
    contentDesc: el.getAttribute("content-desc") ?? "",
    packageName: el.getAttribute("package") ?? "",
    clickable: el.getAttribute("clickable") === "true",
    enabled: el.getAttribute("enabled") !== "false",
    focusable: el.getAttribute("focusable") === "true",
    bounds: parseBounds(el.getAttribute("bounds")),
    children: Array.from(el.children).filter((c) => c.tagName === "node").map(walk),
  });
  return Array.from(root.children).filter((c) => c.tagName === "node").map(walk);
}

export function countNodes(nodes: UiNode[]): number {
  return nodes.reduce((n, c) => n + 1 + countNodes(c.children), 0);
}

export function nodeLabel(n: UiNode): string {
  const short = n.className.split(".").pop() || "node";
  const detail = n.text || n.contentDesc || n.resourceId.split("/").pop() || "";
  return detail ? `${short} · ${detail}` : short;
}
