import { createClient, ApiError } from "@dp/api-client";
import { QueryClient, queryOptions } from "@tanstack/react-query";

export const api = createClient({ baseUrl: "" });

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5_000,
      retry: (count, err) => !(err instanceof ApiError && [401, 403, 404].includes(err.status)) && count < 2,
    },
  },
});

export const meQuery = queryOptions({ queryKey: ["me"], queryFn: () => api.auth.me(), staleTime: 60_000, retry: false });

export const qk = {
  apps: ["apps"] as const,
  app: (id: string) => ["apps", id] as const,
  profiles: ["device-profiles"] as const,
  hosts: ["hosts"] as const,
  host: (id: string) => ["hosts", id] as const,
  sessions: (active?: boolean) => ["sessions", { active }] as const,
  session: (id: string) => ["session", id] as const,
  events: (id: string) => ["session", id, "events"] as const,
  usage: ["usage"] as const,
  members: ["members"] as const,
  apiKeys: ["api-keys"] as const,
  audit: (action?: string) => ["audit", action] as const,
  org: (id: string) => ["org", id] as const,
};

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return "Something went wrong";
}

export { ApiError };
