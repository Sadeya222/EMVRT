import type { SessionEvent, Session } from "@dp/api-client";

const HISTORY_KINDS = new Set(["created", "state", "action", "screenshot", "ui_tree", "warning"]);

export function buildHistoryExport(session: Pick<Session, "id" | "profile_name" | "app_name" | "version_name">, events: SessionEvent[]) {
  return {
    format: "device-platform.session-history.v1",
    exported_at: new Date().toISOString(),
    session: { id: session.id, device: session.profile_name, app: session.app_name ?? null, version: session.version_name ?? null },
    events: events
      .filter((e) => HISTORY_KINDS.has(e.kind))
      .map((e) => ({ at: e.created_at, kind: e.kind, from_state: e.from_state ?? null, to_state: e.to_state ?? null, actor: e.actor_email ?? null, payload: e.payload })),
  };
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function describeEvent(e: SessionEvent): string {
  const p = (e.payload ?? {}) as Record<string, unknown>;
  switch (e.kind) {
    case "created":
      return "Session requested";
    case "state":
      return `${e.from_state ?? "?"} → ${e.to_state ?? "?"}${p.reason ? ` (${String(p.reason)})` : ""}`;
    case "action": {
      const a = (p.action ?? {}) as Record<string, unknown>;
      const t = String(a.type ?? "action");
      const detail =
        t === "tap" ? `(${a.x}, ${a.y})` :
        t === "swipe" ? `(${a.x1}, ${a.y1}) → (${a.x2}, ${a.y2})` :
        t === "text" ? `${String(a.text ?? "").length} chars` :
        t === "key" ? String(a.key) :
        t === "rotate" ? String(a.orientation) :
        t === "deep_link" ? String(a.uri) : "";
      return `${t.replace("_", " ")} ${detail}${p.ok === false ? " — failed" : ""}`;
    }
    case "screenshot":
      return "Screenshot captured";
    case "ui_tree":
      return "Accessibility tree fetched";
    case "warning":
      return String(p.message ?? "Warning");
    default:
      return e.kind;
  }
}
