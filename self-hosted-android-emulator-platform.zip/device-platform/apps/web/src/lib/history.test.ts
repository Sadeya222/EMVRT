import { describe, expect, it } from "vitest";
import type { SessionEvent } from "@dp/api-client";
import { buildHistoryExport, describeEvent } from "./history";

const ev = (kind: string, payload: Record<string, unknown> = {}, extra: Partial<SessionEvent> = {}): SessionEvent => ({
  id: crypto.randomUUID(), kind, payload: payload as never, created_at: "2025-01-01T00:00:00Z", from_state: null, to_state: null, actor_email: null, ...extra,
});

describe("history", () => {
  it("describes actions", () => {
    expect(describeEvent(ev("action", { action: { type: "tap", x: 1, y: 2 }, ok: true }))).toBe("tap (1, 2)");
    expect(describeEvent(ev("action", { action: { type: "deep_link", uri: "a://b" }, ok: false }))).toBe("deep link a://b — failed");
    expect(describeEvent(ev("state", { reason: "user" }, { from_state: "ACTIVE", to_state: "ENDING" }))).toBe("ACTIVE → ENDING (user)");
  });
  it("exports a versioned JSON document", () => {
    const out = buildHistoryExport({ id: "s1", profile_name: "Pixel", app_name: null, version_name: null }, [ev("action", { action: { type: "tap" } }), ev("internal")]);
    expect(out.format).toBe("device-platform.session-history.v1");
    expect(out.events).toHaveLength(1);
    expect(out.session.device).toBe("Pixel");
  });
});
