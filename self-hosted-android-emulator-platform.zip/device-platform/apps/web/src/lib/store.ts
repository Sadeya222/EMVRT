import { create } from "zustand";

/** Local, ephemeral UI state only. Server state lives in TanStack Query. */
interface UiState {
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
  sessionPanel: "logcat" | "tree" | "screenshots" | "history";
  setSessionPanel: (p: UiState["sessionPanel"]) => void;
  logFilter: string;
  setLogFilter: (v: string) => void;
  logLevel: "V" | "D" | "I" | "W" | "E";
  setLogLevel: (v: UiState["logLevel"]) => void;
}

export const useUi = create<UiState>((set) => ({
  sidebarOpen: false,
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  sessionPanel: "logcat",
  setSessionPanel: (sessionPanel) => set({ sessionPanel }),
  logFilter: "",
  setLogFilter: (logFilter) => set({ logFilter }),
  logLevel: "V",
  setLogLevel: (logLevel) => set({ logLevel }),
}));
