import { Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { Activity, AppWindow, BookOpen, ChevronsUpDown, FileClock, Gauge, KeyRound, LayoutDashboard, LogOut, Menu, Server, Settings, Smartphone, Users, X } from "lucide-react";
import { api, meQuery } from "@/lib/api";
import { useUi } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "./ui";

const NAV = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { to: "/apps", label: "Applications", icon: AppWindow },
  { to: "/sessions", label: "Sessions", icon: Smartphone },
  { to: "/hosts", label: "Hosts", icon: Server },
  { to: "/usage", label: "Usage", icon: Gauge },
] as const;
const ADMIN_NAV = [
  { to: "/members", label: "Members", icon: Users },
  { to: "/api-keys", label: "API keys", icon: KeyRound },
  { to: "/audit-log", label: "Audit log", icon: FileClock },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function Logo() {
  return (
    <span className="flex items-center gap-2 font-semibold text-white">
      <span className="grid h-7 w-7 place-items-center rounded-md bg-emerald-500 text-slate-950"><Activity className="h-4 w-4" aria-hidden /></span>
      Device Platform
    </span>
  );
}

function OrgSwitcher() {
  const { data: me } = useQuery(meQuery);
  const qc = useQueryClient();
  const activate = useMutation({
    mutationFn: (id: string) => api.orgs.activate(id),
    onSuccess: (m) => {
      qc.clear();
      qc.setQueryData(meQuery.queryKey, m);
    },
  });
  const active = me?.organizations.find((o) => o.id === me.active_org_id);
  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger asChild>
        <button className="flex w-full items-center justify-between rounded-md border border-slate-800 bg-slate-900 px-3 py-2 text-left text-sm hover:border-slate-700" aria-label="Switch organization">
          <span className="min-w-0">
            <span className="block truncate font-medium text-white">{active?.name ?? "No organization"}</span>
            <span className="block text-xs text-slate-500">{me?.role ?? "—"}</span>
          </span>
          <ChevronsUpDown className="h-4 w-4 text-slate-500" aria-hidden />
        </button>
      </DropdownMenu.Trigger>
      <DropdownMenu.Portal>
        <DropdownMenu.Content align="start" sideOffset={6} className="z-50 min-w-56 rounded-lg border border-slate-700 bg-slate-900 p-1 shadow-xl">
          {me?.organizations.map((o) => (
            <DropdownMenu.Item key={o.id} onSelect={() => activate.mutate(o.id)} className="cursor-pointer rounded px-3 py-2 text-sm text-slate-200 outline-none data-[highlighted]:bg-slate-800">
              {o.name} <span className="text-xs text-slate-500">· {o.role}</span>
            </DropdownMenu.Item>
          ))}
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  );
}

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const { data: me } = useQuery(meQuery);
  const isAdmin = me?.role === "admin" || me?.role === "owner";
  const item = "flex items-center gap-3 rounded-md px-3 py-2 text-sm text-slate-400 hover:bg-slate-800/60 hover:text-white";
  return (
    <nav aria-label="Main" className="space-y-6">
      <ul className="space-y-0.5">
        {NAV.map((n) => (
          <li key={n.to}>
            <Link to={n.to} onClick={onNavigate} className={item} activeProps={{ className: "bg-slate-800 text-white" }}>
              <n.icon className="h-4 w-4" aria-hidden /> {n.label}
            </Link>
          </li>
        ))}
      </ul>
      <div>
        <p className="px-3 pb-1 text-xs font-medium uppercase tracking-wide text-slate-600">Organization</p>
        <ul className="space-y-0.5">
          {ADMIN_NAV.filter((n) => isAdmin || n.to === "/members").map((n) => (
            <li key={n.to}>
              <Link to={n.to} onClick={onNavigate} className={item} activeProps={{ className: "bg-slate-800 text-white" }}>
                <n.icon className="h-4 w-4" aria-hidden /> {n.label}
              </Link>
            </li>
          ))}
          <li>
            <Link to="/documentation" onClick={onNavigate} className={item}><BookOpen className="h-4 w-4" aria-hidden /> Documentation</Link>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export function AppShell() {
  const { data: me } = useQuery(meQuery);
  const { sidebarOpen, setSidebarOpen } = useUi();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const logout = useMutation({
    mutationFn: () => api.auth.logout(),
    onSettled: () => {
      qc.clear();
      navigate({ to: "/login", search: { redirect: undefined } });
    },
  });
  const sidebar = (
    <div className="flex h-full flex-col gap-6 p-4">
      <Link to="/dashboard" className="px-1"><Logo /></Link>
      <OrgSwitcher />
      <div className="flex-1 overflow-y-auto"><NavLinks onNavigate={() => setSidebarOpen(false)} /></div>
      <div className="border-t border-slate-800 pt-4">
        <p className="truncate px-1 text-sm text-slate-300">{me?.display_name || me?.email}</p>
        <p className="truncate px-1 text-xs text-slate-500">{me?.email}</p>
        <Button variant="ghost" size="sm" className="mt-2 w-full justify-start" onClick={() => logout.mutate()} loading={logout.isPending}>
          <LogOut className="h-4 w-4" aria-hidden /> Sign out
        </Button>
      </div>
    </div>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[256px_1fr]">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-emerald-500 focus:px-3 focus:py-2 focus:text-slate-950">Skip to content</a>
      <aside className="hidden border-r border-slate-800 bg-slate-950 lg:block lg:sticky lg:top-0 lg:h-screen">{sidebar}</aside>
      <div className={cn("fixed inset-0 z-40 lg:hidden", sidebarOpen ? "" : "pointer-events-none")} aria-hidden={!sidebarOpen}>
        <div className={cn("absolute inset-0 bg-black/60 transition-opacity", sidebarOpen ? "opacity-100" : "opacity-0")} onClick={() => setSidebarOpen(false)} />
        <aside className={cn("absolute inset-y-0 left-0 w-72 border-r border-slate-800 bg-slate-950 transition-transform", sidebarOpen ? "translate-x-0" : "-translate-x-full")}>
          <Button variant="ghost" size="icon" className="absolute right-2 top-3" aria-label="Close navigation" onClick={() => setSidebarOpen(false)}><X className="h-4 w-4" /></Button>
          {sidebar}
        </aside>
      </div>
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-slate-800 bg-slate-950/90 px-4 py-3 backdrop-blur lg:hidden">
          <Button variant="ghost" size="icon" aria-label="Open navigation" onClick={() => setSidebarOpen(true)}><Menu className="h-5 w-5" /></Button>
          <Logo />
        </header>
        <main id="main" className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          {me && !me.active_org_id ? (
            <div className="rounded-lg border border-amber-900 bg-amber-950/40 p-4 text-sm text-amber-100">You are not a member of any organization yet. Ask an admin for an invite.</div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </div>
  );
}
