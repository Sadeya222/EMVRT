import type { SessionState } from "@dp/api-client";
import { Badge, type BadgeColor } from "./ui";

const COLORS: Record<SessionState, BadgeColor> = {
  REQUESTED: "gray",
  QUEUED: "gray",
  ASSIGNED: "blue",
  BOOTING: "blue",
  INSTALLING: "blue",
  READY: "green",
  ACTIVE: "green",
  ENDING: "yellow",
  WIPED: "purple",
  FAILED: "red",
  CANCELLED: "gray",
};

export const TERMINAL: SessionState[] = ["WIPED", "FAILED", "CANCELLED"];
export const PROVISIONING: SessionState[] = ["REQUESTED", "QUEUED", "ASSIGNED", "BOOTING", "INSTALLING"];
export const isTerminal = (s: SessionState) => TERMINAL.includes(s);
export const isInteractive = (s: SessionState) => s === "READY" || s === "ACTIVE";

export function StateBadge({ state }: { state: SessionState }) {
  const live = PROVISIONING.includes(state) || isInteractive(state);
  return (
    <Badge color={COLORS[state]} aria-label={`Session state: ${state}`}>
      {live && <span className={`h-1.5 w-1.5 rounded-full ${isInteractive(state) ? "bg-emerald-400" : "animate-pulse bg-sky-400"}`} aria-hidden />}
      {state}
    </Badge>
  );
}

export function HostStatusBadge({ status, connected }: { status: string; connected?: boolean | null }) {
  const color: BadgeColor = status === "online" && connected !== false ? "green" : status === "draining" ? "yellow" : status === "disabled" ? "red" : "gray";
  return <Badge color={color}>{status}{connected === false && status === "online" ? " (reconnecting)" : ""}</Badge>;
}

export function VersionStatusBadge({ status }: { status: string }) {
  const map: Record<string, BadgeColor> = { approved: "green", rejected: "red", quarantined: "yellow", validating: "blue", pending_upload: "gray", deleted: "gray" };
  return <Badge color={map[status] ?? "gray"}>{status.replace("_", " ")}</Badge>;
}
