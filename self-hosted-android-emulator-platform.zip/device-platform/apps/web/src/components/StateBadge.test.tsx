import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { isInteractive, isTerminal, StateBadge, VersionStatusBadge } from "./StateBadge";

describe("StateBadge", () => {
  it("renders an accessible label for each state", () => {
    render(<StateBadge state="READY" />);
    expect(screen.getByLabelText("Session state: READY")).toHaveTextContent("READY");
  });
  it("classifies states", () => {
    expect(isTerminal("WIPED")).toBe(true);
    expect(isTerminal("ACTIVE")).toBe(false);
    expect(isInteractive("READY")).toBe(true);
    expect(isInteractive("BOOTING")).toBe(false);
  });
  it("renders version status text", () => {
    render(<VersionStatusBadge status="pending_upload" />);
    expect(screen.getByText("pending upload")).toBeInTheDocument();
  });
});
