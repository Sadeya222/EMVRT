import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Download, Hand, Image as ImageIcon, ListTree, Pause, Play, Trash2 } from "lucide-react";
import type { InputAction, LogLine, Session, SessionEvent } from "@dp/api-client";
import { api, errorMessage } from "@/lib/api";
import { useUi } from "@/lib/store";
import { buildHistoryExport, describeEvent, downloadJson } from "@/lib/history";
import { boundsCenter, countNodes, nodeLabel, parseUiXml, type UiNode } from "@/lib/uitree";
import { cn, formatDate } from "@/lib/utils";
import { Alert, Button, EmptyState, Input, Select, Spinner } from "@/components/ui";

const LEVELS = ["V", "D", "I", "W", "E"] as const;
const levelColor: Record<string, string> = { V: "text-slate-500", D: "text-sky-300", I: "text-emerald-300", W: "text-amber-300", E: "text-red-400", F: "text-red-500" };

export function LogcatPanel({ sessionId, live }: { sessionId: string; live: boolean }) {
  const [lines, setLines] = useState<LogLine[]>([]);
  const [paused, setPaused] = useState(false);
  const cursor = useRef(0);
  const box = useRef<HTMLDivElement>(null);
  const { logFilter, setLogFilter, logLevel, setLogLevel } = useUi();

  useEffect(() => {
    cursor.current = 0;
    setLines([]);
  }, [sessionId]);
  useEffect(() => {
    if (paused) return;
    let stop = false;
    const tick = async () => {
      try {
        const next = await api.sessions.logs(sessionId, cursor.current || undefined);
        if (!stop && next.length) {
          cursor.current = next[next.length - 1].id;
          setLines((prev) => [...prev, ...next].slice(-3000));
        }
      } catch {
        /* transient; retry on next tick */
      }
    };
    void tick();
    const t = live ? setInterval(tick, 1500) : undefined;
    return () => { stop = true; if (t) clearInterval(t); };
  }, [sessionId, paused, live]);
  useEffect(() => {
    if (!paused && box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [lines, paused]);

  const min = LEVELS.indexOf(logLevel);
  const filtered = useMemo(() => {
    const f = logFilter.toLowerCase();
    return lines.filter((l) => (LEVELS.indexOf(l.level as (typeof LEVELS)[number]) >= min || l.level === "F") && (!f || l.tag.toLowerCase().includes(f) || l.message.toLowerCase().includes(f)));
  }, [lines, logFilter, min]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-2 p-3">
        <Input aria-label="Filter logcat" placeholder="Filter tag or message" value={logFilter} onChange={(e) => setLogFilter(e.target.value)} className="h-8 flex-1 min-w-32" />
        <Select aria-label="Minimum level" value={logLevel} onChange={(e) => setLogLevel(e.target.value as typeof logLevel)} className="h-8 w-20">
          {LEVELS.map((l) => <option key={l} value={l}>{l}+</option>)}
        </Select>
        <Button size="icon" variant="secondary" aria-label={paused ? "Resume logcat" : "Pause logcat"} onClick={() => setPaused(!paused)}>{paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}</Button>
        <Button size="icon" variant="secondary" aria-label="Clear logcat view" onClick={() => setLines([])}><Trash2 className="h-4 w-4" /></Button>
      </div>
      <div ref={box} role="log" aria-live="off" aria-label="Logcat output" className="min-h-64 flex-1 overflow-auto bg-slate-950 px-3 py-2 font-mono text-[11px] leading-5">
        {filtered.length === 0 ? <p className="text-slate-600">{live ? "Waiting for log lines…" : "No log lines."}</p> : filtered.map((l) => (
          <div key={l.id} className="whitespace-pre-wrap break-all">
            <span className="text-slate-600">{l.ts} </span>
            <span className={cn("font-bold", levelColor[l.level] ?? "text-slate-300")}>{l.level} </span>
            <span className="text-violet-300">{l.tag}: </span>
            <span className="text-slate-200">{l.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TreeNode({ node, selected, onSelect }: { node: UiNode; selected: string | null; onSelect: (n: UiNode) => void }) {
  const label = (
    <button type="button" onClick={(e) => { e.preventDefault(); onSelect(node); }} className={cn("rounded px-1 text-left hover:bg-slate-800", selected === node.id && "bg-emerald-500/20 text-emerald-200")}>
      {nodeLabel(node)}{node.clickable && <Hand className="ml-1 inline h-3 w-3 text-amber-300" aria-label="clickable" />}
    </button>
  );
  if (node.children.length === 0) return <li className="py-0.5 pl-4">{label}</li>;
  return (
    <li className="py-0.5">
      <details open>
        <summary className="cursor-pointer select-none marker:text-slate-500">{label}</summary>
        <ul className="ml-3 border-l border-slate-800 pl-1">{node.children.map((c) => <TreeNode key={c.id} node={c} selected={selected} onSelect={onSelect} />)}</ul>
      </details>
    </li>
  );
}

export function UiTreePanel({ session, onAction, live }: { session: Session; onAction: (a: InputAction) => void; live: boolean }) {
  const [selected, setSelected] = useState<UiNode | null>(null);
  const fetchTree = useMutation({ mutationFn: async () => parseUiXml((await api.sessions.uiTree(session.id)).xml) });
  const nodes = fetchTree.data;
  return (
    <div className="space-y-3 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs text-slate-400">{nodes ? `${countNodes(nodes)} nodes` : "Android accessibility hierarchy (uiautomator)"}</p>
        <Button size="sm" variant="secondary" onClick={() => fetchTree.mutate()} loading={fetchTree.isPending} disabled={!live}><ListTree className="h-4 w-4" aria-hidden /> {nodes ? "Refresh" : "Fetch tree"}</Button>
      </div>
      {fetchTree.isError && <Alert tone="error">{errorMessage(fetchTree.error)}</Alert>}
      {!nodes && !fetchTree.isPending && <EmptyState icon={<ListTree className="h-7 w-7" />} title="No hierarchy loaded" description={live ? "Fetch the current accessibility tree from the device." : "The session is not interactive."} />}
      {nodes && (
        <div className="grid gap-3">
          <ul aria-label="Accessibility tree" className="max-h-80 overflow-auto rounded border border-slate-800 bg-slate-950 p-2 font-mono text-xs text-slate-300">
            {nodes.map((n) => <TreeNode key={n.id} node={n} selected={selected?.id ?? null} onSelect={setSelected} />)}
          </ul>
          {selected && (
            <div className="rounded border border-slate-800 p-3 text-xs">
              <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                {([["class", selected.className], ["text", selected.text], ["resource-id", selected.resourceId], ["content-desc", selected.contentDesc], ["package", selected.packageName],
                  ["bounds", selected.bounds ? `[${selected.bounds.x1},${selected.bounds.y1}][${selected.bounds.x2},${selected.bounds.y2}]` : "—"],
                  ["clickable", String(selected.clickable)], ["enabled", String(selected.enabled)]] as const).map(([k, v]) => (
                  <div key={k} className="contents"><dt className="text-slate-500">{k}</dt><dd className="break-all text-slate-200">{v || "—"}</dd></div>
                ))}
              </dl>
              {selected.bounds && live && (
                <Button size="sm" className="mt-3" onClick={() => onAction({ type: "tap", ...boundsCenter(selected.bounds!) })}>Tap element center</Button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function ScreenshotPanel({ sessionId, live, onCaptured }: { sessionId: string; live: boolean; onCaptured?: () => void }) {
  const [shots, setShots] = useState<{ url: string; at: string }[]>([]);
  const capture = useMutation({
    mutationFn: () => api.sessions.screenshot(sessionId),
    onSuccess: (r) => { setShots((s) => [{ url: r.url, at: r.captured_at }, ...s].slice(0, 12)); onCaptured?.(); },
  });
  return (
    <div className="space-y-3 p-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-400">Links expire after 5 minutes.</p>
        <Button size="sm" onClick={() => capture.mutate()} loading={capture.isPending} disabled={!live}><ImageIcon className="h-4 w-4" aria-hidden /> Capture</Button>
      </div>
      {capture.isError && <Alert tone="error">{errorMessage(capture.error)}</Alert>}
      {shots.length === 0 ? <EmptyState icon={<ImageIcon className="h-7 w-7" />} title="No screenshots yet" /> : (
        <ul className="grid grid-cols-2 gap-3">
          {shots.map((s) => (
            <li key={s.url} className="overflow-hidden rounded border border-slate-800">
              <a href={s.url} target="_blank" rel="noreferrer noopener"><img src={s.url} alt={`Screenshot captured ${formatDate(s.at)}`} className="w-full" /></a>
              <p className="px-2 py-1 text-[11px] text-slate-500">{formatDate(s.at)}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function ActionHistoryPanel({ session, live }: { session: Session; live: boolean }) {
  const events = useQuery({ queryKey: ["session", session.id, "events"], queryFn: () => api.sessions.events(session.id), refetchInterval: live ? 3000 : false });
  const list: SessionEvent[] = events.data ?? [];
  return (
    <div className="space-y-3 p-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-400">{list.length} events</p>
        <Button size="sm" variant="secondary" disabled={!list.length} onClick={() => downloadJson(`session-${session.id}-history.json`, buildHistoryExport(session, list))}>
          <Download className="h-4 w-4" aria-hidden /> Export JSON
        </Button>
      </div>
      {events.isLoading ? <Spinner /> : (
        <ol aria-label="Session action history" className="relative space-y-3 border-l border-slate-800 pl-4">
          {list.map((e) => (
            <li key={e.id} className="text-sm">
              <span className={cn("absolute -left-[5px] mt-1.5 h-2.5 w-2.5 rounded-full", e.kind === "action" ? "bg-amber-400" : e.kind === "state" ? "bg-emerald-400" : "bg-slate-500")} aria-hidden />
              <p className="text-slate-200">{describeEvent(e)}</p>
              <p className="text-xs text-slate-500">{formatDate(e.created_at)}{e.actor_email ? ` · ${e.actor_email}` : ""}</p>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
