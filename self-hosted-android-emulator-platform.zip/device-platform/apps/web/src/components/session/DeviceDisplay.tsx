import { useCallback, useEffect, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { MonitorOff, RefreshCw } from "lucide-react";
import type { InputAction, Session } from "@dp/api-client";
import { api, ApiError } from "@/lib/api";
import { Alert, Button, Spinner } from "@/components/ui";
import { isInteractive } from "@/components/StateBadge";

/**
 * Renders the device. Providers:
 * - gateway / local-dev: iframe to the host node ingress with a short-lived token
 * - fake: simulated display built from real screenshots of the FakeEmulatorAdapter; clicks/drags map to taps/swipes
 * - unavailable: explains exactly what must be configured
 */
export function DeviceDisplay({ session, onAction, refreshKey }: { session: Session; onAction: (a: InputAction) => void; refreshKey: number }) {
  const interactive = isInteractive(session.state);
  const stream = useQuery({
    queryKey: ["stream", session.id],
    queryFn: () => api.sessions.streamToken(session.id),
    enabled: interactive,
    retry: false,
    // Refresh well before the 5-minute token expires.
    refetchInterval: 4 * 60_000,
  });
  if (!interactive) {
    return (
      <div className="grid aspect-[9/16] max-h-[70vh] w-full place-items-center rounded-2xl border border-slate-800 bg-slate-950 text-center text-sm text-slate-500">
        {["WIPED", "FAILED", "CANCELLED"].includes(session.state) ? (
          <div className="px-6"><MonitorOff className="mx-auto mb-2 h-8 w-8" aria-hidden />Session ended — device wiped.</div>
        ) : (
          <Spinner label={`Device ${session.state.toLowerCase()}`} />
        )}
      </div>
    );
  }
  if (stream.isLoading) return <Spinner label="Requesting stream access" />;
  if (stream.isError) {
    const e = stream.error;
    return (
      <Alert tone="warn" title={e instanceof ApiError && e.code === "stream_unavailable" ? "Streaming unavailable" : "Could not open stream"}>
        <p>{e.message}</p>
        {e instanceof ApiError && e.instructions && (
          <ol className="mt-2 list-decimal space-y-1 pl-5 text-xs">{e.instructions.map((i) => <li key={i}>{i}</li>)}</ol>
        )}
        <p className="mt-2 text-xs opacity-80">Screenshots, logcat, the accessibility tree and input controls still work.</p>
      </Alert>
    );
  }
  if (stream.data?.provider === "fake") return <FakeDisplay session={session} onAction={onAction} refreshKey={refreshKey} />;
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-700 bg-black">
      <iframe
        title={`Emulator stream for session ${session.id}`}
        src={stream.data?.url ?? undefined}
        className="aspect-[9/16] max-h-[75vh] w-full"
        sandbox="allow-scripts allow-same-origin"
        allow="autoplay; clipboard-write"
        referrerPolicy="no-referrer"
      />
    </div>
  );
}

function FakeDisplay({ session, onAction, refreshKey }: { session: Session; onAction: (a: InputAction) => void; refreshKey: number }) {
  const [url, setUrl] = useState<string | null>(null);
  const [dims, setDims] = useState({ w: session.screen_width, h: session.screen_height });
  const drag = useRef<{ x: number; y: number; t: number } | null>(null);
  const shot = useMutation({ mutationFn: () => api.sessions.screenshot(session.id), onSuccess: (r) => setUrl(r.url) });
  const { mutate } = shot;
  useEffect(() => {
    const t = setTimeout(() => mutate(), 250);
    return () => clearTimeout(t);
  }, [mutate, refreshKey]);

  const toDevice = useCallback((e: React.PointerEvent<HTMLImageElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    return { x: Math.round(((e.clientX - r.left) / r.width) * dims.w), y: Math.round(((e.clientY - r.top) / r.height) * dims.h) };
  }, [dims]);

  return (
    <div>
      <div className="relative mx-auto max-w-sm overflow-hidden rounded-[2rem] border-8 border-slate-800 bg-black shadow-2xl">
        {url ? (
          <img
            src={url}
            alt="Simulated device screen (FakeEmulatorAdapter). Click to tap, drag to swipe."
            className="w-full cursor-crosshair select-none"
            draggable={false}
            onLoad={(e) => {
              const img = e.currentTarget;
              const landscape = img.naturalWidth > img.naturalHeight;
              const [a, b] = [session.screen_width, session.screen_height];
              setDims(landscape ? { w: Math.max(a, b), h: Math.min(a, b) } : { w: Math.min(a, b), h: Math.max(a, b) });
            }}
            onPointerDown={(e) => { drag.current = { ...toDevice(e), t: Date.now() }; }}
            onPointerUp={(e) => {
              const start = drag.current;
              drag.current = null;
              if (!start) return;
              const end = toDevice(e);
              const dist = Math.hypot(end.x - start.x, end.y - start.y);
              if (dist < 20) onAction({ type: "tap", x: end.x, y: end.y });
              else onAction({ type: "swipe", x1: start.x, y1: start.y, x2: end.x, y2: end.y, duration_ms: Math.min(Math.max(Date.now() - start.t, 50), 2000) });
            }}
          />
        ) : (
          <div className="grid aspect-[9/16] place-items-center"><Spinner label="Capturing screen" /></div>
        )}
      </div>
      <div className="mt-2 flex items-center justify-center gap-2 text-xs text-amber-300/80">
        <span>Simulated display · FakeEmulatorAdapter</span>
        <Button size="sm" variant="ghost" onClick={() => shot.mutate()} loading={shot.isPending} aria-label="Refresh screen"><RefreshCw className="h-3.5 w-3.5" /></Button>
      </div>
    </div>
  );
}
