/**
 * Embed a Device Platform session stream in a customer page.
 *
 * The host page must obtain short-lived stream URLs from ITS OWN backend (which calls
 * `POST /v1/sessions/{id}/stream-token` with a scoped API key). Long-lived credentials must never
 * be placed in iframe URLs or shipped to browsers.
 */
export interface StreamGrant {
  provider: string;
  url?: string | null;
  expires_at: string;
}

export interface EmbedOptions {
  /** Called whenever a fresh short-lived grant is needed. */
  getStreamGrant: () => Promise<StreamGrant>;
  /** Refresh this many ms before expiry (default 60s). */
  refreshSkewMs?: number;
  title?: string;
  onError?: (err: unknown) => void;
}

export interface EmbedHandle {
  destroy(): void;
}

export function mountSession(container: HTMLElement, opts: EmbedOptions): EmbedHandle {
  const iframe = document.createElement("iframe");
  iframe.title = opts.title ?? "Android emulator session";
  iframe.setAttribute("sandbox", "allow-scripts allow-same-origin");
  iframe.setAttribute("allow", "autoplay; clipboard-write");
  iframe.setAttribute("referrerpolicy", "no-referrer");
  iframe.style.border = "0";
  iframe.style.width = "100%";
  iframe.style.height = "100%";
  container.appendChild(iframe);
  let timer: ReturnType<typeof setTimeout> | undefined;
  let destroyed = false;

  const refresh = async () => {
    try {
      const grant = await opts.getStreamGrant();
      if (destroyed) return;
      if (!grant.url) throw new Error(`Stream provider '${grant.provider}' does not expose an embeddable URL`);
      // Only reload when the URL changes so in-flight WebRTC sessions are not interrupted needlessly.
      if (iframe.src !== grant.url && !iframe.src) iframe.src = grant.url;
      const ms = new Date(grant.expires_at).getTime() - Date.now() - (opts.refreshSkewMs ?? 60_000);
      timer = setTimeout(refresh, Math.max(ms, 10_000));
    } catch (err) {
      opts.onError?.(err);
      timer = setTimeout(refresh, 15_000);
    }
  };
  void refresh();
  return {
    destroy() {
      destroyed = true;
      if (timer) clearTimeout(timer);
      iframe.remove();
    },
  };
}
