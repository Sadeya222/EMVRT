/**
 * Typed client for the Device Platform REST API.
 *
 * Types are GENERATED from the Rust OpenAPI document (`src/schema.ts`, via
 * `scripts/generate-api-client.sh`). Authentication uses the HttpOnly session cookie set by the
 * API; this client never stores tokens. Cookie-authenticated mutations send the double-submit
 * CSRF token read from the non-HttpOnly `dp_csrf` cookie.
 */
import type { components } from "./schema";

export type Schemas = components["schemas"];
export type Me = Schemas["MeResponse"];
export type Organization = Schemas["Organization"];
export type AppSummary = Schemas["AppSummary"];
export type AppDetail = Schemas["AppDetail"];
export type AppVersion = Schemas["AppVersion"];
export type CreateUploadResponse = Schemas["CreateUploadResponse"];
export type DeviceProfile = Schemas["DeviceProfile"];
export type Host = Schemas["Host"];
export type HostDetail = Schemas["HostDetail"];
export type EnrollmentTokenResponse = Schemas["EnrollmentTokenResponse"];
export type Session = Schemas["Session"];
export type SessionState = Schemas["SessionState"];
export type SessionEvent = Schemas["SessionEvent"];
export type LogLine = Schemas["LogLineDto"];
export type InputAction = Schemas["InputAction"];
export type ActionResult = Schemas["ActionResult"];
export type ScreenshotResponse = Schemas["ScreenshotResponse"];
export type StreamAccess = Schemas["StreamAccess"];
export type ApiKey = Schemas["ApiKey"];
export type CreateApiKeyResponse = Schemas["CreateApiKeyResponse"];
export type Usage = Schemas["Usage"];
export type AuditLog = Schemas["AuditLog"];
export type MembersResponse = Schemas["MembersResponse"];
export type Role = Schemas["Role"];
export type InviteInfo = Schemas["InviteInfo"];
export type CreateInviteResponse = Schemas["CreateInviteResponse"];

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public instructions?: string[],
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export interface ClientOptions {
  baseUrl?: string;
  /** For server-to-server use with a scoped API key. Never use in browsers. */
  apiKey?: string;
  fetch?: typeof fetch;
}

function readCookie(name: string): string | undefined {
  if (typeof document === "undefined") return undefined;
  return document.cookie
    .split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${name}=`))
    ?.slice(name.length + 1);
}

export function createClient(opts: ClientOptions = {}) {
  const base = (opts.baseUrl ?? "").replace(/\/$/, "");
  const f = opts.fetch ?? ((...a: Parameters<typeof fetch>) => fetch(...a));

  async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
    const headers: Record<string, string> = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (opts.apiKey) headers.Authorization = `Bearer ${opts.apiKey}`;
    else if (method !== "GET") {
      const csrf = readCookie("dp_csrf");
      if (csrf) headers["X-CSRF-Token"] = csrf;
    }
    const res = await f(`${base}${path}`, {
      method,
      headers,
      credentials: "include",
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (res.status === 204) return undefined as T;
    const text = await res.text();
    const data = text ? JSON.parse(text) : undefined;
    if (!res.ok) {
      const err = data?.error ?? {};
      throw new ApiError(res.status, err.code ?? "http_error", err.message ?? res.statusText, err.instructions);
    }
    return data as T;
  }

  const get = <T>(p: string) => request<T>("GET", p);
  const post = <T>(p: string, b?: unknown) => request<T>("POST", p, b ?? {});
  const qs = (o: Record<string, string | number | boolean | undefined>) => {
    const s = new URLSearchParams();
    for (const [k, v] of Object.entries(o)) if (v !== undefined) s.set(k, String(v));
    const r = s.toString();
    return r ? `?${r}` : "";
  };

  return {
    request,
    auth: {
      login: (b: Schemas["LoginRequest"]) => post<Me>("/v1/auth/login", b),
      logout: () => post<void>("/v1/auth/logout"),
      me: () => get<Me>("/v1/auth/me"),
      invite: (b: Schemas["CreateInviteRequest"]) => post<CreateInviteResponse>("/v1/auth/invites", b),
      inviteInfo: (token: string) => get<InviteInfo>(`/v1/auth/invite-info${qs({ token })}`),
      acceptInvite: (b: Schemas["AcceptInviteRequest"]) => post<Me>("/v1/auth/accept-invite", b),
    },
    orgs: {
      list: () => get<Organization[]>("/v1/organizations"),
      create: (b: Schemas["CreateOrgRequest"]) => post<Organization>("/v1/organizations", b),
      get: (id: string) => get<Organization>(`/v1/organizations/${id}`),
      activate: (id: string) => post<Me>(`/v1/organizations/${id}/activate`),
      members: () => get<MembersResponse>("/v1/organizations/current/members"),
      updateSettings: (b: Schemas["UpdateSettingsRequest"]) => request<Organization>("PATCH", "/v1/organizations/current/settings", b),
    },
    apps: {
      list: () => get<AppSummary[]>("/v1/apps"),
      create: (b: Schemas["CreateAppRequest"]) => post<AppDetail>("/v1/apps", b),
      get: (id: string) => get<AppDetail>(`/v1/apps/${id}`),
      createUpload: (id: string, b: Schemas["CreateUploadRequest"]) => post<CreateUploadResponse>(`/v1/apps/${id}/uploads`, b),
      finalize: (id: string, versionId: string) => post<AppVersion>(`/v1/apps/${id}/versions/${versionId}/finalize`),
    },
    deviceProfiles: () => get<DeviceProfile[]>("/v1/device-profiles"),
    hosts: {
      list: () => get<Host[]>("/v1/hosts"),
      get: (id: string) => get<HostDetail>(`/v1/hosts/${id}`),
      enrollmentToken: (name: string) => post<EnrollmentTokenResponse>("/v1/hosts/enrollment-token", { name }),
    },
    sessions: {
      list: (q: { active?: boolean; state?: string; limit?: number } = {}) => get<Session[]>(`/v1/sessions${qs(q)}`),
      create: (b: Schemas["CreateSessionRequest"]) => post<Session>("/v1/sessions", b),
      get: (id: string) => get<Session>(`/v1/sessions/${id}`),
      end: (id: string) => request<Session>("DELETE", `/v1/sessions/${id}`),
      action: (id: string, a: InputAction) => post<ActionResult>(`/v1/sessions/${id}/actions`, a),
      events: (id: string) => get<SessionEvent[]>(`/v1/sessions/${id}/events`),
      logs: (id: string, after?: number) => get<LogLine[]>(`/v1/sessions/${id}/logs${qs({ after })}`),
      screenshot: (id: string) => post<ScreenshotResponse>(`/v1/sessions/${id}/screenshot`),
      uiTree: (id: string) => get<Schemas["UiTreeResponse"]>(`/v1/sessions/${id}/ui-tree`),
      streamToken: (id: string) => post<StreamAccess>(`/v1/sessions/${id}/stream-token`),
    },
    apiKeys: {
      list: () => get<ApiKey[]>("/v1/api-keys"),
      create: (b: Schemas["CreateApiKeyRequest"]) => post<CreateApiKeyResponse>("/v1/api-keys", b),
      revoke: (id: string) => request<void>("DELETE", `/v1/api-keys/${id}`),
    },
    usage: () => get<Usage>("/v1/usage"),
    auditLogs: (q: { limit?: number; action?: string } = {}) => get<AuditLog[]>(`/v1/audit-logs${qs(q)}`),
  };
}

export type ApiClient = ReturnType<typeof createClient>;

/** Upload a file to a presigned URL (direct to MinIO/S3), reporting progress. */
export function uploadToPresignedUrl(url: string, file: Blob, onProgress?: (fraction: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress?.(e.loaded / e.total);
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`Upload failed (${xhr.status})`)));
    xhr.onerror = () => reject(new Error("Upload failed: network error (check MinIO CORS / S3_PUBLIC_ENDPOINT)"));
    xhr.send(file);
  });
}
