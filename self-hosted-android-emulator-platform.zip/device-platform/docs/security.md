# Security

## Threat model (summary)
| Actor | Concern | Mitigation |
|---|---|---|
| Other tenants | Read/affect another org's apps, sessions, hosts | `org_id` on every tenant row; org derived from the authenticated principal; every query filters by it; integration tests (`crates/api/tests/tenancy.rs`) |
| Malicious org member | Escalate privileges / run code on hosts | RBAC (owner/admin/developer/viewer); typed commands only; no shell, no raw ADB, no image names from users |
| Malicious APK | Zip bombs, path traversal, oversized files | Declared-size check + signed `content-length`, HEAD size check, capped download, entry/ratio/total limits, path checks, AXML parse, quarantine until approved |
| Network attacker | Session theft, CSRF | TLS (Caddy), `Secure`/`HttpOnly`/`SameSite` cookies, double-submit CSRF + Origin check, strict CORS allow-list |
| Compromised emulator | Escape to host / other sessions | No Docker socket, `no-new-privileges`, dropped caps, cgroup limits, ICC-disabled bridge network, ADB bound to loopback, ephemeral volumes destroyed on end |
| Compromised agent | Tamper with other hosts' data | Agent credential bound to one host+org; results/logs accepted only for sessions assigned to that host (tested) |

## Authentication
* Passwords: **Argon2id** (argon2 crate defaults, v19), minimum 12 characters. Constant-time-ish login
  (dummy hash verification for unknown users). Login failures are audited.
* Dashboard sessions: 256-bit random token in `dp_session` (HttpOnly, SameSite=Lax, Secure in
  production). Only the SHA-256 hash is stored. Expire after `AUTH_SESSION_HOURS` (default 12h).
* CSRF: `dp_csrf` cookie (readable, SameSite=Strict) must be echoed in `X-CSRF-Token` for every
  cookie-authenticated mutation; its hash is bound to the server-side session. The `Origin` header,
  when present, must be on the allow-list.
* Nothing is stored in `localStorage`.
* **Invite-only**: the first owner is created with `device-api bootstrap-invite` (prints a one-time
  link to the operator's terminal; it is never logged). Invite tokens are stored hashed and expire.

## API keys
`dpk_<random>`; only the SHA-256 hash and a short display prefix are stored; shown once. Scopes:
`apps:read apps:write sessions:read sessions:write hosts:read usage:read`. Administrative
permissions (members, keys, hosts, audit, settings) are **never** grantable to keys.

## Rate limits (per replica, in-memory token buckets)
login (per IP and per email), invite creation, invite acceptance, upload finalization, session
creation, agent enrollment. For multi-replica deployments put a limiter in front (Caddy plugin) or
move buckets to PostgreSQL.

## Artifacts & streaming
* Presigned upload URLs: 15 min; agent download URLs: 5 min; screenshot links: 5 min.
* Agents verify the SHA-256 and exact size before `adb install`.
* Stream tokens: HMAC-SHA256, 5-minute TTL, bound to session+host+org, re-validated against the
  session state on every `forward_auth` check. Long-lived credentials never appear in iframe URLs.

## Logging
`tracing` spans contain method, path and request id only (no query strings, which can carry
presigned/stream tokens; no headers). `Config`/`S3Config` have redacting `Debug` impls.

## Headers
API: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, restrictive CSP,
`Cache-Control: no-store`, HSTS when cookies are secure, `X-Request-Id` propagation.
Caddy adds HSTS, Permissions-Policy and the SPA CSP.

## Production refusals
The API exits on start if `APP_ENV=production` and any of: non-HTTPS `PUBLIC_URL`, insecure cookies,
wildcard CORS, `STREAM_MODE=local-dev`, short or development `STREAM_TOKEN_SECRET`, default-looking
S3 credentials.

## Reporting
Please report vulnerabilities privately to the maintainers; do not open public issues.
