# Emulator integration

## Adapters
| Adapter | Use | Status |
|---|---|---|
| `FakeEmulatorAdapter` | tests, local demo | fully implemented; renders a real PNG of a simulated screen, synthetic logcat and UI XML; always labelled “fake” |
| `AndroidEmulatorAdapter` | production | implemented against the official container tooling and ADB; **environment-dependent** (Docker + KVM + adb) |

## Images (allow-list)
Users choose a *device profile*; profiles carry an `image_key`; each agent maps `image_key` → image
in its own allow-list file. The control plane never sends image names and the agent rejects unknown
keys (`rejects_unlisted_images` test).

Build images with Google's official scripts: <https://github.com/google/android-emulator-container-scripts>
```bash
pip install emu-docker   # from the repo above
emu-docker list           # pick a system image + emulator build
emu-docker create stable "R google_apis x86_64" --dest ./build
docker build -t registry.example.com/android-emulator:30-google-apis-x86_64 ./build
```
Then reference the tag in `/etc/device-agent/images.json`. Review licences (see deployment.md).

The adapter expects the image conventions of those scripts: ADB on container port **5555**,
emulator gRPC on **8554**, the ADB key passed in `ADBKEY`. AVD data lives under
`/android-home` (overridable with `AGENT_EMULATOR_DATA_MOUNT`), which is backed by a per-session
named volume so Docker copies the pristine AVD in and deletes it with the session.

## What the adapter does (fixed argv, no shell)
| Command | Implementation |
|---|---|
| PrepareDevice | check `/dev/kvm`, `docker image inspect` / `docker pull <allow-listed>`, ensure bridge network |
| StartEmulator | `docker volume create`, `docker run -d --device /dev/kvm --cpus --memory --pids-limit --security-opt no-new-privileges --cap-drop … --network dp-emulators -p 127.0.0.1::5555 -p <bind>::8554 --env-file <0600 file>`; poll `getprop sys.boot_completed`; disable animations |
| InstallApp | download presigned URL with size cap, verify SHA-256, `adb install -r`, launch via `monkey -p` |
| SendInput | `input tap/swipe/text/keyevent`, `settings put system user_rotation`, `am start -a VIEW -d '<quoted>'` |
| CaptureScreenshot | `adb exec-out screencap -p` → PUT to presigned URL |
| FetchUiXml | `uiautomator dump` + `exec-out cat` |
| StartLogcat | `adb logcat -v threadtime` parsed and batched to the control plane |
| StopSession | kill logcat, `adb disconnect`, `docker rm -f -v`, `docker volume rm` |
| ResetDevice | `pm clear` installed packages, HOME |
On start the agent removes orphaned `dp.managed=true` containers/volumes from a previous run.

## Streaming
The control plane never relays media. The official web stack (from the same repository) consists
of the emulator's gRPC endpoint plus an Envoy proxy (gRPC-Web/WebRTC signaling) and a small web
client. Deploy it per host behind a **node ingress**:

1. Run Envoy + the emulator web client from `android-emulator-container-scripts/js/docker` on the
   host, pointed at `127.0.0.1:<grpc port>` (the agent reports the endpoint via `StartSession`).
2. Run `infra/node-ingress/Caddyfile` on the host with `NODE_DOMAIN`, `CONTROL_PLANE_URL`, TLS.
   It calls `GET /v1/stream/verify` (`forward_auth`) for every request; the API validates the
   5-minute token and returns `X-Dp-Upstream`.
3. Set `AGENT_STREAM_BASE_URL=https://node1.example.com` (before enrollment) and
   `STREAM_MODE=gateway` on the API.
4. Configure TURN (e.g. coturn) if browsers cannot reach hosts directly.

If any of this is missing, `POST /v1/sessions/{id}/stream-token` returns **`stream_unavailable`**
with instructions and the viewer shows them — it never pretends streaming works. Screenshots,
logcat, UI tree and input continue to work over the control channel.

> **Verification status:** WebRTC streaming could not be verified in the development environment
> used to build this (no KVM). The interfaces, token flow and ingress validation are implemented
> and unit-tested; end-to-end media must be validated on a real host with the checklist below.

## Manual verification checklist (real host)
- [ ] `device-agent` enrolls; host shows `kvm: yes`, Docker version, capacity.
- [ ] Session reaches READY in < 3 min (first image pull excluded).
- [ ] APK installs; tampering with the object makes InstallApp fail with “checksum mismatch”.
- [ ] Tap/swipe/text/rotate/deep link change the screenshot; logcat streams; UI tree loads.
- [ ] Stop → container and `dp-vol-*` volume are gone (`docker ps -a`, `docker volume ls`).
- [ ] Killing the agent mid-session → session FAILED (`host_lost`) within ~2 min; orphan reaped on restart.
- [ ] With node ingress: iframe streams; an expired token is rejected (401) by the ingress.
