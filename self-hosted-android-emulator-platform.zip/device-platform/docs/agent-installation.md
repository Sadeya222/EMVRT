# Installing `device-agent` on a Linux/KVM host

## Requirements
* x86_64 Linux (Ubuntu 22.04+/Debian 12 tested), CPU virtualisation enabled in BIOS.
* `/dev/kvm` present: `ls -l /dev/kvm` and `kvm-ok` (package `cpu-checker`).
* Docker Engine 24+; Android platform tools (`adb`) on the host (`apt install adb` or SDK platform-tools).
* Per emulator: ~2–4 vCPU, 3–5 GB RAM, ~8 GB disk.

## Install
```bash
# 1. Build (or download a release) and install the binary
cargo build --release -p dp-agent && sudo install -m 0755 target/release/device-agent /usr/local/bin/

# 2. Dedicated user with access to docker and kvm (note: docker group == root-equivalent on that host;
#    dedicate the machine to emulator workloads)
sudo useradd --system --create-home --home-dir /var/lib/device-agent dpagent
sudo usermod -aG docker,kvm dpagent

# 3. ADB key used to authenticate to emulator containers
sudo -u dpagent HOME=/var/lib/device-agent adb keygen /var/lib/device-agent/.android/adbkey

# 4. Configuration
sudo mkdir -p /etc/device-agent
sudo cp infra/agent/agent.env.example /etc/device-agent/agent.env
sudo cp infra/agent/images.json.example /etc/device-agent/images.json
sudo chmod 600 /etc/device-agent/agent.env
#   - CONTROL_PLANE_URL=https://dp.example.com
#   - AGENT_ENROLLMENT_TOKEN=<from Dashboard → Hosts → Enroll host>
#   - edit images.json: image_key → image reference you built/pulled (see emulator-integration.md)

# 5. systemd
sudo cp infra/agent/device-agent.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now device-agent
journalctl -u device-agent -f
```
After the first successful start the token is consumed; remove `AGENT_ENROLLMENT_TOKEN` from the
env file. Credentials live in `/var/lib/device-agent/credentials.json` (mode 0600). To re-enroll,
delete that file and use a new token.

## Configuration reference
| Variable | Default | Meaning |
|---|---|---|
| `CONTROL_PLANE_URL` | — | `https://…` (plain http only with `AGENT_ALLOW_INSECURE=true`, dev only) |
| `AGENT_ENROLLMENT_TOKEN` | — | one-time token, first start only |
| `AGENT_ADAPTER` | `android-emulator` | or `fake` |
| `AGENT_CAPACITY` | `2` | max concurrent emulators |
| `AGENT_IMAGES_FILE` / `AGENT_IMAGES` | — | JSON allow-list `image_key → image` |
| `AGENT_EMULATOR_NETWORK` | `dp-emulators` | dedicated bridge network (ICC disabled) |
| `AGENT_PUBLISH_BIND` | `127.0.0.1` | bind address for the emulator gRPC/web port |
| `AGENT_EMULATOR_DATA_MOUNT` | `/android-home` | path in the image backed by a per-session volume (`none` to disable) |
| `AGENT_ADB_KEY` | `~/.android/adbkey` | private ADB key passed via a 0600 env-file |
| `AGENT_BOOT_TIMEOUT_SECS` | `480` | wait for `sys.boot_completed` |
| `AGENT_STREAM_BASE_URL` | — | HTTPS node ingress for browser streaming |

## Firewall
Outbound 443 to the control plane and S3 endpoint. No inbound ports for control traffic.
Inbound 443 only if you run the node ingress for streaming.
