# Roadmap

## Done (v0.1)
Phases 1–6: monorepo, Compose, migrations, auth/tenancy, uploads + validation, API keys, audit,
agent + enrollment + WS protocol, state machine, PG scheduler, fake adapter, session UI,
Android adapter, ADB operations, StreamProvider, hardening, tests, docs.

## Next
1. **Real-host CI lane**: self-hosted runner with KVM running the emulator checklist nightly.
2. **Streaming gateway in Rust** replacing the Caddy `forward_auth` ingress; TURN credential minting.
3. **Warm pools**: pre-booted devices per profile (the scheduler already prefers `devices.status='ready'`).
4. **Multi-replica control plane**: PostgreSQL `LISTEN/NOTIFY` command bus so any replica can reach any agent.
5. **Host management**: drain/disable, labels for profile affinity, agent auto-update with signed releases.
6. **Session recordings** (screenrecord → MinIO) and test-automation hooks (Appium/UIAutomator runners via typed commands).
7. **SSO** (OIDC) and SCIM provisioning; per-org rate limits stored in PostgreSQL.
8. **Metrics**: Prometheus endpoint on API and agent; Grafana dashboards (compose profile exists).
9. Physical device adapter (USB-attached phones) behind the same `EmulatorAdapter` trait.

## Explicit non-goals
iOS; a free public device farm; raw shells or arbitrary command execution for users.
