# Local development

## Prerequisites
Rust stable (rustup), Node 22 + pnpm 9 (`corepack enable`), Docker, PostgreSQL client tools.

## Run infrastructure only, API and web natively
```bash
scripts/dev-setup.sh
docker compose up -d postgres minio minio-init
export $(grep -v '^#' .env | xargs)
export DATABASE_URL=postgresql://dp:$POSTGRES_PASSWORD@localhost:5432/device_platform \
       S3_ENDPOINT=http://localhost:9000 S3_ACCESS_KEY=$MINIO_ROOT_USER S3_SECRET_KEY=$MINIO_ROOT_PASSWORD \
       PUBLIC_URL=http://localhost:5173 CORS_ALLOWED_ORIGINS=http://localhost:5173
cargo run -p dp-api --bin device-api                     # :8081, migrations run automatically
cargo run -p dp-api --bin device-api -- bootstrap-invite --email you@example.com --org Dev
pnpm install && pnpm --filter @dp/web dev                # :5173, proxies /v1 to :8081
```
(Set `MINIO_API_CORS_ALLOW_ORIGIN=http://localhost:5173` for browser uploads in this mode.)

## Fake agent natively
```bash
CONTROL_PLANE_URL=http://localhost:8081 AGENT_ALLOW_INSECURE=true AGENT_ADAPTER=fake \
AGENT_STATE_DIR=/tmp/dp-agent AGENT_ENROLLMENT_TOKEN=dpe_... cargo run -p dp-agent
```
Note: in this mode agents download artifacts from `S3_AGENT_ENDPOINT` (defaults to the public endpoint).

## Tests
```bash
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/postgres cargo test --workspace
pnpm test            # vitest (jsdom)
pnpm e2e             # playwright; API mocked via route interception
```
`sqlx::test` creates and drops an isolated database per test, so the user needs `CREATEDB`.

## Tests that exist
| Area | Location |
|---|---|
| State machine transitions | `crates/common/src/state.rs` |
| APK validation (manifest parse, zip bomb, oversize) | `crates/common/src/apk.rs` |
| Protocol wire format / unknown command rejection / input validation | `crates/common/src/protocol.rs` |
| Scheduler races (capacity, quota), health, tenancy, warm devices | `crates/scheduler/tests/allocation.rs` |
| Tenancy, RBAC, CSRF, scoped keys, audit scoping, quota | `crates/api/tests/tenancy.rs` |
| Command idempotency (control plane) | `crates/api/tests/idempotency.rs` |
| Command idempotency (agent), shell quoting, image allow-list | `crates/agent/src/executor.rs`, `adapter/android.rs` |
| Stream tokens, presigner, rate limiter, password hashing | `crates/api/src/*.rs` |
| UI components & helpers | `apps/web/src/**/*.test.ts(x)` |
| Smoke: login → upload → create session | `apps/web/e2e/smoke.spec.ts` |

## Regenerating the API client
`pnpm generate:api` runs `device-api openapi` (no DB needed) and `openapi-typescript`.
