# Architecture

Device Platform is a **self-hosted, Android-only** emulator platform. A small control plane
(Rust API + PostgreSQL + MinIO + React dashboard) runs anywhere Docker Compose runs. Emulator
workloads run on **customer-owned Linux/KVM hosts** running the `device-agent` binary, which
dials *out* to the control plane over a WebSocket.

```
 Browser ──HTTPS──► Caddy ──► web (static React)        ┌────────── Linux/KVM host ──────────┐
                     │  └──► api (Axum) ◄──WSS (outbound)── device-agent ──docker──► emulator   │
                     │          │   │                    │        │ adb (loopback only)        │
                     │          │   └──► MinIO (APKs, screenshots; presigned URLs)              │
                     │          └──► PostgreSQL (state, scheduler locks, audit)                │
 Browser ──WebRTC/HTTPS (short-lived stream token) ──► node ingress (Caddy forward_auth) ──►   │
                                                                  emulator web endpoint       │
                                                         └─────────────────────────────────────┘
```

Design principles:

* **No arbitrary execution.** The dashboard sends *typed* commands only. The agent maps each
  typed command to a fixed argv (never a shell string built from user input).
* **No inbound ports on hosts.** Agents connect outbound; media goes to a node ingress only
  when explicitly configured with TLS + short-lived tokens.
* **PostgreSQL is the queue and the lock manager.** `SELECT … FOR UPDATE SKIP LOCKED` gives
  race-free allocation without Redis/NATS.
* **Org isolation everywhere.** Every tenant-owned table carries `org_id`; every query filters on
  the caller's `org_id` derived from the authenticated principal, never from request bodies.

## File tree

```
device-platform/
├── Cargo.toml                    # Rust workspace
├── apps/web/                     # React + Vite + Tailwind + Radix + TanStack Router/Query
│   ├── src/components/ui/        # accessible primitives (Radix based)
│   ├── src/components/session/   # viewer, logcat, a11y tree, screenshots, history
│   ├── src/pages/                # public + authenticated pages
│   ├── src/lib/                  # api wrapper, query keys, zustand UI store
│   └── e2e/                      # Playwright smoke tests (API mocked via route interception)
├── crates/
│   ├── common/                   # session state machine, agent protocol, roles, APK validator
│   ├── scheduler/                # Scheduler trait + PgScheduler (row locks, SKIP LOCKED)
│   ├── api/                      # Axum control plane (REST /v1, agent WS hub, OpenAPI)
│   │   └── tests/                # tenancy + idempotency integration tests (sqlx::test)
│   └── agent/                    # device-agent binary: enrollment, WS client, adapters
│       └── src/adapter/{mod,fake,android}.rs
├── packages/
│   ├── api-client/               # TS client; types generated from OpenAPI (openapi-typescript)
│   └── embed-sdk/                # tiny SDK to embed a session viewer in a customer page
├── migrations/                   # SQLx migrations (run automatically by the API)
├── infra/                        # docker-compose.yml, Dockerfiles, Caddyfile, prometheus
└── docs/
```

## Database schema plan

| Table | Purpose | Key columns |
|---|---|---|
| users | identities | email (unique, lower-cased), password_hash (Argon2id), disabled_at |
| organizations | tenants + quota/retention policy | slug, max_concurrent_sessions, max_session_minutes, apk_retention_days, max_apk_bytes |
| memberships | user↔org with role | (org_id,user_id) unique, role ∈ owner/admin/developer/viewer |
| auth_sessions | dashboard cookie sessions | token_hash (SHA-256), csrf_hash, active_org_id, expires_at, revoked_at |
| api_keys | scoped org keys | prefix, key_hash, scopes text[], expires_at, revoked_at |
| invites | invite-only registration | token_hash, email, role, expires_at, accepted_at |
| apps | logical application | org_id, name, package_name |
| app_versions | an uploaded APK | status (pending_upload→quarantined→validating→approved/rejected/deleted), sha256, size, package/version, expires_at |
| uploads | presigned upload records | object_key, declared_size, presigned_expires_at, completed_at |
| hosts | emulator hosts | org_id, adapter, kvm_available, emulator_capacity, allocated_slots, status, last_heartbeat_at |
| host_agents | enrollment + agent credentials | enrollment_token_hash (one-time), agent_secret_hash |
| device_profiles | allowed device shapes | api_level, abi, screen, image_key (key into agent allow-list, never an image name) |
| devices | (warm) emulator instances | host_id, profile_id, status, session_id |
| sessions | emulator sessions | state (strict state machine), host_id, device_id, timeout_minutes, ended_reason |
| session_events | state changes + user actions | kind, from_state, to_state, payload |
| session_commands | typed agent commands | id = command_id (idempotency key), status, result |
| session_log_lines | buffered logcat | seq, level, tag, message |
| usage_events | metering | kind, quantity |
| audit_logs | security-sensitive actions | actor, action, target, ip, metadata |

## API contract plan (all under `/v1`, OpenAPI at `/openapi.json`, UI at `/docs`)

Auth: cookie session (`dp_session`, HttpOnly) + double-submit CSRF (`dp_csrf` cookie ↔ `X-CSRF-Token`)
**or** `Authorization: Bearer dpk_…` API key (scoped, no CSRF needed). Errors: `{"error":{"code","message"}}`.

| Method & path | Permission |
|---|---|
| POST /auth/login, /auth/logout, /auth/accept-invite · GET /auth/me | public / any |
| POST /auth/invites | admin |
| GET/POST /organizations · GET /organizations/{id} · POST /organizations/{id}/activate | member |
| GET/PATCH /organizations/current/settings · GET /organizations/current/members | viewer / admin |
| GET/POST /apps · GET /apps/{id} | viewer / developer |
| POST /apps/{id}/uploads → presigned PUT | developer |
| POST /apps/{id}/versions/{vid}/finalize → validate + approve/reject | developer |
| GET /device-profiles | viewer |
| GET /hosts · GET /hosts/{id} · POST /hosts/enrollment-token | viewer / admin |
| POST/GET /sessions · GET/DELETE /sessions/{id} | developer / viewer |
| POST /sessions/{id}/actions (tap, swipe, text, key, rotate, deep_link) | developer |
| GET /sessions/{id}/events · /logs · /ui-tree · POST /screenshot · /stream-token | viewer / developer |
| GET/POST /api-keys · DELETE /api-keys/{id} | admin |
| GET /usage · GET /audit-logs | viewer / admin |
| POST /agent/enroll · GET /agent/connect (WS) | enrollment token / agent credential |
| GET /stream/verify | short-lived stream token (Caddy `forward_auth`) |

## Session lifecycle

```
REQUESTED → QUEUED → ASSIGNED → BOOTING → INSTALLING → READY → ACTIVE → ENDING → WIPED
     │         │         │          │          │          │        │
     └─────────┴─────────┴──────────┴──► FAILED / CANCELLED (from any non-terminal state)
```

`crates/common/src/state.rs` holds the single transition table. Every state write in the API goes
through `transition()` **and** a conditional `UPDATE … WHERE state = $expected`, so concurrent
writers cannot skip states.

Flow: API checks permission + quota → `PgScheduler` allocates host/device in one transaction →
orchestrator sends `PrepareDevice`, `StartEmulator` (agent waits for `sys.boot_completed`),
`InstallApp` (short-lived presigned URL + SHA-256 verified by the agent), `StartSession`,
`StartLogcat` → READY. End (user/timeout/host loss/admin) → `StopSession` (container + volume
destroyed) → WIPED, usage recorded, slot released.

## Streaming

`StreamProvider` (crates/api/src/stream.rs) returns either a `StreamAccess` (URL + token valid
≤ 5 minutes) or `stream_unavailable` with setup instructions. Providers:

* `fake` – FakeEmulatorAdapter hosts; UI renders a simulated display from real screenshots.
* `local-dev` – development only, host stream URL on a loopback/private address.
* `gateway` – HMAC-signed short-lived token appended to the host's HTTPS ingress URL; the node
  ingress (Caddy `forward_auth` → `/v1/stream/verify`) validates it before proxying signaling.

## Extension points

* `Scheduler` trait – swap PgScheduler for bin-packing/affinity schedulers.
* `EmulatorAdapter` trait – Fake / AndroidEmulator; add Cuttlefish or physical devices later.
* `StreamProvider` trait – add a Rust stream gateway or TURN-aware provider later.

## Components in detail

### Control plane (`crates/api`)
* `auth.rs` — `AuthCtx` extractor: API key (`Authorization: Bearer dpk_…`) or session cookie + CSRF.
  Handlers get the organization **only** via `ctx.require(Perm::…)`, which couples tenancy and RBAC.
* `hub.rs` — registry of connected agents; every command is persisted in `session_commands` before it
  is sent; results are applied with `UPDATE … WHERE status IN ('pending','sent','acked')` so duplicates are no-ops.
* `orchestrator.rs` — drives the lifecycle via typed commands; `finalize()` performs the terminal CAS
  transition, releases scheduler capacity and records usage **in one transaction**, exactly once.
* `stream.rs` — `StreamProvider` implementations and HMAC stream tokens.
* `storage.rs` — SigV4 presigner (no AWS SDK). Upload URLs sign `content-length`, so the client
  cannot upload a different size than the one that passed the size check.
* Background maintenance (every 5 s): heartbeat expiry, session timeouts, host-loss failure,
  stuck provisioning, queued placement retries, warm device cleanup, APK retention.

### Agent (`crates/agent`)
* Enrolls once with a one-time token → receives `agent_id` + secret (stored `0600`).
* Keeps one outbound WebSocket; heartbeats every 15 s with the host report.
* `Executor` deduplicates by `command_id` (cache of completed results + in-flight set).
* `EmulatorAdapter` trait → `FakeEmulatorAdapter` / `AndroidEmulatorAdapter`.

### Agent protocol (`crates/common/src/protocol.rs`)
```
Agent → CP: hello · heartbeat · command_ack · command_result · log_lines · session_lost
CP → Agent: welcome · command{PrepareDevice|StartEmulator|InstallApp|StartSession|SendInput|
                             CaptureScreenshot|FetchUiXml|StartLogcat|StopSession|ResetDevice} · ping
```
Unknown message kinds fail deserialisation and are dropped (tested).
