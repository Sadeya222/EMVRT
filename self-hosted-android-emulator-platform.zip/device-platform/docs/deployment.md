# Deployment

## Read this first
* **Android-only.** iOS is not supported (and cannot legally/technically run on Linux hosts).
* **A Linux host with KVM is required for emulator workloads.** Nested virtualisation on cloud VMs is
  often slow or unavailable; bare-metal or KVM-enabled instances are recommended.
* **A free public cloud emulator service is not economically viable.** Each Android emulator needs
  ~2–4 vCPU and 2–4 GB RAM while running, plus bandwidth for video. This project is deliberately
  self-hosted / bring-your-own-host.
* **Licensing.** Android Emulator system images, and especially images containing **Google Play
  Services / Google APIs**, are subject to Google's licence terms. Review them (and the Android SDK
  licence) before any commercial use or redistribution. Prefer AOSP/"Google APIs" images where possible.
* **Public streaming requires planning:** TLS certificates, DNS for each node ingress, firewall
  rules, and TURN/STUN for WebRTC when browsers and hosts are on different networks.

## Topology
```
[ Control plane VM ]  Caddy (TLS) → web, api ; PostgreSQL ; MinIO
        ▲  WSS (outbound from hosts)          ▲ HTTPS presigned downloads
[ KVM host 1..n ]  device-agent → Docker → emulator containers
        └─ optional node ingress (Caddy + TLS) for browser streaming
```

## Control plane
1. Provision a VM with Docker. Point DNS at it: `dp.example.com` (dashboard/API) and `s3.example.com` (MinIO S3 API).
2. `cp .env.example .env` and set:
   * `APP_ENV=production`, `PUBLIC_URL=https://dp.example.com`, `CORS_ALLOWED_ORIGINS=https://dp.example.com`, `COOKIE_SECURE=true`
   * strong `POSTGRES_PASSWORD`, `MINIO_ROOT_PASSWORD`, `STREAM_TOKEN_SECRET` (`openssl rand -hex 32`)
   * `S3_PUBLIC_ENDPOINT=https://s3.example.com` and `S3_AGENT_ENDPOINT=https://s3.example.com`
   * `SITE_ADDRESS=dp.example.com`
3. Add a Caddy site block for `s3.example.com { reverse_proxy minio:9000 }` and remove the
   `127.0.0.1:9000` port mapping. Set `MINIO_API_CORS_ALLOW_ORIGIN=https://dp.example.com`.
4. Expose only 80/443. Keep PostgreSQL and the MinIO console private.
5. `docker compose up -d --build`, then `scripts/bootstrap.sh owner@example.com "Acme"`.
6. Backups: `pg_dump` nightly; MinIO bucket replication or `mc mirror`.

## Hosts
See [agent-installation.md](agent-installation.md). Hosts only need **outbound** HTTPS to the
control plane and S3 endpoint. Streaming additionally needs inbound 443 on the node ingress.

## Upgrades
Migrations run automatically on API start (`sqlx::migrate!`). Upgrade the API before agents; the
protocol carries `protocol_version`.

## Scaling notes
A single API replica handles hundreds of concurrent sessions (agents hold one WebSocket each).
Running multiple API replicas requires sticky routing of agent WebSockets or a shared command bus
(see roadmap) — the scheduler itself is already safe across replicas (row locks).
