-- Device Platform initial schema. All IDs are UUIDs; tenant-owned rows carry org_id.

CREATE TABLE users (
    id              UUID PRIMARY KEY,
    email           TEXT NOT NULL,
    display_name    TEXT NOT NULL DEFAULT '',
    password_hash   TEXT NOT NULL,
    disabled_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT users_email_lower CHECK (email = lower(email))
);
CREATE UNIQUE INDEX users_email_key ON users (email);

CREATE TABLE organizations (
    id                       UUID PRIMARY KEY,
    name                     TEXT NOT NULL,
    slug                     TEXT NOT NULL UNIQUE,
    max_concurrent_sessions  INT NOT NULL DEFAULT 2 CHECK (max_concurrent_sessions >= 0),
    max_session_minutes      INT NOT NULL DEFAULT 30 CHECK (max_session_minutes BETWEEN 1 AND 720),
    default_session_minutes  INT NOT NULL DEFAULT 15 CHECK (default_session_minutes BETWEEN 1 AND 720),
    apk_retention_days       INT NOT NULL DEFAULT 90 CHECK (apk_retention_days BETWEEN 1 AND 3650),
    max_apk_bytes            BIGINT NOT NULL DEFAULT 209715200,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
    id          UUID PRIMARY KEY,
    org_id      UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role        TEXT NOT NULL CHECK (role IN ('owner','admin','developer','viewer')),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (org_id, user_id)
);
CREATE INDEX memberships_user_idx ON memberships (user_id);

CREATE TABLE auth_sessions (
    id             UUID PRIMARY KEY,
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash     BYTEA NOT NULL UNIQUE,
    csrf_hash      BYTEA NOT NULL,
    active_org_id  UUID REFERENCES organizations(id) ON DELETE SET NULL,
    ip             TEXT,
    user_agent     TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at     TIMESTAMPTZ NOT NULL,
    revoked_at     TIMESTAMPTZ
);
CREATE INDEX auth_sessions_user_idx ON auth_sessions (user_id);

CREATE TABLE api_keys (
    id            UUID PRIMARY KEY,
    org_id        UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    created_by    UUID REFERENCES users(id) ON DELETE SET NULL,
    name          TEXT NOT NULL,
    prefix        TEXT NOT NULL,
    key_hash      BYTEA NOT NULL UNIQUE,
    scopes        TEXT[] NOT NULL DEFAULT '{}',
    last_used_at  TIMESTAMPTZ,
    expires_at    TIMESTAMPTZ,
    revoked_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX api_keys_org_idx ON api_keys (org_id);

CREATE TABLE invites (
    id           UUID PRIMARY KEY,
    org_id       UUID REFERENCES organizations(id) ON DELETE CASCADE,
    email        TEXT NOT NULL,
    role         TEXT NOT NULL CHECK (role IN ('owner','admin','developer','viewer')),
    token_hash   BYTEA NOT NULL UNIQUE,
    invited_by   UUID REFERENCES users(id) ON DELETE SET NULL,
    -- Bootstrap invites create a brand new organization with this name on acceptance.
    bootstrap_org_name TEXT,
    expires_at   TIMESTAMPTZ NOT NULL,
    accepted_at  TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX invites_org_idx ON invites (org_id);

CREATE TABLE apps (
    id            UUID PRIMARY KEY,
    org_id        UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    package_name  TEXT,
    created_by    UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX apps_org_idx ON apps (org_id, created_at DESC);

CREATE TABLE app_versions (
    id                UUID PRIMARY KEY,
    org_id            UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    app_id            UUID NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
    status            TEXT NOT NULL CHECK (status IN ('pending_upload','quarantined','validating','approved','rejected','deleted')),
    object_key        TEXT NOT NULL,
    file_name         TEXT NOT NULL,
    declared_size     BIGINT NOT NULL,
    size_bytes        BIGINT,
    sha256            TEXT,
    package_name      TEXT,
    version_name      TEXT,
    version_code      BIGINT,
    min_sdk           INT,
    rejection_reason  TEXT,
    uploaded_by       UUID REFERENCES users(id) ON DELETE SET NULL,
    validated_at      TIMESTAMPTZ,
    expires_at        TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX app_versions_app_idx ON app_versions (org_id, app_id, created_at DESC);
CREATE INDEX app_versions_expiry_idx ON app_versions (expires_at) WHERE status <> 'deleted';

CREATE TABLE uploads (
    id                    UUID PRIMARY KEY,
    org_id                UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    app_version_id        UUID NOT NULL REFERENCES app_versions(id) ON DELETE CASCADE,
    object_key            TEXT NOT NULL,
    declared_size         BIGINT NOT NULL,
    presigned_expires_at  TIMESTAMPTZ NOT NULL,
    completed_at          TIMESTAMPTZ,
    created_by            UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX uploads_org_idx ON uploads (org_id, app_version_id);

CREATE TABLE hosts (
    id                  UUID PRIMARY KEY,
    org_id              UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name                TEXT NOT NULL,
    hostname            TEXT NOT NULL DEFAULT '',
    os                  TEXT NOT NULL DEFAULT '',
    docker_version      TEXT,
    adapter             TEXT NOT NULL DEFAULT 'android-emulator' CHECK (adapter IN ('fake','android-emulator')),
    agent_version       TEXT,
    kvm_available       BOOLEAN NOT NULL DEFAULT false,
    cpu_count           INT NOT NULL DEFAULT 0,
    ram_mb              BIGINT NOT NULL DEFAULT 0,
    disk_free_mb        BIGINT NOT NULL DEFAULT 0,
    emulator_capacity   INT NOT NULL DEFAULT 0,
    reported_active     INT NOT NULL DEFAULT 0,
    allocated_slots     INT NOT NULL DEFAULT 0 CHECK (allocated_slots >= 0),
    status              TEXT NOT NULL DEFAULT 'offline' CHECK (status IN ('online','offline','draining','disabled')),
    labels              JSONB NOT NULL DEFAULT '{}'::jsonb,
    stream_base_url     TEXT,
    last_heartbeat_at   TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX hosts_org_status_idx ON hosts (org_id, status);

CREATE TABLE host_agents (
    id                     UUID PRIMARY KEY,
    org_id                 UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    host_id                UUID REFERENCES hosts(id) ON DELETE CASCADE,
    name                   TEXT NOT NULL,
    enrollment_token_hash  BYTEA NOT NULL UNIQUE,
    enrollment_expires_at  TIMESTAMPTZ NOT NULL,
    enrolled_at            TIMESTAMPTZ,
    agent_secret_hash      BYTEA,
    last_connected_at      TIMESTAMPTZ,
    revoked_at             TIMESTAMPTZ,
    created_by             UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX host_agents_org_idx ON host_agents (org_id);

CREATE TABLE device_profiles (
    id             UUID PRIMARY KEY,
    org_id         UUID REFERENCES organizations(id) ON DELETE CASCADE, -- NULL = built-in
    slug           TEXT NOT NULL,
    name           TEXT NOT NULL,
    api_level      INT NOT NULL,
    abi            TEXT NOT NULL,
    screen_width   INT NOT NULL,
    screen_height  INT NOT NULL,
    density        INT NOT NULL,
    cpu_cores      INT NOT NULL DEFAULT 2,
    ram_mb         INT NOT NULL DEFAULT 2048,
    disk_mb        INT NOT NULL DEFAULT 8192,
    image_key      TEXT NOT NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX device_profiles_slug_key ON device_profiles (COALESCE(org_id, '00000000-0000-0000-0000-000000000000'::uuid), slug);

CREATE TABLE devices (
    id            UUID PRIMARY KEY,
    org_id        UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    host_id       UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    profile_id    UUID NOT NULL REFERENCES device_profiles(id),
    status        TEXT NOT NULL CHECK (status IN ('warming','ready','in_use','wiping','failed')),
    session_id    UUID,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX devices_alloc_idx ON devices (org_id, profile_id, status);

CREATE TABLE sessions (
    id               UUID PRIMARY KEY,
    org_id           UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    app_version_id   UUID REFERENCES app_versions(id) ON DELETE SET NULL,
    profile_id       UUID NOT NULL REFERENCES device_profiles(id),
    host_id          UUID REFERENCES hosts(id) ON DELETE SET NULL,
    device_id        UUID REFERENCES devices(id) ON DELETE SET NULL,
    state            TEXT NOT NULL CHECK (state IN ('REQUESTED','QUEUED','ASSIGNED','BOOTING','INSTALLING','READY','ACTIVE','ENDING','WIPED','FAILED','CANCELLED')),
    requested_by     UUID REFERENCES users(id) ON DELETE SET NULL,
    requested_by_key UUID REFERENCES api_keys(id) ON DELETE SET NULL,
    timeout_minutes  INT NOT NULL,
    stream_kind      TEXT,
    stream_endpoint  TEXT,
    ended_reason     TEXT,
    failure_reason   TEXT,
    ready_at         TIMESTAMPTZ,
    ended_at         TIMESTAMPTZ,
    expires_at       TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX sessions_org_idx ON sessions (org_id, created_at DESC);
CREATE INDEX sessions_org_state_idx ON sessions (org_id, state);
CREATE INDEX sessions_host_idx ON sessions (host_id, state);
ALTER TABLE devices ADD CONSTRAINT devices_session_fk FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE SET NULL;

CREATE TABLE session_events (
    id             UUID PRIMARY KEY,
    org_id         UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    session_id     UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    kind           TEXT NOT NULL,
    from_state     TEXT,
    to_state       TEXT,
    actor_user_id  UUID REFERENCES users(id) ON DELETE SET NULL,
    payload        JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX session_events_session_idx ON session_events (org_id, session_id, created_at);

CREATE TABLE session_commands (
    id            UUID PRIMARY KEY, -- the command_id sent to the agent (idempotency key)
    org_id        UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    session_id    UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    host_id       UUID NOT NULL REFERENCES hosts(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL,
    payload       JSONB NOT NULL,
    status        TEXT NOT NULL CHECK (status IN ('pending','sent','acked','succeeded','failed','timed_out')),
    result        JSONB,
    error         TEXT,
    attempts      INT NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at  TIMESTAMPTZ
);
CREATE INDEX session_commands_session_idx ON session_commands (org_id, session_id, created_at);
CREATE INDEX session_commands_host_pending_idx ON session_commands (host_id) WHERE status IN ('pending','sent','acked');

CREATE TABLE session_log_lines (
    id          BIGSERIAL PRIMARY KEY,
    org_id      UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    session_id  UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    ts          TEXT NOT NULL,
    level       TEXT NOT NULL,
    tag         TEXT NOT NULL,
    message     TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX session_log_lines_idx ON session_log_lines (org_id, session_id, id);

CREATE TABLE usage_events (
    id          UUID PRIMARY KEY,
    org_id      UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    session_id  UUID REFERENCES sessions(id) ON DELETE SET NULL,
    kind        TEXT NOT NULL,
    quantity    BIGINT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX usage_events_org_idx ON usage_events (org_id, created_at);

CREATE TABLE audit_logs (
    id                UUID PRIMARY KEY,
    org_id            UUID REFERENCES organizations(id) ON DELETE CASCADE,
    actor_user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    actor_api_key_id  UUID REFERENCES api_keys(id) ON DELETE SET NULL,
    action            TEXT NOT NULL,
    target_type       TEXT,
    target_id         TEXT,
    ip                TEXT,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_org_idx ON audit_logs (org_id, created_at DESC);

-- Built-in device profiles. image_key refers to the agent's allow-list (agent config), never to
-- a raw Docker image name.
INSERT INTO device_profiles (id, org_id, slug, name, api_level, abi, screen_width, screen_height, density, cpu_cores, ram_mb, disk_mb, image_key) VALUES
 ('01900000-0000-7000-8000-000000000001', NULL, 'pixel-6-api-34', 'Pixel 6 · Android 14', 34, 'x86_64', 1080, 2400, 420, 4, 4096, 8192, 'android-34-google-apis-x86_64'),
 ('01900000-0000-7000-8000-000000000002', NULL, 'pixel-4-api-30', 'Pixel 4 · Android 11', 30, 'x86_64', 1080, 2280, 440, 2, 3072, 6144, 'android-30-google-apis-x86_64'),
 ('01900000-0000-7000-8000-000000000003', NULL, 'tablet-api-33', 'Generic Tablet · Android 13', 33, 'x86_64', 1600, 2560, 320, 4, 4096, 8192, 'android-33-google-apis-x86_64');
