#!/usr/bin/env bash
# Generate a local .env with random secrets (development only).
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -f .env ]; then echo ".env already exists; refusing to overwrite"; exit 1; fi
rand() { openssl rand -hex "$1"; }
sed -e "s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$(rand 24)/" \
    -e "s/^MINIO_ROOT_PASSWORD=.*/MINIO_ROOT_PASSWORD=$(rand 24)/" \
    -e "s/^STREAM_TOKEN_SECRET=.*/STREAM_TOKEN_SECRET=$(rand 32)/" .env.example > .env
chmod 600 .env
echo "Wrote .env with random development secrets."
