#!/usr/bin/env bash
# Create the first owner invite (prints a one-time link). Usage: scripts/bootstrap.sh you@example.com "Acme"
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose exec api device-api bootstrap-invite --email "${1:?email}" --org "${2:-My Organization}"
