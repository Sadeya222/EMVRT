#!/usr/bin/env bash
# Regenerate packages/api-client types from the Rust OpenAPI document.
set -euo pipefail
cd "$(dirname "$0")/.."
cargo run -q -p dp-api --bin device-api -- openapi > packages/api-client/openapi.json
pnpm --filter @dp/api-client exec openapi-typescript openapi.json -o src/schema.ts
echo "Regenerated packages/api-client/src/schema.ts"
