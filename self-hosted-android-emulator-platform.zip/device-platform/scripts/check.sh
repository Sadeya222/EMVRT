#!/usr/bin/env bash
# Full local quality gate.
set -euo pipefail
cd "$(dirname "$0")/.."
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
DATABASE_URL="${DATABASE_URL:?DATABASE_URL for sqlx::test (needs CREATEDB)}" cargo test --workspace
pnpm lint && pnpm typecheck && pnpm test && pnpm build
